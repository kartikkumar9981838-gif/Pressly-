import { PDFDocument, rgb, degrees, StandardFonts, PDFName, PDFDict, PDFPage, PDFFont } from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';
import { decryptPdfWithQpdf } from './qpdfEngine';

// Set up PDF.js worker with offline-ready local resolution and CDN fallback
try {
  pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
    'pdfjs-dist/build/pdf.worker.min.mjs',
    import.meta.url
  ).toString();
} catch {
  pdfjsLib.GlobalWorkerOptions.workerSrc = `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;
}

export interface PDFMetadata {
  title?: string;
  author?: string;
  subject?: string;
  keywords?: string[];
  creator?: string;
  producer?: string;
}

export interface AcroFormFieldInfo {
  name: string;
  type: 'text' | 'checkbox' | 'radio' | 'dropdown' | 'option';
  value: string;
  options?: string[];
}

export interface SplitResult {
  filename: string;
  bytes: Uint8Array;
}

/**
 * Helper to convert hex color (#RRGGBB) to pdf-lib rgb()
 */
export function hexToRgb(hex: string) {
  let cleanHex = hex.replace('#', '');
  if (cleanHex.length === 3) {
    cleanHex = cleanHex.split('').map((c) => c + c).join('');
  }
  const num = parseInt(cleanHex, 16);
  if (isNaN(num)) return rgb(0, 0, 0);
  return rgb(((num >> 16) & 255) / 255, ((num >> 8) & 255) / 255, (num & 255) / 255);
}

/**
 * Load PDF with pdf-lib
 */
export async function loadPdfDoc(buffer: ArrayBuffer, password?: string): Promise<PDFDocument> {
  return await PDFDocument.load(buffer, {
    ignoreEncryption: false,
  } as any);
}

/**
 * Load PDF for rendering with PDF.js
 */
export async function loadPdfJsDoc(buffer: ArrayBuffer, password?: string): Promise<pdfjsLib.PDFDocumentProxy> {
  const loadingTask = pdfjsLib.getDocument({
    data: new Uint8Array(buffer.slice(0)),
    password,
  } as any);
  return await loadingTask.promise;
}

const activeRenderTasks = new WeakMap<HTMLCanvasElement, any>();

/**
 * Render a single page to HTML Canvas element
 */
export async function renderPageToCanvas(
  pdfJsDoc: pdfjsLib.PDFDocumentProxy,
  pageNumber: number,
  canvas: HTMLCanvasElement,
  scale: number = 1.0
): Promise<void> {
  const existingTask = activeRenderTasks.get(canvas);
  if (existingTask) {
    try {
      existingTask.cancel();
    } catch {
      // ignore cancellation errors
    }
    activeRenderTasks.delete(canvas);
  }

  const page = await pdfJsDoc.getPage(pageNumber);
  const viewport = page.getViewport({ scale });
  
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  canvas.width = viewport.width;
  canvas.height = viewport.height;

  const renderTask = page.render({
    canvasContext: ctx,
    viewport: viewport,
    canvas: canvas,
  } as any);

  activeRenderTasks.set(canvas, renderTask);

  try {
    await renderTask.promise;
  } catch (err: any) {
    if (err?.name === 'RenderingCancelledException' || err?.message?.includes('cancelled')) {
      return;
    }
    throw err;
  } finally {
    if (activeRenderTasks.get(canvas) === renderTask) {
      activeRenderTasks.delete(canvas);
    }
  }
}

/**
 * Render a page thumbnail to a base64 Data URL
 */
export async function renderPageThumbnail(
  pdfJsDoc: pdfjsLib.PDFDocumentProxy,
  pageNumber: number,
  width: number = 140
): Promise<string> {
  const page = await pdfJsDoc.getPage(pageNumber);
  const unscaledViewport = page.getViewport({ scale: 1.0 });
  const scale = width / unscaledViewport.width;
  const viewport = page.getViewport({ scale });

  const canvas = document.createElement('canvas');
  canvas.width = viewport.width;
  canvas.height = viewport.height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  await page.render({
    canvasContext: ctx,
    viewport: viewport,
    canvas: canvas,
  } as any).promise;

  return canvas.toDataURL('image/png');
}

/**
 * Render all page thumbnails for a document
 */
export async function renderAllThumbnails(
  pdfJsDoc: pdfjsLib.PDFDocumentProxy,
  width: number = 140
): Promise<string[]> {
  const thumbnails: string[] = [];
  for (let i = 1; i <= pdfJsDoc.numPages; i++) {
    const thumb = await renderPageThumbnail(pdfJsDoc, i, width);
    thumbnails.push(thumb);
  }
  return thumbnails;
}

/**
 * MERGE multiple PDF ArrayBuffers into a single PDF Uint8Array
 */
export async function mergePdfs(pdfBuffers: ArrayBuffer[]): Promise<Uint8Array> {
  const mergedPdf = await PDFDocument.create();
  for (const buffer of pdfBuffers) {
    const doc = await PDFDocument.load(buffer);
    const copiedPages = await mergedPdf.copyPages(doc, doc.getPageIndices());
    copiedPages.forEach((page) => mergedPdf.addPage(page));
  }
  return await mergedPdf.save();
}

/**
 * SPLIT a PDF into multiple separate files
 */
export async function splitPdf(
  buffer: ArrayBuffer,
  mode: 'every_n' | 'range',
  param: number | string // every N pages OR page ranges like "1-3, 4-5"
): Promise<SplitResult[]> {
  const doc = await PDFDocument.load(buffer);
  const totalPages = doc.getPageCount();
  const results: SplitResult[] = [];

  if (mode === 'every_n') {
    const n = Math.max(1, Number(param) || 1);
    let partIndex = 1;
    for (let i = 0; i < totalPages; i += n) {
      const subDoc = await PDFDocument.create();
      const indices = [];
      for (let j = i; j < Math.min(i + n, totalPages); j++) {
        indices.push(j);
      }
      const pages = await subDoc.copyPages(doc, indices);
      pages.forEach((p) => subDoc.addPage(p));
      const bytes = await subDoc.save();
      results.push({
        filename: `split_part_${partIndex}_pages_${i + 1}-${Math.min(i + n, totalPages)}.pdf`,
        bytes,
      });
      partIndex++;
    }
  } else {
    // Mode: range e.g. "1-2, 3-5"
    const rangesStr = String(param).split(',');
    let partIndex = 1;
    for (const range of rangesStr) {
      const parts = range.trim().split('-').map((v) => parseInt(v.trim(), 10));
      if (parts.length > 0 && !isNaN(parts[0])) {
        const start = Math.max(1, parts[0]);
        const end = parts.length > 1 && !isNaN(parts[1]) ? Math.min(totalPages, parts[1]) : start;
        const indices: number[] = [];
        for (let p = start; p <= end; p++) {
          if (p <= totalPages) indices.push(p - 1);
        }
        if (indices.length > 0) {
          const subDoc = await PDFDocument.create();
          const pages = await subDoc.copyPages(doc, indices);
          pages.forEach((p) => subDoc.addPage(p));
          const bytes = await subDoc.save();
          results.push({
            filename: `split_range_${start}-${end}.pdf`,
            bytes,
          });
          partIndex++;
        }
      }
    }
  }
  return results;
}

/**
 * EXTRACT specific pages into a new PDF
 */
export async function extractPages(buffer: ArrayBuffer, pageNumbers: number[]): Promise<Uint8Array> {
  const srcDoc = await PDFDocument.load(buffer);
  const newDoc = await PDFDocument.create();
  const indices = pageNumbers.map((n) => n - 1).filter((idx) => idx >= 0 && idx < srcDoc.getPageCount());
  const pages = await newDoc.copyPages(srcDoc, indices);
  pages.forEach((p) => newDoc.addPage(p));
  return await newDoc.save();
}

export interface ParsedPageRangesResult {
  pages: number[];
  uniquePages: number[];
  invalidTokens: string[];
  outOfRangePages: number[];
  formattedRangeString: string;
  isValid: boolean;
  errorMessage?: string;
}

/**
 * Format an array of page numbers into a clean range string like "1-5, 8, 12-17, 25"
 */
export function formatPagesToRangeString(pages: number[]): string {
  if (!pages || pages.length === 0) return '';
  const sorted = Array.from(new Set(pages.filter((p) => typeof p === 'number' && !isNaN(p) && p > 0))).sort((a, b) => a - b);
  if (sorted.length === 0) return '';

  const ranges: string[] = [];
  let rangeStart = sorted[0];
  let prev = sorted[0];

  for (let i = 1; i < sorted.length; i++) {
    const current = sorted[i];
    if (current === prev + 1) {
      prev = current;
    } else {
      if (rangeStart === prev) {
        ranges.push(`${rangeStart}`);
      } else if (prev === rangeStart + 1) {
        ranges.push(`${rangeStart}, ${prev}`);
      } else {
        ranges.push(`${rangeStart}-${prev}`);
      }
      rangeStart = current;
      prev = current;
    }
  }

  if (rangeStart === prev) {
    ranges.push(`${rangeStart}`);
  } else if (prev === rangeStart + 1) {
    ranges.push(`${rangeStart}, ${prev}`);
  } else {
    ranges.push(`${rangeStart}-${prev}`);
  }

  return ranges.join(', ');
}

/**
 * Robust parser for page ranges like "1-5, 8, 12-17, 25", "1-3, 5, 7-10", "4, 6, 8"
 */
export function parsePageRanges(rangeStr: string, maxPages: number): ParsedPageRangesResult {
  if (!rangeStr || !rangeStr.trim()) {
    return {
      pages: [],
      uniquePages: [],
      invalidTokens: [],
      outOfRangePages: [],
      formattedRangeString: '',
      isValid: false,
      errorMessage: 'Please enter at least one page number or range (e.g. 1-5, 8, 12-17, 25).',
    };
  }

  // Split by commas, semicolons, or whitespace when appropriate
  const rawTokens = rangeStr
    .split(/[,;]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0);

  const resolvedPages: number[] = [];
  const invalidTokens: string[] = [];
  const outOfRangePages: number[] = [];

  for (const token of rawTokens) {
    const cleanToken = token.trim();
    if (!cleanToken) continue;

    // Check if token contains a range separator (- or .. or to)
    if (cleanToken.includes('-') || cleanToken.includes('..') || /\bto\b/i.test(cleanToken)) {
      const parts = cleanToken.includes('..')
        ? cleanToken.split('..')
        : cleanToken.includes('-')
        ? cleanToken.split('-')
        : cleanToken.split(/\s+to\s+/i);

      if (parts.length === 2) {
        const start = parseInt(parts[0].trim(), 10);
        const end = parseInt(parts[1].trim(), 10);

        if (isNaN(start) || isNaN(end) || start < 1 || end < 1) {
          invalidTokens.push(cleanToken);
        } else {
          const min = Math.min(start, end);
          const max = Math.max(start, end);

          for (let p = min; p <= max; p++) {
            if (p > maxPages) {
              outOfRangePages.push(p);
            } else {
              resolvedPages.push(p);
            }
          }
        }
      } else {
        invalidTokens.push(cleanToken);
      }
    } else {
      // Single number (or space separated numbers like "1 2 3")
      const subTokens = cleanToken.split(/\s+/).filter((s) => s.length > 0);
      for (const sub of subTokens) {
        const num = parseInt(sub, 10);
        if (isNaN(num) || num < 1) {
          invalidTokens.push(sub);
        } else if (num > maxPages) {
          outOfRangePages.push(num);
        } else {
          resolvedPages.push(num);
        }
      }
    }
  }

  const uniqueSorted = Array.from(new Set(resolvedPages)).sort((a, b) => a - b);
  const formatted = formatPagesToRangeString(uniqueSorted);

  let errorMessage: string | undefined = undefined;
  if (invalidTokens.length > 0) {
    errorMessage = `Invalid entry: "${invalidTokens.join(', ')}". Please use valid numbers and ranges (e.g. 1-5, 8, 12-17, 25).`;
  } else if (outOfRangePages.length > 0 && uniqueSorted.length === 0) {
    errorMessage = `Page ${Array.from(new Set(outOfRangePages)).join(', ')} is beyond document total pages (${maxPages}).`;
  } else if (uniqueSorted.length === 0) {
    errorMessage = 'No valid pages found in the specified range.';
  }

  return {
    pages: resolvedPages,
    uniquePages: uniqueSorted,
    invalidTokens,
    outOfRangePages: Array.from(new Set(outOfRangePages)),
    formattedRangeString: formatted,
    isValid: uniqueSorted.length > 0,
    errorMessage,
  };
}

/**
 * EXTRACT multiple pages into separate individual PDF files (one file per page)
 */
export async function extractPagesToSeparateFiles(
  buffer: ArrayBuffer,
  pageNumbers: number[],
  baseFilename: string = 'document.pdf'
): Promise<Array<{ filename: string; bytes: Uint8Array; pageNumber: number }>> {
  const doc = await PDFDocument.load(buffer);
  const totalPages = doc.getPageCount();
  const results: Array<{ filename: string; bytes: Uint8Array; pageNumber: number }> = [];

  const cleanBaseName = baseFilename.replace(/\.pdf$/i, '');

  for (const pageNum of pageNumbers) {
    if (pageNum < 1 || pageNum > totalPages) continue;
    const singleDoc = await PDFDocument.create();
    const [copiedPage] = await singleDoc.copyPages(doc, [pageNum - 1]);
    singleDoc.addPage(copiedPage);
    const bytes = await singleDoc.save();
    results.push({
      filename: `${cleanBaseName}_page_${pageNum}.pdf`,
      bytes,
      pageNumber: pageNum,
    });
  }

  return results;
}

/**
 * DELETE specific pages from PDF
 */
export async function deletePages(buffer: ArrayBuffer, pageNumbersToDelete: number[]): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const deleteSet = new Set(pageNumbersToDelete.map((n) => n - 1));
  const newDoc = await PDFDocument.create();
  const keepIndices: number[] = [];
  for (let i = 0; i < doc.getPageCount(); i++) {
    if (!deleteSet.has(i)) {
      keepIndices.push(i);
    }
  }
  if (keepIndices.length === 0) {
    throw new Error('Cannot delete all pages from document.');
  }
  const pages = await newDoc.copyPages(doc, keepIndices);
  pages.forEach((p) => newDoc.addPage(p));
  return await newDoc.save();
}

/**
 * REORDER pages in a PDF
 */
export async function reorderPages(buffer: ArrayBuffer, newOrder1Based: number[]): Promise<Uint8Array> {
  const srcDoc = await PDFDocument.load(buffer);
  const newDoc = await PDFDocument.create();
  const indices = newOrder1Based.map((n) => n - 1).filter((idx) => idx >= 0 && idx < srcDoc.getPageCount());
  const pages = await newDoc.copyPages(srcDoc, indices);
  pages.forEach((p) => newDoc.addPage(p));
  return await newDoc.save();
}

/**
 * Compute 1-based indices for pdf-lib copyPages given a target list of page labels
 * and the current sequence of page labels in pdfBuffer.
 */
export function computeReorderIndices(
  targetLabels: number[],
  currentSequence: number[],
  pageCount: number
): { indices: number[]; newSequence: number[] } {
  const currentSeqToUse =
    currentSequence && currentSequence.length === pageCount
      ? currentSequence
      : Array.from({ length: pageCount }, (_, i) => i + 1);

  // Check if all target labels exist in currentSequence and targetLabels has length === pageCount
  const allLabelsPresent =
    targetLabels.length === currentSeqToUse.length &&
    targetLabels.every((lbl) => currentSeqToUse.includes(lbl));

  if (allLabelsPresent) {
    const indices = targetLabels.map((lbl) => currentSeqToUse.indexOf(lbl) + 1);
    return { indices, newSequence: targetLabels };
  }

  // Fallback: assume targetLabels are 1-based indices of current pdfBuffer
  const validIndices = targetLabels.filter((n) => n >= 1 && n <= pageCount);
  if (validIndices.length === 0) {
    throw new Error('Please enter valid page numbers for reordering.');
  }
  const newSequence = validIndices.map((idx) => currentSeqToUse[idx - 1] ?? idx);
  return { indices: validIndices, newSequence };
}

/**
 * ROTATE pages in a PDF
 */
export async function rotatePages(
  buffer: ArrayBuffer,
  rotationAngle: number, // e.g. 90, 180, 270
  targetPages1Based?: number[] // if empty/undefined, rotate all pages
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const total = doc.getPageCount();
  const targets = targetPages1Based && targetPages1Based.length > 0
    ? new Set(targetPages1Based.map((n) => n - 1))
    : null;

  for (let i = 0; i < total; i++) {
    if (targets === null || targets.has(i)) {
      const page = doc.getPage(i);
      const currentRotation = page.getRotation().angle;
      page.setRotation(degrees((currentRotation + rotationAngle) % 360));
    }
  }
  return await doc.save();
}

/**
 * CROP a page in a PDF
 */
export async function cropPage(
  buffer: ArrayBuffer,
  pageIndex1Based: number,
  x: number,
  y: number,
  width: number,
  height: number
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const page = doc.getPage(pageIndex1Based - 1);
  page.setCropBox(x, y, width, height);
  return await doc.save();
}

/**
 * ADD PASSWORD / ENCRYPT PDF
 */
export async function addPasswordToPdf(
  buffer: ArrayBuffer,
  password: string,
  permissions?: {
    printing?: 'lowResolution' | 'highResolution' | 'none';
    modifying?: boolean;
    copying?: boolean;
    annotating?: boolean;
  }
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  if (typeof (doc as any).encrypt === 'function') {
    (doc as any).encrypt({
      userPassword: password,
      ownerPassword: password,
      permissions: {
        printing: permissions?.printing || 'highResolution',
        modifying: permissions?.modifying ?? true,
        copying: permissions?.copying ?? true,
        annotating: permissions?.annotating ?? true,
      },
    });
  }
  return await doc.save();
}

/**
 * Checks if raw PDF trailer/catalog contains /Encrypt dictionary
 */
export function isRawPdfEncrypted(bytes: Uint8Array): boolean {
  try {
    const len = Math.min(bytes.length, 65536);
    const endSlice = bytes.subarray(Math.max(0, bytes.length - len));
    const text = new TextDecoder('latin1').decode(endSlice);
    return /\/Encrypt\s+\d+\s+\d+\s+R/.test(text) || /\/Encrypt\s*<</.test(text);
  } catch {
    return false;
  }
}

/**
 * Detect if an error is caused by password protection or encryption
 */
export function isEncryptionError(err: any): boolean {
  if (!err) return false;
  const name = String(err?.name || '').toLowerCase();
  const message = String(err?.message || '').toLowerCase();

  return (
    name.includes('encrypted') ||
    name.includes('password') ||
    message.includes('encrypt') ||
    message.includes('password') ||
    message.includes('ignoreencryption') ||
    message.includes('cannot parse encrypted') ||
    message.includes('passwordresponses') ||
    message.includes('user password') ||
    message.includes('owner password') ||
    err?.code === 1 || // PasswordResponses.NEED_PASSWORD
    err?.code === 2    // PasswordResponses.INCORRECT_PASSWORD
  );
}

/**
 * Check if a PDF buffer is password-protected or encrypted
 */
export async function isPdfEncrypted(buffer: ArrayBuffer | Uint8Array): Promise<boolean> {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  try {
    // Normal load without ignoreEncryption will throw if password is required
    await PDFDocument.load(bytes);
    return false;
  } catch (err: any) {
    if (isEncryptionError(err)) {
      return true;
    }
    // Also check raw bytes
    return isRawPdfEncrypted(bytes);
  }
}

/**
 * Genuine unlock and decryption of a password-protected PDF using QPDF WebAssembly.
 * Supports RC4, AES-128, and AES-256 encrypted PDFs.
 */
export async function unlockAndDecryptPdf(
  buffer: ArrayBuffer | Uint8Array,
  password?: string
): Promise<{
  decryptedBuffer: ArrayBuffer;
  decryptedBytes: Uint8Array;
  pageCount: number;
}> {
  if (!password) {
    throw new Error('Please provide the password to decrypt this document.');
  }

  // 1. Decrypt using QPDF WebAssembly engine
  const decryptedBytes = await decryptPdfWithQpdf(buffer, password);

  // 2. Load into PDFDocument to verify structure and get page count
  const verifiedLibDoc = await PDFDocument.load(decryptedBytes);
  const pageCount = verifiedLibDoc.getPageCount();

  const decryptedBuffer = decryptedBytes.buffer.slice(
    decryptedBytes.byteOffset,
    decryptedBytes.byteOffset + decryptedBytes.byteLength
  );

  return {
    decryptedBuffer,
    decryptedBytes,
    pageCount,
  };
}

/**
 * REMOVE PASSWORD / DECRYPT PDF
 */
export async function removePasswordFromPdf(
  buffer: ArrayBuffer | Uint8Array,
  password?: string
): Promise<Uint8Array> {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  const isEnc = await isPdfEncrypted(bytes);
  if (isEnc) {
    if (!password) {
      throw new Error('This document is password-protected. Please provide the password to decrypt it.');
    }
    const result = await unlockAndDecryptPdf(bytes, password);
    return result.decryptedBytes;
  }
  const doc = await PDFDocument.load(bytes);
  return await doc.save();
}

/**
 * Sanitize text to ensure WinAnsiEncoding safety for PDF standard fonts
 */
export function sanitizeWinAnsi(str: string): string {
  if (!str) return '';
  return str.replace(/[^\x20-\x7E\xA0-\xFF]/g, (ch) => {
    if (ch === '💬') return '[Note]';
    if (ch === '’' || ch === '‘') return "'";
    if (ch === '“' || ch === '”') return '"';
    if (ch === '–' || ch === '—') return '-';
    if (ch === '…') return '...';
    return '';
  });
}

/**
 * ADD TEXT onto a PDF page
 */
export async function addTextToPage(
  buffer: ArrayBuffer,
  pageIndex1Based: number,
  text: string,
  x: number,
  y: number,
  fontSize: number = 14,
  fontColorHex: string = '#1B2740'
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const page = doc.getPage(pageIndex1Based - 1);
  const cleanText = sanitizeWinAnsi(text) || ' ';
  
  page.drawText(cleanText, {
    x,
    y,
    size: fontSize,
    font,
    color: hexToRgb(fontColorHex),
  });

  return await doc.save();
}

/**
 * ADD WATERMARK across all pages or target page (supports both Text & Image watermarks)
 */
export async function addWatermarkToPdf(
  buffer: ArrayBuffer,
  text?: string,
  imageBytes?: ArrayBuffer,
  opacity: number = 0.3,
  rotationDegrees: number = 45,
  targetPageIndex1Based?: number,
  fontSize: number = 48,
  colorHex: string = '#C4432E',
  xRatio: number = 0.5,
  yRatio: number = 0.5,
  imageWidthRatio: number = 0.45,
  imageFormat: 'jpg' | 'png' = 'png'
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const pages = doc.getPages();
  const font = await doc.embedFont(StandardFonts.HelveticaBold);

  let embeddedImg: any = null;
  if (imageBytes && imageBytes.byteLength > 0) {
    try {
      if (imageFormat === 'jpg') {
        embeddedImg = await doc.embedJpg(imageBytes);
      } else {
        embeddedImg = await doc.embedPng(imageBytes);
      }
    } catch {
      try {
        embeddedImg = await doc.embedPng(imageBytes);
      } catch {
        try {
          embeddedImg = await doc.embedJpg(imageBytes);
        } catch (embedErr) {
          console.error('Failed to embed watermark image bytes:', embedErr);
        }
      }
    }
  }

  const pagesToProcess =
    typeof targetPageIndex1Based === 'number' && targetPageIndex1Based > 0
      ? [pages[targetPageIndex1Based - 1]]
      : pages;

  const cleanWatermarkText = sanitizeWinAnsi(text || '') || 'WATERMARK';

  for (const page of pagesToProcess) {
    if (!page) continue;
    const { width, height } = page.getSize();
    if (embeddedImg) {
      const boundedWidthRatio = Math.max(0.05, Math.min(1.0, imageWidthRatio || 0.45));
      const imgWidth = width * boundedWidthRatio;
      const imgHeight = (embeddedImg.height / embeddedImg.width) * imgWidth;

      const pdfAngle = -rotationDegrees;
      const rad = pdfAngle * (Math.PI / 180);
      const cos = Math.cos(rad);
      const sin = Math.sin(rad);

      const centerX = width * xRatio;
      const centerY = height * (1 - yRatio);

      const dx = (imgWidth / 2) * cos - (imgHeight / 2) * sin;
      const dy = (imgWidth / 2) * sin + (imgHeight / 2) * cos;

      page.drawImage(embeddedImg, {
        x: centerX - dx,
        y: centerY - dy,
        width: imgWidth,
        height: imgHeight,
        opacity: Math.max(0.05, Math.min(1.0, opacity)),
        rotate: degrees(pdfAngle),
      });
    } else if (cleanWatermarkText) {
      const actualSize = Math.max(12, fontSize);
      const textWidth = font.widthOfTextAtSize(cleanWatermarkText, actualSize);
      // For Helvetica Bold, cap height + baseline offset is roughly actualSize * 0.70
      const textHeight = actualSize * 0.70;

      // PDF angle for clockwise CSS rotation: pdfAngle = -rotationDegrees
      const pdfAngle = -rotationDegrees;
      const rad = pdfAngle * (Math.PI / 180);
      const cos = Math.cos(rad);
      const sin = Math.sin(rad);

      // Target relative center position in PDF coordinate space (Y=0 is bottom)
      const centerX = width * xRatio;
      const centerY = height * (1 - yRatio);

      // Rotated offset from text bottom-left corner to its bounding box center
      const dx = (textWidth / 2) * cos - (textHeight / 2) * sin;
      const dy = (textWidth / 2) * sin + (textHeight / 2) * cos;

      // Bottom-left anchor for page.drawText
      const x = centerX - dx;
      const y = centerY - dy;

      page.drawText(cleanWatermarkText, {
        x,
        y,
        size: actualSize,
        font,
        color: hexToRgb(colorHex),
        opacity: Math.max(0.05, Math.min(1.0, opacity)),
        rotate: degrees(pdfAngle),
      });
    }
  }

  return await doc.save();
}

/**
 * Add an e-signature PNG image to a PDF page at exact relative position and scale
 */
export async function addSignatureToPdf(
  buffer: ArrayBuffer,
  imageDataUrl: string,
  targetPageIndex1Based: number = 1,
  xRatio: number = 0.5,
  yRatio: number = 0.5,
  widthRatio: number = 0.25
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const pages = doc.getPages();
  const pageIndex = Math.max(0, Math.min(pages.length - 1, targetPageIndex1Based - 1));
  const page = pages[pageIndex];

  if (!page) return new Uint8Array(buffer);

  // Convert base64 data URL to bytes
  const base64Data = imageDataUrl.replace(/^data:image\/(png|jpg|jpeg);base64,/, '');
  const imageBytes = Uint8Array.from(atob(base64Data), (c) => c.charCodeAt(0));

  let embeddedImg;
  try {
    embeddedImg = await doc.embedPng(imageBytes);
  } catch {
    embeddedImg = await doc.embedJpg(imageBytes);
  }

  const { width, height } = page.getSize();

  // Calculate dimensions in PDF points
  const sigWidth = width * Math.max(0.08, Math.min(0.9, widthRatio));
  const aspectRatio = embeddedImg.height / embeddedImg.width;
  const sigHeight = sigWidth * aspectRatio;

  // Center position in PDF coordinate system (Y=0 is bottom)
  const centerX = width * xRatio;
  const centerY = height * (1 - yRatio);

  const x = centerX - sigWidth / 2;
  const y = centerY - sigHeight / 2;

  page.drawImage(embeddedImg, {
    x,
    y,
    width: sigWidth,
    height: sigHeight,
  });

  return await doc.save();
}

/**
 * Detect whether an ArrayBuffer contains a JPEG or PNG image based on magic bytes or MIME type
 */
export function detectImageType(buffer: ArrayBuffer, mimeType?: string): 'jpg' | 'png' | null {
  const bytes = new Uint8Array(buffer);
  // PNG magic bytes: 89 50 4E 47 0D 0A 1A 0A
  if (
    bytes.length >= 8 &&
    bytes[0] === 0x89 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x4E &&
    bytes[3] === 0x47 &&
    bytes[4] === 0x0D &&
    bytes[5] === 0x0A &&
    bytes[6] === 0x1A &&
    bytes[7] === 0x0A
  ) {
    return 'png';
  }
  // JPEG magic bytes: FF D8 FF
  if (bytes.length >= 3 && bytes[0] === 0xFF && bytes[1] === 0xD8 && bytes[2] === 0xFF) {
    return 'jpg';
  }
  if (mimeType?.toLowerCase().includes('png')) return 'png';
  if (mimeType?.toLowerCase().includes('jpeg') || mimeType?.toLowerCase().includes('jpg')) return 'jpg';
  return null;
}

/**
 * Crop an image via HTML5 Canvas given fractional bounding box ratios (0..1)
 */
export async function cropImageToBuffer(
  sourceDataUrl: string,
  cropRatio: { x: number; y: number; width: number; height: number },
  format: 'jpg' | 'png' = 'png'
): Promise<{ buffer: ArrayBuffer; dataUrl: string; width: number; height: number; aspectRatio: number }> {
  return new Promise((resolve, reject) => {
    if (!sourceDataUrl) {
      reject(new Error('No image source provided for cropping'));
      return;
    }

    const img = new Image();
    // Only set crossOrigin for remote HTTP(S) URLs; data URLs fail in some browsers with crossOrigin
    if (sourceDataUrl.startsWith('http://') || sourceDataUrl.startsWith('https://')) {
      img.crossOrigin = 'anonymous';
    }

    img.onload = () => {
      try {
        const naturalW = img.naturalWidth || img.width;
        const naturalH = img.naturalHeight || img.height;

        if (!naturalW || !naturalH) {
          reject(new Error('Invalid image dimensions'));
          return;
        }

        // Clamp fractional ratios strictly within [0, 1]
        const clampedX = Math.max(0, Math.min(0.99, cropRatio.x));
        const clampedY = Math.max(0, Math.min(0.99, cropRatio.y));
        const clampedW = Math.max(0.01, Math.min(1 - clampedX, cropRatio.width));
        const clampedH = Math.max(0.01, Math.min(1 - clampedY, cropRatio.height));

        // Calculate pixel crop coordinates
        const sx = Math.max(0, Math.min(naturalW - 1, Math.floor(clampedX * naturalW)));
        const sy = Math.max(0, Math.min(naturalH - 1, Math.floor(clampedY * naturalH)));
        const sWidth = Math.max(1, Math.min(naturalW - sx, Math.ceil(clampedW * naturalW)));
        const sHeight = Math.max(1, Math.min(naturalH - sy, Math.ceil(clampedH * naturalH)));

        const canvas = document.createElement('canvas');
        canvas.width = sWidth;
        canvas.height = sHeight;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas 2D context not available'));
          return;
        }

        // Clean high quality drawing
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';

        // If JPG, fill white background to avoid transparent black artifacts
        if (format === 'jpg') {
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, sWidth, sHeight);
        }

        ctx.drawImage(img, sx, sy, sWidth, sHeight, 0, 0, sWidth, sHeight);

        const mimeType = format === 'jpg' ? 'image/jpeg' : 'image/png';
        const croppedDataUrl = canvas.toDataURL(mimeType, 0.95);

        // Convert base64 data URL to ArrayBuffer synchronously & reliably
        try {
          const base64Data = croppedDataUrl.split(',')[1];
          const binaryString = atob(base64Data);
          const len = binaryString.length;
          const bytes = new Uint8Array(len);
          for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          resolve({
            buffer: bytes.buffer,
            dataUrl: croppedDataUrl,
            width: sWidth,
            height: sHeight,
            aspectRatio: sWidth / sHeight,
          });
        } catch {
          // Fallback to canvas.toBlob
          canvas.toBlob(
            (blob) => {
              if (!blob) {
                reject(new Error('Failed to create cropped image blob'));
                return;
              }
              const reader = new FileReader();
              reader.onload = () => {
                const buffer = reader.result as ArrayBuffer;
                resolve({
                  buffer,
                  dataUrl: croppedDataUrl,
                  width: sWidth,
                  height: sHeight,
                  aspectRatio: sWidth / sHeight,
                });
              };
              reader.onerror = reject;
              reader.readAsArrayBuffer(blob);
            },
            mimeType,
            0.95
          );
        }
      } catch (err) {
        reject(err);
      }
    };

    img.onerror = () => reject(new Error('Failed to load image for cropping'));
    img.src = sourceDataUrl;
  });
}

/**
 * Add an image (JPG or PNG) to a PDF page at exact relative position, size, rotation, and opacity
 */
export async function addImageToPdf(
  buffer: ArrayBuffer,
  imageBytes: ArrayBuffer,
  targetPageIndex1Based: number = 1,
  xRatio: number = 0.5,
  yRatio: number = 0.5,
  widthRatio: number = 0.3,
  rotation: number = 0,
  opacity: number = 1.0,
  imageFormat?: 'jpg' | 'png'
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const pages = doc.getPages();
  const pageIndex = Math.max(0, Math.min(pages.length - 1, targetPageIndex1Based - 1));
  const page = pages[pageIndex];

  if (!page) return new Uint8Array(buffer);

  let embeddedImg;
  const detectedFormat = imageFormat || detectImageType(imageBytes) || 'png';

  if (detectedFormat === 'png') {
    try {
      embeddedImg = await doc.embedPng(imageBytes);
    } catch {
      embeddedImg = await doc.embedJpg(imageBytes);
    }
  } else {
    try {
      embeddedImg = await doc.embedJpg(imageBytes);
    } catch {
      embeddedImg = await doc.embedPng(imageBytes);
    }
  }

  const { width, height } = page.getSize();

  // Clamp widthRatio safely (5% to 95% of page width)
  const clampedWidthRatio = Math.max(0.05, Math.min(0.95, widthRatio));
  const pdfImgWidth = width * clampedWidthRatio;
  const aspectRatio = embeddedImg.height / embeddedImg.width;
  const pdfImgHeight = pdfImgWidth * aspectRatio;

  // Center position in PDF coordinate space (Y=0 is bottom)
  const centerX = width * xRatio;
  const centerY = height * (1 - yRatio);

  const safeOpacity = Math.max(0.05, Math.min(1.0, opacity ?? 1.0));

  if (!rotation || rotation === 0) {
    page.drawImage(embeddedImg, {
      x: centerX - pdfImgWidth / 2,
      y: centerY - pdfImgHeight / 2,
      width: pdfImgWidth,
      height: pdfImgHeight,
      opacity: safeOpacity,
    });
  } else {
    // In pdf-lib, counter-clockwise is positive, CSS clockwise is positive -> pdfAngle = -rotation
    const pdfAngle = -rotation;
    const rad = pdfAngle * (Math.PI / 180);
    const cos = Math.cos(rad);
    const sin = Math.sin(rad);

    // Rotated offset from center to bottom-left corner
    const x = centerX - (pdfImgWidth / 2) * cos + (pdfImgHeight / 2) * sin;
    const y = centerY - (pdfImgWidth / 2) * sin - (pdfImgHeight / 2) * cos;

    page.drawImage(embeddedImg, {
      x,
      y,
      width: pdfImgWidth,
      height: pdfImgHeight,
      opacity: safeOpacity,
      rotate: degrees(pdfAngle),
    });
  }

  return await doc.save();
}

/**
 * ADD PAGE NUMBERS across all pages with customizable options
 */
export interface PageNumberOptions {
  position?: 'bottom-center' | 'bottom-right' | 'bottom-left' | 'top-center' | 'top-right' | 'top-left';
  format?: 'page_x_of_n' | 'x_slash_n' | 'just_x' | 'dash_x_dash';
  fontSize?: number;
  color?: string;
  startPage?: number;
  skipFirstPage?: boolean;
  marginPt?: number;
}

export async function addPageNumbersToPdf(
  buffer: ArrayBuffer,
  optionsOrPosition: PageNumberOptions | string = {}
): Promise<Uint8Array> {
  const options: PageNumberOptions =
    typeof optionsOrPosition === 'string'
      ? { position: optionsOrPosition as any }
      : optionsOrPosition;

  const {
    position = 'bottom-center',
    format = 'page_x_of_n',
    fontSize = 10,
    color = '#1B2740',
    startPage = 1,
    skipFirstPage = false,
    marginPt = 25,
  } = options;

  const doc = await PDFDocument.load(buffer);
  const pages = doc.getPages();
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const totalPages = pages.length;

  pages.forEach((page, idx) => {
    if (skipFirstPage && idx === 0) return;

    const { width, height } = page.getSize();
    const displayNum = (idx + (skipFirstPage ? 0 : 1)) + (startPage - 1);

    let str = `Page ${displayNum} of ${totalPages}`;
    if (format === 'x_slash_n') {
      str = `${displayNum} / ${totalPages}`;
    } else if (format === 'just_x') {
      str = `${displayNum}`;
    } else if (format === 'dash_x_dash') {
      str = `- ${displayNum} -`;
    }

    const textWidth = font.widthOfTextAtSize(str, fontSize);

    let x = (width - textWidth) / 2;
    let y = marginPt;

    switch (position) {
      case 'bottom-center':
        x = (width - textWidth) / 2;
        y = marginPt;
        break;
      case 'bottom-right':
        x = width - textWidth - marginPt;
        y = marginPt;
        break;
      case 'bottom-left':
        x = marginPt;
        y = marginPt;
        break;
      case 'top-center':
        x = (width - textWidth) / 2;
        y = height - marginPt - fontSize;
        break;
      case 'top-right':
        x = width - textWidth - marginPt;
        y = height - marginPt - fontSize;
        break;
      case 'top-left':
        x = marginPt;
        y = height - marginPt - fontSize;
        break;
    }

    page.drawText(str, {
      x,
      y,
      size: fontSize,
      font,
      color: hexToRgb(color),
    });
  });

  return await doc.save();
}

/**
 * ADD IMAGE onto a page
 */
export async function addImageToPage(
  buffer: ArrayBuffer,
  pageIndex1Based: number,
  imageBuffer: ArrayBuffer,
  x: number,
  y: number,
  width: number,
  height: number
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  let embeddedImg: any;
  try {
    embeddedImg = await doc.embedPng(imageBuffer);
  } catch {
    embeddedImg = await doc.embedJpg(imageBuffer);
  }

  const page = doc.getPage(pageIndex1Based - 1);
  page.drawImage(embeddedImg, {
    x,
    y,
    width,
    height,
  });

  return await doc.save();
}

/**
 * ADD HEADERS AND FOOTERS
 */
export async function addHeadersAndFootersToPdf(
  buffer: ArrayBuffer,
  headerText?: string,
  footerText?: string
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const font = await doc.embedFont(StandardFonts.Helvetica);
  const pages = doc.getPages();

  const cleanHeader = sanitizeWinAnsi(headerText || '');
  const cleanFooter = sanitizeWinAnsi(footerText || '');

  pages.forEach((page) => {
    const { width, height } = page.getSize();
    const fontSize = 10;

    if (cleanHeader) {
      const hWidth = font.widthOfTextAtSize(cleanHeader, fontSize);
      page.drawText(cleanHeader, {
        x: (width - hWidth) / 2,
        y: height - 25,
        size: fontSize,
        font,
        color: hexToRgb('#1B2740'),
      });
    }

    if (cleanFooter) {
      const fWidth = font.widthOfTextAtSize(cleanFooter, fontSize);
      page.drawText(cleanFooter, {
        x: (width - fWidth) / 2,
        y: 20,
        size: fontSize,
        font,
        color: hexToRgb('#6B7280'),
      });
    }
  });

  return await doc.save();
}

/**
 * EMBED SIGNATURE onto a page
 */
export async function embedSignatureOnPage(
  buffer: ArrayBuffer,
  pageIndex1Based: number,
  signaturePngBytes: ArrayBuffer,
  x: number,
  y: number,
  width: number = 180,
  height: number = 60
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const embeddedImg = await doc.embedPng(signaturePngBytes);
  const page = doc.getPage(pageIndex1Based - 1);

  page.drawImage(embeddedImg, {
    x,
    y,
    width,
    height,
  });

  return await doc.save();
}

/**
 * GET ACROFORM FIELDS
 */
export async function getAcroFormFields(buffer: ArrayBuffer): Promise<AcroFormFieldInfo[]> {
  try {
    const doc = await PDFDocument.load(buffer);
    const form = doc.getForm();
    const fields = form.getFields();
    return fields.map((field) => {
      const name = field.getName();
      const fieldType = field.constructor.name;
      let type: AcroFormFieldInfo['type'] = 'text';
      let value = '';

      if (fieldType.includes('Text')) {
        type = 'text';
        try { value = (field as any).getText() || ''; } catch {}
      } else if (fieldType.includes('CheckBox')) {
        type = 'checkbox';
        try { value = (field as any).isChecked() ? 'true' : 'false'; } catch {}
      } else if (fieldType.includes('Radio')) {
        type = 'radio';
        try { value = (field as any).getSelected() || ''; } catch {}
      } else if (fieldType.includes('Dropdown') || fieldType.includes('Option')) {
        type = 'dropdown';
        try { value = (field as any).getSelected()?.[0] || ''; } catch {}
      }

      return {
        name,
        type,
        value,
      };
    });
  } catch {
    return [];
  }
}

/**
 * FILL ACROFORM FIELDS
 */
export async function fillAcroForm(
  buffer: ArrayBuffer,
  fieldValues: Record<string, string>
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  try {
    const form = doc.getForm();

    Object.entries(fieldValues).forEach(([fieldName, val]) => {
      try {
        const field = form.getField(fieldName);
        if ((field as any).setText) {
          (field as any).setText(val);
        } else if ((field as any).check && (field as any).uncheck) {
          if (val === 'true') (field as any).check();
          else (field as any).uncheck();
        } else if ((field as any).select) {
          (field as any).select(val);
        }
      } catch (e) {
        console.warn(`Could not set field ${fieldName}`, e);
      }
    });
  } catch (e) {
    console.warn('Document has no AcroForm', e);
  }

  return await doc.save();
}

/**
 * ADD HIGHLIGHT / ANNOTATIONS
 */
export async function addHighlightToPage(
  buffer: ArrayBuffer,
  pageIndex1Based: number,
  x: number,
  y: number,
  width: number,
  height: number,
  colorHex: string = '#FFE066'
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const page = doc.getPage(pageIndex1Based - 1);

  page.drawRectangle({
    x,
    y,
    width,
    height,
    color: hexToRgb(colorHex),
    opacity: 0.4,
  });

  return await doc.save();
}

/**
 * ADD UNDERLINE / STRIKETHROUGH
 */
export async function addUnderlineLine(
  buffer: ArrayBuffer,
  pageIndex1Based: number,
  x: number,
  y: number,
  width: number,
  colorHex: string = '#1B2740',
  thickness: number = 2
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const page = doc.getPage(pageIndex1Based - 1);

  page.drawLine({
    start: { x, y },
    end: { x: x + width, y },
    thickness,
    color: hexToRgb(colorHex),
  });

  return await doc.save();
}

/**
 * ADD COMMENT STICKY NOTE
 */
export async function addCommentNoteToPage(
  buffer: ArrayBuffer,
  pageIndex1Based: number,
  x: number,
  y: number,
  commentText: string
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  const page = doc.getPage(pageIndex1Based - 1);
  const font = await doc.embedFont(StandardFonts.Helvetica);

  // Draw sticky box icon
  page.drawRectangle({
    x,
    y,
    width: 20,
    height: 20,
    color: hexToRgb('#FFD166'),
    borderColor: hexToRgb('#C4432E'),
    borderWidth: 1,
  });

  page.drawText('!', {
    x: x + 8,
    y: y + 5,
    size: 12,
    font,
    color: hexToRgb('#C4432E'),
  });

  const cleanNote = sanitizeWinAnsi(commentText) || 'Note';

  // Render note text next to icon
  page.drawText(cleanNote, {
    x: x + 26,
    y: y + 5,
    size: 10,
    font,
    color: hexToRgb('#1B2740'),
  });

  return await doc.save();
}

export interface CompressResult {
  bytes: Uint8Array;
  originalSize: number;
  compressedSize: number;
  reductionPercentage: number;
}

export interface CompressIterationProgress {
  iteration: number;
  totalIterations: number;
  currentSize?: number;
  targetSize: number;
  percent: number;
  stage: string;
}

export interface CompressTargetResult {
  bytes: Uint8Array;
  originalSize: number;
  targetSize: number;
  finalSize: number;
  reductionPercentage: number;
  targetAchieved: boolean;
  bestAchievableSize: number;
  qualityDescription: string;
  statusMessage: string;
  iterationsCount: number;
}

export interface CompressionProfile {
  name: string;
  scale: number;
  quality: number;
  dpiEstimate: number;
  description: string;
}

export const TARGET_COMPRESSION_PROFILES: CompressionProfile[] = [
  { name: 'Ultra High Clarity', scale: 1.75, quality: 0.85, dpiEstimate: 126, description: 'Near-original vector clarity with lossless text smoothing' },
  { name: 'Very High Clarity', scale: 1.50, quality: 0.80, dpiEstimate: 108, description: 'Crystal-clear text and high-res imagery' },
  { name: 'High Clarity', scale: 1.35, quality: 0.75, dpiEstimate: 97, description: 'Crisp, razor-sharp reading experience' },
  { name: 'Standard High', scale: 1.20, quality: 0.70, dpiEstimate: 86, description: 'Standard publishing density with balanced file size' },
  { name: 'Balanced', scale: 1.05, quality: 0.62, dpiEstimate: 75, description: 'Balanced optimization for email and web viewing' },
  { name: 'Medium Compression', scale: 0.95, quality: 0.55, dpiEstimate: 68, description: 'Optimized compression with clear legibility' },
  { name: 'High Compression', scale: 0.85, quality: 0.48, dpiEstimate: 61, description: 'Strong size reduction while maintaining readable text' },
  { name: 'Aggressive Compression', scale: 0.75, quality: 0.40, dpiEstimate: 54, description: 'High compression with compact footprint' },
  { name: 'Maximum Acceptable', scale: 0.68, quality: 0.32, dpiEstimate: 49, description: 'Maximum achievable reduction threshold' },
];

export function formatFileSize(bytes: number): string {
  if (bytes >= 1024 * 1024) {
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  }
  return `${(bytes / 1024).toFixed(1)} KB`;
}

/**
 * Render PDF pages with given scale & quality settings and return bundled PDF bytes
 */
export async function renderAndCompressPdfDoc(
  pdfBuffer: ArrayBuffer,
  scale: number,
  quality: number,
  isCancelled?: () => boolean,
  onPageProgress?: (current: number, total: number) => void
): Promise<Uint8Array> {
  const jsDoc = await loadPdfJsDoc(pdfBuffer);
  const numPages = jsDoc.numPages;
  const newDoc = await PDFDocument.create();

  for (let pageNum = 1; pageNum <= numPages; pageNum++) {
    if (isCancelled?.()) {
      throw new Error('COMPRESSION_CANCELLED');
    }
    const page = await jsDoc.getPage(pageNum);
    const viewport = page.getViewport({ scale });

    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.floor(viewport.width));
    canvas.height = Math.max(1, Math.floor(viewport.height));

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      await page.render({ canvasContext: ctx, viewport } as any).promise;

      const jpegDataUrl = canvas.toDataURL('image/jpeg', quality);
      const base64Data = jpegDataUrl.split(',')[1];
      const binaryStr = atob(base64Data);
      const imgBytes = new Uint8Array(binaryStr.length);
      for (let k = 0; k < binaryStr.length; k++) {
        imgBytes[k] = binaryStr.charCodeAt(k);
      }

      const embeddedImage = await newDoc.embedJpg(imgBytes);
      const origViewport = page.getViewport({ scale: 1.0 });
      const newPage = newDoc.addPage([origViewport.width, origViewport.height]);
      newPage.drawImage(embeddedImage, {
        x: 0,
        y: 0,
        width: origViewport.width,
        height: origViewport.height,
      });
    }

    if (onPageProgress) {
      onPageProgress(pageNum, numPages);
    }
    // Yield to the browser event loop for responsiveness & instant cancellation
    await new Promise((resolve) => setTimeout(resolve, 0));
  }

  if (isCancelled?.()) {
    throw new Error('COMPRESSION_CANCELLED');
  }

  return await newDoc.save({ useObjectStreams: true });
}

/**
 * COMPRESS PDF TO TARGET MAXIMUM SIZE (≤ target)
 * Iterative / binary-search style optimization across visual quality profiles.
 * Preserves highest possible visual quality while guaranteeing target size constraint.
 */
export async function compressToTargetSize(
  pdfBuffer: ArrayBuffer,
  targetSizeBytes: number,
  options?: {
    onProgress?: (progress: CompressIterationProgress) => void;
    isCancelled?: () => boolean;
  }
): Promise<CompressTargetResult> {
  const originalSize = pdfBuffer.byteLength;
  const isCancelled = options?.isCancelled;
  const onProgress = options?.onProgress;

  if (targetSizeBytes <= 0) {
    throw new Error('Target size must be greater than 0.');
  }

  // If already under target size, perform fast lossless stream compression
  if (originalSize <= targetSizeBytes) {
    let losslessBytes: Uint8Array | null = null;
    try {
      const doc = await PDFDocument.load(pdfBuffer, { ignoreEncryption: true });
      doc.setTitle('');
      doc.setAuthor('');
      doc.setSubject('');
      doc.setKeywords([]);
      doc.setCreator('');
      doc.setProducer('');
      losslessBytes = await doc.save({ useObjectStreams: true, addDefaultPage: false, updateFieldAppearances: false });
    } catch {}

    const finalBytes = losslessBytes || new Uint8Array(pdfBuffer);
    const finalSize = finalBytes.byteLength;
    const reductionPercentage = Math.max(0, Math.round(((originalSize - finalSize) / originalSize) * 100 * 10) / 10);

    return {
      bytes: finalBytes,
      originalSize,
      targetSize: targetSizeBytes,
      finalSize,
      reductionPercentage,
      targetAchieved: true,
      bestAchievableSize: finalSize,
      qualityDescription: '100% Lossless Vector Quality (Original already within target)',
      statusMessage: `Original PDF is already within the requested target size of ${formatFileSize(targetSizeBytes)}.`,
      iterationsCount: 1,
    };
  }

  // --- PASS 1: Check Lossless Stream Compression ---
  onProgress?.({
    iteration: 1,
    totalIterations: 5,
    percent: 15,
    stage: 'Evaluating Lossless Vector & Stream Optimization...',
    targetSize: targetSizeBytes,
  });

  let pass1Bytes: Uint8Array | null = null;
  try {
    const doc = await PDFDocument.load(pdfBuffer, { ignoreEncryption: true });
    doc.setTitle('');
    doc.setAuthor('');
    doc.setSubject('');
    doc.setKeywords([]);
    doc.setCreator('');
    doc.setProducer('');
    pass1Bytes = await doc.save({
      useObjectStreams: true,
      addDefaultPage: false,
      updateFieldAppearances: false,
    });
  } catch (e) {
    console.warn('Pass 1 error:', e);
  }

  if (isCancelled?.()) throw new Error('COMPRESSION_CANCELLED');

  if (pass1Bytes && pass1Bytes.byteLength <= targetSizeBytes) {
    const finalSize = pass1Bytes.byteLength;
    const reductionPercentage = Math.max(0, Math.round(((originalSize - finalSize) / originalSize) * 100 * 10) / 10);
    return {
      bytes: pass1Bytes,
      originalSize,
      targetSize: targetSizeBytes,
      finalSize,
      reductionPercentage,
      targetAchieved: true,
      bestAchievableSize: finalSize,
      qualityDescription: '100% Lossless Vector Stream (Zero quality degradation)',
      statusMessage: `Target achieved with 100% lossless vector quality.`,
      iterationsCount: 1,
    };
  }

  // --- PASS 2: ITERATIVE / BINARY-SEARCH COMPRESSION OVER QUALITY SPACE ---
  const profiles = TARGET_COMPRESSION_PROFILES;
  let low = 0; // Highest quality profile index
  let high = profiles.length - 1; // Lowest quality profile index
  let bestCandidate: { bytes: Uint8Array; size: number; profile: CompressionProfile; iteration: number } | null = null;
  let smallestGenerated: { bytes: Uint8Array; size: number; profile: CompressionProfile } | null = null;

  let iterationCount = 0;
  const maxIterations = 5;

  // Binary search to find lowest index (highest quality) where size <= targetSizeBytes
  while (low <= high && iterationCount < maxIterations) {
    if (isCancelled?.()) throw new Error('COMPRESSION_CANCELLED');

    const mid = Math.floor((low + high) / 2);
    const profile = profiles[mid];
    iterationCount++;

    onProgress?.({
      iteration: iterationCount,
      totalIterations: maxIterations,
      percent: Math.round((iterationCount / (maxIterations + 1)) * 100),
      stage: `Testing ${profile.name} (~${profile.dpiEstimate} DPI @ ${Math.round(profile.quality * 100)}% quality)...`,
      targetSize: targetSizeBytes,
      currentSize: bestCandidate?.size || smallestGenerated?.size,
    });

    const candidateBytes = await renderAndCompressPdfDoc(
      pdfBuffer,
      profile.scale,
      profile.quality,
      isCancelled,
      (currPage, totalPages) => {
        const pagePct = Math.round(((currPage / totalPages) * 100));
        onProgress?.({
          iteration: iterationCount,
          totalIterations: maxIterations,
          percent: Math.round(((iterationCount - 1 + currPage / totalPages) / (maxIterations + 1)) * 100),
          stage: `Testing ${profile.name} (Page ${currPage}/${totalPages} - ${pagePct}%)...`,
          targetSize: targetSizeBytes,
          currentSize: bestCandidate?.size || smallestGenerated?.size,
        });
      }
    );

    const candidateSize = candidateBytes.byteLength;

    if (!smallestGenerated || candidateSize < smallestGenerated.size) {
      smallestGenerated = { bytes: candidateBytes, size: candidateSize, profile };
    }

    if (candidateSize <= targetSizeBytes) {
      // Meets target! Record as candidate, then try to search higher quality (lower index)
      bestCandidate = { bytes: candidateBytes, size: candidateSize, profile, iteration: iterationCount };
      high = mid - 1;
    } else {
      // Exceeds target, need stronger compression (higher index)
      low = mid + 1;
    }
  }

  // Optional Fine-Tuning Step if target was met
  if (bestCandidate && bestCandidate.size <= targetSizeBytes && iterationCount < maxIterations) {
    // If the candidate is significantly below target and not at profile 0, we can test a slightly higher quality
    const headroom = targetSizeBytes - bestCandidate.size;
    if (headroom > 0.15 * targetSizeBytes && bestCandidate.profile.quality < 0.85) {
      const fineQuality = Math.min(0.88, bestCandidate.profile.quality + 0.08);
      iterationCount++;
      onProgress?.({
        iteration: iterationCount,
        totalIterations: maxIterations,
        percent: 90,
        stage: `Fine-tuning quality to ${Math.round(fineQuality * 100)}%...`,
        targetSize: targetSizeBytes,
        currentSize: bestCandidate.size,
      });

      try {
        const fineBytes = await renderAndCompressPdfDoc(
          pdfBuffer,
          bestCandidate.profile.scale,
          fineQuality,
          isCancelled
        );
        if (fineBytes.byteLength <= targetSizeBytes) {
          bestCandidate = {
            bytes: fineBytes,
            size: fineBytes.byteLength,
            profile: { ...bestCandidate.profile, quality: fineQuality, name: `${bestCandidate.profile.name} (Enhanced)` },
            iteration: iterationCount,
          };
        }
      } catch (err: any) {
        if (err.message === 'COMPRESSION_CANCELLED') throw err;
      }
    }
  }

  onProgress?.({
    iteration: iterationCount,
    totalIterations: iterationCount,
    percent: 100,
    stage: 'Finalizing compressed document...',
    targetSize: targetSizeBytes,
    currentSize: bestCandidate ? bestCandidate.size : smallestGenerated?.size,
  });

  if (bestCandidate && bestCandidate.size <= targetSizeBytes) {
    const finalSize = bestCandidate.size;
    const reductionPercentage = Math.max(0, Math.round(((originalSize - finalSize) / originalSize) * 100 * 10) / 10);
    return {
      bytes: bestCandidate.bytes,
      originalSize,
      targetSize: targetSizeBytes,
      finalSize,
      reductionPercentage,
      targetAchieved: true,
      bestAchievableSize: finalSize,
      qualityDescription: `${bestCandidate.profile.name} (~${bestCandidate.profile.dpiEstimate} DPI, ${Math.round(bestCandidate.profile.quality * 100)}% Quality)`,
      statusMessage: `Target achieved: ${formatFileSize(finalSize)} ≤ ${formatFileSize(targetSizeBytes)} (${reductionPercentage}% reduction).`,
      iterationsCount: iterationCount,
    };
  }

  // If target could NOT be reached without unacceptable quality loss
  const fallback = smallestGenerated || (pass1Bytes ? { bytes: pass1Bytes, size: pass1Bytes.byteLength, profile: profiles[profiles.length - 1] } : null);
  const fallbackBytes = fallback ? fallback.bytes : new Uint8Array(pdfBuffer);
  const fallbackSize = fallbackBytes.byteLength;
  const reductionPercentage = Math.max(0, Math.round(((originalSize - fallbackSize) / originalSize) * 100 * 10) / 10);

  return {
    bytes: fallbackBytes,
    originalSize,
    targetSize: targetSizeBytes,
    finalSize: fallbackSize,
    reductionPercentage,
    targetAchieved: false,
    bestAchievableSize: fallbackSize,
    qualityDescription: `Minimum Readable Threshold (~${profiles[profiles.length - 1].dpiEstimate} DPI)`,
    statusMessage: `Best achievable size: ${formatFileSize(fallbackSize)}. The requested target of ${formatFileSize(targetSizeBytes)} could not be reached without unacceptable quality loss.`,
    iterationsCount: iterationCount,
  };
}

/**
 * HIGH-CLARITY INTELLIGENT PDF COMPRESSOR
 * Guarantees zero text blurriness/pixelation while achieving real size reduction.
 * Dual-Pass Engine:
 * - Pass 1: Vector/Stream Object Optimization (100% loss-free vector text & metadata stream compression)
 * - Pass 2: High-Resolution Retina Rendering (scale 1.3-1.8, high-smoothing JPEG) for graphics/image-heavy PDFs
 * Automatically selects the smallest output that preserves sharp document quality.
 */
export async function compressPdf(
  pdfBuffer: ArrayBuffer,
  ratioPercent: number = 50
): Promise<CompressResult> {
  const originalSize = pdfBuffer.byteLength;
  const targetRatio = Math.min(85, Math.max(10, ratioPercent));

  // --- PASS 1: LOSSLESS VECTOR & STREAM STRUCTURE COMPRESSION ---
  let pass1Bytes: Uint8Array | null = null;
  try {
    const doc = await PDFDocument.load(pdfBuffer, { ignoreEncryption: true });
    
    // Clean redundant metadata streams
    doc.setTitle('');
    doc.setAuthor('');
    doc.setSubject('');
    doc.setKeywords([]);
    doc.setCreator('');
    doc.setProducer('');

    pass1Bytes = await doc.save({
      useObjectStreams: true,
      addDefaultPage: false,
      updateFieldAppearances: false,
    });
  } catch (err) {
    console.warn('Pass 1 compression error:', err);
  }

  const pass1Size = pass1Bytes ? pass1Bytes.byteLength : originalSize;

  // --- PASS 2: RETINA HIGH-CLARITY PAGE COMPRESSION (FOR HEAVY IMAGES/MEDIA) ---
  let pass2Bytes: Uint8Array | null = null;
  try {
    const jsDoc = await loadPdfJsDoc(pdfBuffer);
    const numPages = jsDoc.numPages;
    const newDoc = await PDFDocument.create();

    // High clarity scale (1.3 to 1.8) ensures text is crisp, legible, and non-blurry
    // Quality (0.60 to 0.85) produces clean JPEG compression without ugly pixelation artifacts
    const scale = Math.max(1.3, Math.min(1.8, 2.0 - (targetRatio / 100) * 0.8));
    const quality = Math.max(0.55, Math.min(0.85, 0.90 - (targetRatio / 100) * 0.35));

    for (let pageNum = 1; pageNum <= numPages; pageNum++) {
      const page = await jsDoc.getPage(pageNum);
      const viewport = page.getViewport({ scale });

      const canvas = document.createElement('canvas');
      canvas.width = Math.floor(viewport.width);
      canvas.height = Math.floor(viewport.height);

      const ctx = canvas.getContext('2d');
      if (ctx) {
        // High quality rendering settings
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        await page.render({ canvasContext: ctx, viewport } as any).promise;

        const jpegDataUrl = canvas.toDataURL('image/jpeg', quality);
        const base64Data = jpegDataUrl.split(',')[1];
        const binaryStr = atob(base64Data);
        const imgBytes = new Uint8Array(binaryStr.length);
        for (let k = 0; k < binaryStr.length; k++) {
          imgBytes[k] = binaryStr.charCodeAt(k);
        }

        const embeddedImage = await newDoc.embedJpg(imgBytes);
        const origViewport = page.getViewport({ scale: 1.0 });
        const newPage = newDoc.addPage([origViewport.width, origViewport.height]);
        newPage.drawImage(embeddedImage, {
          x: 0,
          y: 0,
          width: origViewport.width,
          height: origViewport.height,
        });
      }
    }

    pass2Bytes = await newDoc.save({ useObjectStreams: true });
  } catch (err) {
    console.warn('Pass 2 compression error:', err);
  }

  const pass2Size = pass2Bytes ? pass2Bytes.byteLength : Infinity;

  // --- SELECTION ENGINE: GUARANTEE SIZE REDUCTION AND MAXIMUM QUALITY ---
  let chosenBytes: Uint8Array;
  let chosenSize: number;

  // If user requested light/moderate compression OR if Pass 1 vector compression already achieved reduction
  if (pass1Size < originalSize && (targetRatio <= 25 || pass1Size <= pass2Size)) {
    chosenBytes = pass1Bytes!;
    chosenSize = pass1Size;
  } else if (pass2Size < originalSize && pass2Size < pass1Size) {
    chosenBytes = pass2Bytes!;
    chosenSize = pass2Size;
  } else if (pass1Bytes && pass1Size < originalSize) {
    chosenBytes = pass1Bytes;
    chosenSize = pass1Size;
  } else {
    // If file is already fully compressed and cannot be reduced without quality loss
    chosenBytes = pass1Bytes || new Uint8Array(pdfBuffer);
    chosenSize = Math.min(originalSize, pass1Size);
  }

  const bytesSaved = Math.max(0, originalSize - chosenSize);
  const reductionPercentage =
    originalSize > 0
      ? Math.max(0, Math.round((bytesSaved / originalSize) * 100 * 10) / 10)
      : 0;

  return {
    bytes: chosenBytes,
    originalSize,
    compressedSize: chosenSize,
    reductionPercentage,
  };
}

export async function compressPdfDoc(
  buffer: ArrayBuffer,
  level: 'extreme' | 'recommended' | 'high' = 'recommended'
): Promise<CompressResult> {
  const levelRatioMap = {
    extreme: 75,
    recommended: 50,
    high: 25,
  };
  return compressPdf(buffer, levelRatioMap[level] || 50);
}

/**
 * REPAIR PDF by reloading & re-saving
 */
export async function repairPdfDoc(buffer: ArrayBuffer): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer, { ignoreEncryption: true });
  return await doc.save();
}

/**
 * METADATA OPERATIONS
 */
export async function getPdfMetadata(buffer: ArrayBuffer): Promise<PDFMetadata> {
  const doc = await PDFDocument.load(buffer);
  return {
    title: doc.getTitle() || '',
    author: doc.getAuthor() || '',
    subject: doc.getSubject() || '',
    keywords: doc.getKeywords() ? doc.getKeywords()!.split(',') : [],
    creator: doc.getCreator() || '',
    producer: doc.getProducer() || '',
  };
}

export async function updatePdfMetadata(
  buffer: ArrayBuffer,
  meta: { title?: string; author?: string; subject?: string; keywords?: string }
): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  if (meta.title !== undefined) doc.setTitle(meta.title);
  if (meta.author !== undefined) doc.setAuthor(meta.author);
  if (meta.subject !== undefined) doc.setSubject(meta.subject);
  if (meta.keywords !== undefined) doc.setKeywords(meta.keywords.split(',').map((s) => s.trim()));
  return await doc.save();
}

export async function removePdfMetadata(buffer: ArrayBuffer): Promise<Uint8Array> {
  const doc = await PDFDocument.load(buffer);
  doc.setTitle('');
  doc.setAuthor('');
  doc.setSubject('');
  doc.setKeywords([]);
  doc.setCreator('');
  doc.setProducer('');
  return await doc.save();
}

/**
 * BROWSER FILE DOWNLOAD TRIGGER
 */
export function downloadPdfBytes(bytes: Uint8Array, filename: string = 'document.pdf') {
  const blob = new Blob([bytes], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.pdf') ? filename : `${filename}.pdf`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/**
 * CREATE NEW PDF FROM SIMPLE TEXT
 */
export async function createPdfFromSimpleText(title: string, content: string): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([595.28, 841.89]); // A4
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  page.drawText(title || 'Pressly Document', {
    x: 50,
    y: 780,
    size: 20,
    font: fontBold,
    color: rgb(0.1, 0.15, 0.25),
  });

  const lines = (content || 'Created with Pressly PDF Editor').split('\n');
  let y = 740;
  for (const line of lines) {
    if (y < 50) break;
    page.drawText(line.substring(0, 80), {
      x: 50,
      y,
      size: 12,
      font,
      color: rgb(0.1, 0.15, 0.25),
    });
    y -= 18;
  }

  return await pdfDoc.save();
}

export interface TextOverlayItem {
  id: string;
  str: string;
  pdfX: number;
  pdfY: number;
  pdfWidth: number;
  pdfHeight: number;
  fontSize: number;
  fontName?: string;
  canvasX: number;
  canvasY: number;
  canvasWidth: number;
  canvasHeight: number;
}

/**
 * Extract selectable text items on a page along with canvas pixel coordinates for overlay
 */
export async function extractPageTextOverlayItems(
  pdfBuffer: ArrayBuffer,
  pageNumber: number,
  scale: number = 1.5,
  rotation: number = 0
): Promise<{
  items: TextOverlayItem[];
  hasText: boolean;
  canvasWidth: number;
  canvasHeight: number;
}> {
  const pdfJsDoc = await loadPdfJsDoc(pdfBuffer);
  const totalPages = pdfJsDoc.numPages;
  if (pageNumber < 1 || pageNumber > totalPages) {
    return { items: [], hasText: false, canvasWidth: 0, canvasHeight: 0 };
  }

  const page = await pdfJsDoc.getPage(pageNumber);
  const viewport = page.getViewport({ scale, rotation: rotation || page.rotate });
  const textContent = await page.getTextContent();

  const items: TextOverlayItem[] = [];

  for (let idx = 0; idx < textContent.items.length; idx++) {
    const rawItem: any = textContent.items[idx];
    if (!rawItem || typeof rawItem.str !== 'string') continue;
    const str: string = rawItem.str;
    if (!str || !str.trim()) continue;

    const transform = rawItem.transform || [1, 0, 0, 1, 0, 0];
    const pdfX = transform[4] || 0;
    const pdfY = transform[5] || 0;
    const fontSize = Math.abs(transform[3]) || Math.abs(transform[0]) || 12;
    const fontName = rawItem.fontName || 'Helvetica';
    const pdfWidth = rawItem.width || (str.length * fontSize * 0.5);
    const pdfHeight = rawItem.height || fontSize;

    // Convert PDF coordinates to viewport / canvas coordinates
    const [x1, y1] = viewport.convertToViewportPoint(pdfX, pdfY);
    const [x2, y2] = viewport.convertToViewportPoint(pdfX + pdfWidth, pdfY + pdfHeight);
    const canvasX = Math.min(x1, x2);
    const canvasY = Math.min(y1, y2);
    const canvasWidth = Math.max(Math.abs(x2 - x1), 10);
    const canvasHeight = Math.max(Math.abs(y2 - y1), 10);

    items.push({
      id: `text_p${pageNumber}_${idx}_${Math.round(pdfX)}_${Math.round(pdfY)}`,
      str,
      pdfX,
      pdfY,
      pdfWidth,
      pdfHeight,
      fontSize,
      fontName,
      canvasX,
      canvasY,
      canvasWidth,
      canvasHeight,
    });
  }

  return {
    items,
    hasText: items.length > 0,
    canvasWidth: viewport.width,
    canvasHeight: viewport.height,
  };
}

/**
 * Apply in-place text edit on a PDF page using pdf-lib
 */
export async function applyInPlaceTextEdit(
  pdfBuffer: ArrayBuffer,
  options: {
    pageNumber: number;
    pdfX: number;
    pdfY: number;
    pdfWidth: number;
    pdfHeight: number;
    fontSize: number;
    newText: string;
    backgroundColor?: string;
  }
): Promise<Uint8Array> {
  const { pageNumber, pdfX, pdfY, pdfWidth, pdfHeight, fontSize, newText, backgroundColor = '#FFFFFF' } = options;

  const pdfDoc = await PDFDocument.load(pdfBuffer);
  const totalPages = pdfDoc.getPageCount();
  if (pageNumber < 1 || pageNumber > totalPages) {
    throw new Error(`Invalid page number ${pageNumber}`);
  }

  const page = pdfDoc.getPage(pageNumber - 1);
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);

  // Erase original text with background rectangle
  const bgRgb = hexToRgb(backgroundColor);
  const rectX = pdfX - 1;
  const rectY = pdfY - fontSize * 0.25;
  const rectW = Math.max(pdfWidth + 2, 4);
  const rectH = Math.max(pdfHeight * 1.1, fontSize * 1.25);

  page.drawRectangle({
    x: rectX,
    y: rectY,
    width: rectW,
    height: rectH,
    color: bgRgb,
  });

  // Draw new text if non-empty
  if (newText.trim()) {
    page.drawText(newText, {
      x: pdfX,
      y: pdfY,
      size: fontSize,
      font,
      color: rgb(0, 0, 0),
    });
  }

  const newBytes = await pdfDoc.save();
  const cleanBuffer = newBytes.buffer.slice(newBytes.byteOffset, newBytes.byteOffset + newBytes.byteLength);

  // Transfer/copy cached text index to the new buffer's cache key so words stay editable
  const oldTextCacheKey = getPageTextCacheKey(pdfBuffer, pageNumber);
  const existingIndex = pageTextIndexCache.get(oldTextCacheKey);
  if (existingIndex) {
    const updatedRawItems = existingIndex.rawItems.map((item) => {
      if (Math.abs(item.pdfX - pdfX) < 2 && Math.abs(item.pdfY - pdfY) < 2) {
        return {
          ...item,
          str: newText,
          pdfWidth: Math.max(font.widthOfTextAtSize(newText || ' ', fontSize), 10),
        };
      }
      return item;
    });

    const updatedIndex = {
      ...existingIndex,
      rawItems: updatedRawItems,
    };

    const newKey1 = getPageTextCacheKey(newBytes.buffer, pageNumber);
    const newKey2 = getPageTextCacheKey(cleanBuffer, pageNumber);
    pageTextIndexCache.set(newKey1, updatedIndex);
    pageTextIndexCache.set(newKey2, updatedIndex);
  }

  return newBytes;
}


export interface RawTextItem {
  id: string;
  str: string;
  pdfX: number;
  pdfY: number;
  pdfWidth: number;
  pdfHeight: number;
  fontSize: number;
  fontName: string;
}

export interface CharMapInfo {
  itemIndex: number;
  charInItem: number;
  isInsertedSpace?: boolean;
  pdfX: number;
  pdfWidth: number;
  pdfHeight: number;
  pdfY: number;
  fontSize: number;
  fontName: string;
}

export interface JoinedTextLine {
  lineIndex: number;
  lineY: number;
  lineHeight: number;
  text: string;
  items: RawTextItem[];
  charMap: CharMapInfo[];
  lineMinX: number;
  lineMaxX: number;
  lineLineWidth: number;
  lineFontSize: number;
  lineFontName: string;
}

export interface PageTextIndex {
  pageNumber: number;
  hasText: boolean;
  lines: JoinedTextLine[];
  rawItems: RawTextItem[];
  pageWidth: number;
  pageHeight: number;
}

export interface FindMatchItem {
  id: string;
  pageNumber: number;
  matchText: string;
  snippet: string;
  startIndexInLine: number;
  endIndexInLine: number;
  pdfX: number;
  pdfY: number;
  pdfWidth: number;
  pdfHeight: number;
  fontSize: number;
  fontName: string;
  lineY: number;
  parentItems: RawTextItem[];
  // Whole-line properties for whole-line rebuild replacement:
  lineIndex: number;
  lineText: string;
  lineMinX: number;
  lineMaxX: number;
  lineLineWidth: number;
  lineFontSize: number;
  lineFontName: string;
  lineHeight: number;
}

export interface FindSearchOptions {
  findQuery: string;
  matchCase: boolean;
  wholeWord: boolean;
}

export interface FindSearchResult {
  query: string;
  totalMatches: number;
  pageCountWithMatches: number;
  matches: FindMatchItem[];
  matchesByPage: Record<number, FindMatchItem[]>;
  scannedPagesCount: number;
  skippedScannedPagesCount: number;
}

// In-memory page text index cache keyed by page number
const pageTextIndexCache = new Map<string, PageTextIndex>();

export function getPageTextCacheKey(pdfBuffer: ArrayBuffer, pageNumber: number): string {
  return `${pdfBuffer.byteLength}_p${pageNumber}`;
}

export function storePageTextIndexInCache(cacheKey: string, index: PageTextIndex) {
  pageTextIndexCache.set(cacheKey, index);
}

export function getPageTextIndexFromCache(cacheKey: string): PageTextIndex | undefined {
  return pageTextIndexCache.get(cacheKey);
}

export function hasPageTextIndexInCache(cacheKey: string): boolean {
  return pageTextIndexCache.has(cacheKey);
}

export function clearPdfTextIndexCache() {
  pageTextIndexCache.clear();
}

/**
 * Common replacements for characters outside standard WinAnsi encoding.
 */
const WIN_ANSI_REPLACEMENTS: Record<string, string> = {
  '\uf0b7': '-', // Symbol bullet
  '\uf0a8': '[ ]',
  '\uf0fe': '[x]',
  '\u2022': '-', // Bullet
  '\u25cf': '-', // Black circle
  '\u25cb': '-', // White circle
  '\u25e6': '-', // Composition bullet
  '\u2013': '-', // En-dash
  '\u2014': '--', // Em-dash
  '\u2018': "'", // Left single quote
  '\u2019': "'", // Right single quote
  '\u201a': "'", // Single low-9 quote
  '\u201c': '"', // Left double quote
  '\u201d': '"', // Right double quote
  '\u201e': '"', // Double low-9 quote
  '\u2026': '...', // Ellipsis
  '\u00a0': ' ', // Non-breaking space
  '\u200b': '', // Zero-width space
  '\u200c': '',
  '\u200d': '',
  '\ufeff': '',
};

export function sanitizeTextForPdfFont(text: string, font: PDFFont): string {
  if (!text) return '';
  let result = '';
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    const mapped = WIN_ANSI_REPLACEMENTS[ch];
    const charToTest = mapped !== undefined ? mapped : ch;

    try {
      font.encodeText(charToTest);
      result += charToTest;
    } catch {
      let safeSeq = '';
      for (let j = 0; j < charToTest.length; j++) {
        const subCh = charToTest[j];
        const code = subCh.charCodeAt(0);
        if (code >= 32 && code <= 126) {
          safeSeq += subCh;
        } else {
          safeSeq += ' ';
        }
      }
      result += safeSeq;
    }
  }
  return result;
}

/**
 * Helper to embed appropriate StandardFont in pdf-lib based on font name (e.g. bold, italic, serif, mono)
 */
async function getFontForMatch(pdfDoc: PDFDocument, fontName?: string): Promise<PDFFont> {
  const name = (fontName || '').toLowerCase();
  const isBold = name.includes('bold') || name.includes('700') || name.includes('800') || name.includes('black') || name.includes('heavy') || name.includes('b');
  const isItalic = name.includes('italic') || name.includes('oblique') || name.includes('i');
  const isSerif = name.includes('times') || name.includes('serif') || name.includes('roman') || name.includes('georgia');
  const isMono = name.includes('courier') || name.includes('mono') || name.includes('code');

  try {
    if (isMono) {
      if (isBold && isItalic) return await pdfDoc.embedFont(StandardFonts.CourierBoldOblique);
      if (isBold) return await pdfDoc.embedFont(StandardFonts.CourierBold);
      if (isItalic) return await pdfDoc.embedFont(StandardFonts.CourierOblique);
      return await pdfDoc.embedFont(StandardFonts.Courier);
    }
    if (isSerif) {
      if (isBold && isItalic) return await pdfDoc.embedFont(StandardFonts.TimesRomanBoldItalic);
      if (isBold) return await pdfDoc.embedFont(StandardFonts.TimesRomanBold);
      if (isItalic) return await pdfDoc.embedFont(StandardFonts.TimesRomanItalic);
      return await pdfDoc.embedFont(StandardFonts.TimesRoman);
    }
    if (isBold && isItalic) return await pdfDoc.embedFont(StandardFonts.HelveticaBoldOblique);
    if (isBold) return await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    if (isItalic) return await pdfDoc.embedFont(StandardFonts.HelveticaOblique);
    return await pdfDoc.embedFont(StandardFonts.Helvetica);
  } catch {
    return await pdfDoc.embedFont(StandardFonts.Helvetica);
  }
}

/**
 * Build or retrieve cached line-joined text index for a specific page using pdfjs-dist
 */
export async function buildPageTextIndex(
  pdfBuffer: ArrayBuffer,
  pageNumber: number,
  forceReindex = false
): Promise<PageTextIndex> {
  const cacheKey = getPageTextCacheKey(pdfBuffer, pageNumber);
  if (!forceReindex && pageTextIndexCache.has(cacheKey)) {
    return pageTextIndexCache.get(cacheKey)!;
  }

  const pdfJsDoc = await loadPdfJsDoc(pdfBuffer);
  const page = await pdfJsDoc.getPage(pageNumber);
  const textContent = await page.getTextContent();
  const viewport = page.getViewport({ scale: 1.0 });
  const styles = (textContent as any).styles || {};

  const rawItems: RawTextItem[] = [];

  for (let idx = 0; idx < textContent.items.length; idx++) {
    const rawItem: any = textContent.items[idx];
    if (!rawItem || typeof rawItem.str !== 'string') continue;
    const str: string = rawItem.str;
    if (!str) continue;

    const transform = rawItem.transform || [1, 0, 0, 1, 0, 0];
    const pdfX = transform[4] || 0;
    const pdfY = transform[5] || 0;
    const fontSize = Math.abs(transform[3]) || Math.abs(transform[0]) || 12;

    const style = styles[rawItem.fontName];
    const resolvedFontName = style?.fontFamily || rawItem.fontName || 'Helvetica';

    const pdfWidth = rawItem.width || str.length * fontSize * 0.5;
    const pdfHeight = rawItem.height || fontSize;

    rawItems.push({
      id: `raw_p${pageNumber}_${idx}_${Math.round(pdfX)}_${Math.round(pdfY)}`,
      str,
      pdfX,
      pdfY,
      pdfWidth,
      pdfHeight,
      fontSize,
      fontName: resolvedFontName,
    });
  }

  // Line-Level Text Joining: Group adjacent text items with similar Y-coordinate
  const lineGroups: Array<{ y: number; items: RawTextItem[] }> = [];

  for (const item of rawItems) {
    let placed = false;
    for (const line of lineGroups) {
      if (Math.abs(line.y - item.pdfY) <= Math.max(2, item.fontSize * 0.25)) {
        line.items.push(item);
        placed = true;
        break;
      }
    }
    if (!placed) {
      lineGroups.push({ y: item.pdfY, items: [item] });
    }
  }

  const lines: JoinedTextLine[] = [];

  for (let groupIdx = 0; groupIdx < lineGroups.length; groupIdx++) {
    const group = lineGroups[groupIdx];
    group.items.sort((a, b) => a.pdfX - b.pdfX);

    let joinedLineText = '';
    const charMap: CharMapInfo[] = [];

    for (let i = 0; i < group.items.length; i++) {
      const item = group.items[i];

      if (i > 0) {
        const prevItem = group.items[i - 1];
        const prevEnd = prevItem.pdfX + prevItem.pdfWidth;
        const gap = item.pdfX - prevEnd;
        const needsSpace =
          gap > prevItem.fontSize * 0.15 &&
          !prevItem.str.endsWith(' ') &&
          !item.str.startsWith(' ');

        if (needsSpace) {
          joinedLineText += ' ';
          charMap.push({
            itemIndex: -1,
            charInItem: -1,
            isInsertedSpace: true,
            pdfX: prevEnd,
            pdfWidth: Math.max(1, gap),
            pdfY: prevItem.pdfY,
            fontSize: prevItem.fontSize,
            fontName: prevItem.fontName,
            pdfHeight: prevItem.pdfHeight,
          });
        }
      }

      const itemLen = item.str.length;
      const charWidth = itemLen > 0 ? item.pdfWidth / itemLen : item.pdfWidth;

      for (let c = 0; c < itemLen; c++) {
        joinedLineText += item.str[c];
        charMap.push({
          itemIndex: i,
          charInItem: c,
          isInsertedSpace: false,
          pdfX: item.pdfX + c * charWidth,
          pdfWidth: charWidth,
          pdfY: item.pdfY,
          fontSize: item.fontSize,
          fontName: item.fontName,
          pdfHeight: item.pdfHeight,
        });
      }
    }

    if (joinedLineText) {
      const lineMinX = charMap.length > 0 ? charMap[0].pdfX : group.items[0].pdfX;
      const lastChar = charMap[charMap.length - 1];
      const lineMaxX = lastChar
        ? lastChar.pdfX + lastChar.pdfWidth
        : group.items[group.items.length - 1].pdfX + group.items[group.items.length - 1].pdfWidth;
      const lineLineWidth = Math.max(1, lineMaxX - lineMinX);

      const fontSizes = group.items.map((it) => it.fontSize);
      const lineFontSize = Math.max(...fontSizes);
      const lineHeight = Math.max(...group.items.map((it) => it.pdfHeight), lineFontSize);
      const lineFontName = group.items[0]?.fontName || 'Helvetica';

      lines.push({
        lineIndex: groupIdx,
        lineY: group.y,
        lineHeight,
        text: joinedLineText,
        items: group.items,
        charMap,
        lineMinX,
        lineMaxX,
        lineLineWidth,
        lineFontSize,
        lineFontName,
      });
    }
  }

  const indexResult: PageTextIndex = {
    pageNumber,
    hasText: rawItems.length > 0 && lines.some((l) => l.text.trim().length > 0),
    lines,
    rawItems,
    pageWidth: viewport.width,
    pageHeight: viewport.height,
  };

  pageTextIndexCache.set(cacheKey, indexResult);
  return indexResult;
}

/**
 * Build index for all pages in PDF document
 */
export async function buildFullDocumentTextIndex(
  pdfBuffer: ArrayBuffer,
  onProgress?: (curr: number, total: number) => void
): Promise<PageTextIndex[]> {
  const pdfJsDoc = await loadPdfJsDoc(pdfBuffer);
  const totalPages = pdfJsDoc.numPages;
  const result: PageTextIndex[] = [];

  for (let p = 1; p <= totalPages; p++) {
    if (onProgress) onProgress(p, totalPages);
    const pageIdx = await buildPageTextIndex(pdfBuffer, p);
    result.push(pageIdx);
  }

  return result;
}

/**
 * Perform search against cached document text index
 */
export function searchInTextIndex(
  indexes: PageTextIndex[],
  options: FindSearchOptions
): FindSearchResult {
  const { findQuery, matchCase, wholeWord } = options;
  const queryTrimmed = findQuery.trim();

  if (!queryTrimmed) {
    let skipped = 0;
    for (const idx of indexes) {
      if (!idx.hasText) skipped++;
    }
    return {
      query: findQuery,
      totalMatches: 0,
      pageCountWithMatches: 0,
      matches: [],
      matchesByPage: {},
      scannedPagesCount: indexes.length,
      skippedScannedPagesCount: skipped,
    };
  }

  const allMatches: FindMatchItem[] = [];
  const matchesByPage: Record<number, FindMatchItem[]> = {};
  let skippedPagesCount = 0;

  const searchQuery = matchCase ? queryTrimmed : queryTrimmed.toLowerCase();

  for (const pageIdx of indexes) {
    if (!pageIdx.hasText) {
      skippedPagesCount++;
      continue;
    }

    let matchIdxOnPage = 0;

    for (const line of pageIdx.lines) {
      const targetText = matchCase ? line.text : line.text.toLowerCase();
      let pos = 0;

      while (pos < targetText.length) {
        const foundPos = targetText.indexOf(searchQuery, pos);
        if (foundPos === -1) break;

        const matchEnd = foundPos + searchQuery.length;
        let isMatchValid = true;

        if (wholeWord) {
          const charBefore = foundPos > 0 ? line.text.charAt(foundPos - 1) : ' ';
          const charAfter = matchEnd < line.text.length ? line.text.charAt(matchEnd) : ' ';
          const isBeforeWord = /[a-zA-Z0-9_]/.test(charBefore);
          const isAfterWord = /[a-zA-Z0-9_]/.test(charAfter);
          if (isBeforeWord || isAfterWord) {
            isMatchValid = false;
          }
        }

        if (isMatchValid) {
          const matchedChars = line.charMap.slice(foundPos, matchEnd);

          if (matchedChars.length > 0) {
            let minX = Infinity;
            let maxX = -Infinity;
            let minY = Infinity;
            let maxY = -Infinity;
            let maxFontSize = 0;
            let maxHeight = 0;

            const parentItemIndices = new Set<number>();

            for (const cInfo of matchedChars) {
              if (cInfo.pdfX < minX) minX = cInfo.pdfX;
              if (cInfo.pdfX + cInfo.pdfWidth > maxX) maxX = cInfo.pdfX + cInfo.pdfWidth;
              if (cInfo.pdfY < minY) minY = cInfo.pdfY;
              if (cInfo.pdfY > maxY) maxY = cInfo.pdfY;
              if (cInfo.fontSize > maxFontSize) maxFontSize = cInfo.fontSize;
              if (cInfo.pdfHeight > maxHeight) maxHeight = cInfo.pdfHeight;

              if (cInfo.itemIndex >= 0) {
                parentItemIndices.add(cInfo.itemIndex);
              }
            }

            if (minX !== Infinity && maxX !== -Infinity) {
              const pdfX = Math.round(minX * 100) / 100;
              const pdfEndX = Math.round(maxX * 100) / 100;
              const pdfWidth = Math.max(4, Math.round((pdfEndX - pdfX) * 100) / 100);
              const pdfY = minY;
              const fontSize = Math.round((maxFontSize || 12) * 10) / 10;
              const pdfHeight = Math.max(maxHeight, fontSize);

              const matchedText = line.text.slice(foundPos, matchEnd);

              // Snippet context
              const snipStart = Math.max(0, foundPos - 20);
              const snipEnd = Math.min(line.text.length, matchEnd + 20);
              const prefix = snipStart > 0 ? '...' : '';
              const suffix = snipEnd < line.text.length ? '...' : '';
              const snippet = `${prefix}${line.text.slice(snipStart, foundPos)}[${matchedText}]${line.text.slice(matchEnd, snipEnd)}${suffix}`;

              const parentItems = Array.from(parentItemIndices).map((idx) => line.items[idx]);
              const firstParentItem = parentItems[0] || line.items[0];

              const matchItem: FindMatchItem = {
                id: `find_p${pageIdx.pageNumber}_m${matchIdxOnPage++}_${foundPos}`,
                pageNumber: pageIdx.pageNumber,
                matchText: matchedText,
                snippet,
                startIndexInLine: foundPos,
                endIndexInLine: matchEnd,
                pdfX,
                pdfY,
                pdfWidth,
                pdfHeight,
                fontSize,
                fontName: firstParentItem?.fontName || line.lineFontName || 'Helvetica',
                lineY: line.lineY,
                parentItems,
                // Whole-line properties for whole-line rebuild replacement:
                lineIndex: line.lineIndex,
                lineText: line.text,
                lineMinX: line.lineMinX,
                lineMaxX: line.lineMaxX,
                lineLineWidth: line.lineLineWidth,
                lineFontSize: line.lineFontSize,
                lineFontName: line.lineFontName,
                lineHeight: line.lineHeight,
              };

              allMatches.push(matchItem);
              if (!matchesByPage[pageIdx.pageNumber]) {
                matchesByPage[pageIdx.pageNumber] = [];
              }
              matchesByPage[pageIdx.pageNumber].push(matchItem);
            }
          }
        }

        pos = foundPos + Math.max(1, searchQuery.length);
      }
    }
  }

  const pagesWithMatches = Object.keys(matchesByPage).length;

  return {
    query: findQuery,
    totalMatches: allMatches.length,
    pageCountWithMatches: pagesWithMatches,
    matches: allMatches,
    matchesByPage,
    scannedPagesCount: indexes.length,
    skippedScannedPagesCount: skippedPagesCount,
  };
}

/**
 * Apply single replacement in PDF using Whole-Line Rebuild
 */
export async function applySingleReplaceInPdf(
  pdfBuffer: ArrayBuffer,
  pageNumber: number,
  match: FindMatchItem,
  replacementText: string
): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.load(pdfBuffer);
  const totalPages = pdfDoc.getPageCount();
  if (pageNumber < 1 || pageNumber > totalPages) {
    throw new Error(`Invalid page number ${pageNumber}`);
  }

  const page = pdfDoc.getPage(pageNumber - 1);
  const fontName = match.lineFontName || match.fontName || 'Helvetica';
  const font = await getFontForMatch(pdfDoc, fontName);

  // 1. Build the complete new line string
  const originalLineText = match.lineText || match.matchText;
  let rawNewLineText = originalLineText;
  if (match.startIndexInLine >= 0 && match.endIndexInLine <= originalLineText.length) {
    rawNewLineText =
      originalLineText.slice(0, match.startIndexInLine) +
      replacementText +
      originalLineText.slice(match.endIndexInLine);
  } else {
    rawNewLineText = originalLineText.replace(match.matchText, replacementText);
  }

  const newLineText = sanitizeTextForPdfFont(rawNewLineText, font);

  // 2. Determine font size & original line width
  const originalFontSize = match.lineFontSize || match.fontSize || 12;
  const originalLineWidth = match.lineLineWidth || match.pdfWidth || 100;

  // 3. Auto-fit new line text if it exceeds original line width
  let finalFontSize = originalFontSize;
  if (newLineText) {
    let measuredWidth = font.widthOfTextAtSize(newLineText, originalFontSize);
    if (measuredWidth > originalLineWidth && originalLineWidth > 0) {
      let size = originalFontSize;
      while (size > 6) {
        size -= 0.5;
        const w = font.widthOfTextAtSize(newLineText, size);
        if (w <= originalLineWidth) break;
      }
      finalFontSize = Math.max(6, size);
    }
  }

  // 4. Cover the ENTIRE original line with white rectangle
  const lineMinX = match.lineMinX ?? match.pdfX;
  const lineY = match.lineY ?? match.pdfY;
  const paddingX = 1.0;
  const paddingYTop = 2.0;
  const paddingYBottom = originalFontSize * 0.28;

  const rectX = Math.max(0, lineMinX - paddingX);
  const rectY = Math.max(0, lineY - paddingYBottom);
  const rectW = Math.max(originalLineWidth + paddingX * 2, 10);
  const rectH = Math.max((match.lineHeight || originalFontSize) * 1.25, originalFontSize * 1.3) + paddingYTop;

  page.drawRectangle({
    x: rectX,
    y: rectY,
    width: rectW,
    height: rectH,
    color: rgb(1, 1, 1),
  });

  // 5. Draw the complete new line string
  if (newLineText) {
    page.drawText(newLineText, {
      x: lineMinX,
      y: lineY,
      size: finalFontSize,
      font,
      color: rgb(0, 0, 0),
    });
  }

  return await pdfDoc.save();
}

/**
 * Apply Replace All in PDF using Whole-Line Rebuild across all matches
 */
export async function applyReplaceAllInPdf(
  pdfBuffer: ArrayBuffer,
  matches: FindMatchItem[],
  replacementText: string
): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.load(pdfBuffer);
  const totalPages = pdfDoc.getPageCount();

  // Group matches by page
  const matchesByPage = new Map<number, FindMatchItem[]>();
  for (const m of matches) {
    const list = matchesByPage.get(m.pageNumber) || [];
    list.push(m);
    matchesByPage.set(m.pageNumber, list);
  }

  for (const [pageNumber, pageMatches] of matchesByPage.entries()) {
    if (pageNumber < 1 || pageNumber > totalPages) continue;
    const page = pdfDoc.getPage(pageNumber - 1);

    // Group matches on this page by line
    const matchesByLine = new Map<string, FindMatchItem[]>();
    for (const m of pageMatches) {
      const lineKey = m.lineIndex !== undefined ? `line_${m.lineIndex}` : `y_${Math.round(m.lineY * 10) / 10}`;
      const lineList = matchesByLine.get(lineKey) || [];
      lineList.push(m);
      matchesByLine.set(lineKey, lineList);
    }

    // Process each line containing matches in a single rebuild operation
    for (const [, lineMatches] of matchesByLine.entries()) {
      if (lineMatches.length === 0) continue;

      const representative = lineMatches[0];
      const fontName = representative.lineFontName || representative.fontName || 'Helvetica';
      const font = await getFontForMatch(pdfDoc, fontName);
      const originalLineText = representative.lineText || representative.matchText;

      // Sort matches right-to-left (descending startIndexInLine) to replace in place
      const sortedMatches = [...lineMatches].sort((a, b) => b.startIndexInLine - a.startIndexInLine);
      let rawNewLineText = originalLineText;

      for (const m of sortedMatches) {
        if (m.startIndexInLine >= 0 && m.endIndexInLine <= rawNewLineText.length) {
          rawNewLineText =
            rawNewLineText.slice(0, m.startIndexInLine) +
            replacementText +
            rawNewLineText.slice(m.endIndexInLine);
        } else {
          rawNewLineText = rawNewLineText.replace(m.matchText, replacementText);
        }
      }

      const newLineText = sanitizeTextForPdfFont(rawNewLineText, font);

      const originalFontSize = representative.lineFontSize || representative.fontSize || 12;
      const originalLineWidth = representative.lineLineWidth || representative.pdfWidth || 100;

      // Auto-fit font size if needed
      let finalFontSize = originalFontSize;
      if (newLineText) {
        let measuredWidth = font.widthOfTextAtSize(newLineText, originalFontSize);
        if (measuredWidth > originalLineWidth && originalLineWidth > 0) {
          let size = originalFontSize;
          while (size > 6) {
            size -= 0.5;
            const w = font.widthOfTextAtSize(newLineText, size);
            if (w <= originalLineWidth) break;
          }
          finalFontSize = Math.max(6, size);
        }
      }

      // Cover the ENTIRE original line with white rectangle
      const lineMinX = representative.lineMinX ?? representative.pdfX;
      const lineY = representative.lineY ?? representative.pdfY;
      const paddingX = 1.0;
      const paddingYTop = 2.0;
      const paddingYBottom = originalFontSize * 0.28;

      const rectX = Math.max(0, lineMinX - paddingX);
      const rectY = Math.max(0, lineY - paddingYBottom);
      const rectW = Math.max(originalLineWidth + paddingX * 2, 10);
      const rectH = Math.max((representative.lineHeight || originalFontSize) * 1.25, originalFontSize * 1.3) + paddingYTop;

      page.drawRectangle({
        x: rectX,
        y: rectY,
        width: rectW,
        height: rectH,
        color: rgb(1, 1, 1),
      });

      // Draw the complete new line string
      if (newLineText) {
        page.drawText(newLineText, {
          x: lineMinX,
          y: lineY,
          size: finalFontSize,
          font,
          color: rgb(0, 0, 0),
        });
      }
    }
  }

  return await pdfDoc.save();
}

export interface ImageToPdfOptions {
  pageSize?: 'a4' | 'letter' | 'fit';
  orientation?: 'auto' | 'portrait' | 'landscape';
  margin?: 'none' | 'small' | 'medium' | 'large';
}

/**
 * CONVERT IMAGES (JPG, PNG, WebP, GIF, BMP) TO A PROFESSIONAL PDF DOCUMENT
 */
export async function convertImagesToPdf(
  imageDataUrls: string[],
  options: ImageToPdfOptions = {}
): Promise<Uint8Array> {
  const { pageSize = 'fit', orientation = 'auto', margin = 'none' } = options;
  const pdfDoc = await PDFDocument.create();

  const marginMap = {
    none: 0,
    small: 18,  // 0.25 in (18pt)
    medium: 36, // 0.5 in (36pt)
    large: 54,  // 0.75 in (54pt)
  };
  const marginPt = marginMap[margin] ?? 0;

  for (const dataUrl of imageDataUrls) {
    if (!dataUrl) continue;

    // Convert image dataUrl to JPEG bytes & get original dimensions via HTML Canvas
    const { bytes, width: imgW, height: imgH } = await new Promise<{
      bytes: Uint8Array;
      width: number;
      height: number;
    }>((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const w = img.naturalWidth || img.width || 800;
        const h = img.naturalHeight || img.height || 600;
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context error'));
          return;
        }
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);

        const jpegUrl = canvas.toDataURL('image/jpeg', 0.92);
        const base64 = jpegUrl.split(',')[1];
        const binary = atob(base64);
        const u8 = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
          u8[i] = binary.charCodeAt(i);
        }
        resolve({ bytes: u8, width: w, height: h });
      };
      img.onerror = () => reject(new Error('Failed to load image file for PDF conversion.'));
      img.src = dataUrl;
    });

    const embeddedImg = await pdfDoc.embedJpg(bytes);

    let pageWidth: number;
    let pageHeight: number;

    if (pageSize === 'fit') {
      pageWidth = imgW + marginPt * 2;
      pageHeight = imgH + marginPt * 2;
    } else {
      let stdW = pageSize === 'letter' ? 612 : 595.28;
      let stdH = pageSize === 'letter' ? 792 : 841.89;

      let isLandscape = false;
      if (orientation === 'landscape') {
        isLandscape = true;
      } else if (orientation === 'portrait') {
        isLandscape = false;
      } else {
        // Auto orientation based on image aspect ratio
        isLandscape = imgW > imgH;
      }

      pageWidth = isLandscape ? Math.max(stdW, stdH) : Math.min(stdW, stdH);
      pageHeight = isLandscape ? Math.min(stdW, stdH) : Math.max(stdW, stdH);
    }

    const page = pdfDoc.addPage([pageWidth, pageHeight]);

    const printableW = Math.max(10, pageWidth - marginPt * 2);
    const printableH = Math.max(10, pageHeight - marginPt * 2);

    const scale = Math.min(printableW / imgW, printableH / imgH);
    const drawW = imgW * scale;
    const drawH = imgH * scale;

    const drawX = (pageWidth - drawW) / 2;
    const drawY = (pageHeight - drawH) / 2;

    page.drawImage(embeddedImg, {
      x: drawX,
      y: drawY,
      width: drawW,
      height: drawH,
    });
  }

  return await pdfDoc.save();
}

export interface PdfToImageResult {
  pageNumber: number;
  dataUrl: string;
  width: number;
  height: number;
  filename: string;
}

export interface PdfToImageOptions {
  format?: 'png' | 'jpeg' | 'webp';
  scale?: number; // e.g. 1.0 (72 DPI), 2.0 (144 DPI - crisp), 3.0 (216 DPI - Ultra HQ)
  quality?: number; // 0.1 to 1.0
}

/**
 * Convert all pages of a PDF document into high quality image Data URLs
 */
export async function convertPdfToImages(
  pdfBuffer: ArrayBuffer,
  options: PdfToImageOptions = {}
): Promise<PdfToImageResult[]> {
  const { format = 'png', scale = 2.0, quality = 0.92 } = options;
  const pdfJsDoc = await loadPdfJsDoc(pdfBuffer);
  const totalPages = pdfJsDoc.numPages;
  const results: PdfToImageResult[] = [];

  const mimeType = format === 'jpeg' ? 'image/jpeg' : format === 'webp' ? 'image/webp' : 'image/png';
  const extension = format === 'jpeg' ? 'jpg' : format;

  for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
    const page = await pdfJsDoc.getPage(pageNum);
    const viewport = page.getViewport({ scale });

    const canvas = document.createElement('canvas');
    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const ctx = canvas.getContext('2d');

    if (!ctx) continue;

    // Fill white background for JPEG/WEBP
    if (format === 'jpeg' || format === 'webp') {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    await page.render({
      canvasContext: ctx,
      viewport: viewport,
      canvas: canvas,
    } as any).promise;

    const dataUrl = canvas.toDataURL(mimeType, quality);
    results.push({
      pageNumber: pageNum,
      dataUrl,
      width: Math.round(viewport.width),
      height: Math.round(viewport.height),
      filename: `page_${pageNum}.${extension}`,
    });
  }

  return results;
}

/**
 * Trigger client-side download of a single image Data URL
 */
export function downloadSingleImage(dataUrl: string, filename: string) {
  const link = document.createElement('a');
  link.href = dataUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * Download multiple converted images packaged into a single ZIP archive
 */
export async function downloadImagesAsZip(
  images: { filename: string; dataUrl: string }[],
  zipFilename: string = 'pdf_converted_images.zip'
) {
  const JSZipModule = (await import('jszip')).default;
  const zip = new JSZipModule();

  images.forEach((img) => {
    const base64Data = img.dataUrl.split(',')[1];
    if (base64Data) {
      zip.file(img.filename, base64Data, { base64: true });
    }
  });

  const content = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(content);
  const link = document.createElement('a');
  link.href = url;
  link.download = zipFilename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export interface DuplicateGroup {
  originalPage: number; // 1-based index of original page
  duplicates: number[]; // 1-based indices of duplicate pages
  matchType: 'exact_text' | 'visual_layout' | 'identical_content';
  textSnippet?: string;
  dataUrl?: string; // Thumbnail data URL of original page
  duplicateThumbnails?: Record<number, string>; // Thumbnail data URL for duplicate pages
}

export interface DuplicateDetectionResult {
  hasDuplicates: boolean;
  totalDuplicatesCount: number;
  groups: DuplicateGroup[];
  duplicatePageNumbers: number[]; // List of all duplicate page numbers (excluding originals)
}

/**
 * Automatically scan PDF for duplicate pages using text content and visual layout fingerprints
 */
export async function detectDuplicatePages(
  pdfBuffer: ArrayBuffer,
  onProgress?: (current: number, total: number) => void
): Promise<DuplicateDetectionResult> {
  const pdfJsDoc = await loadPdfJsDoc(pdfBuffer);
  const totalPages = pdfJsDoc.numPages;

  const pageData: {
    pageNumber: number;
    text: string;
    dataUrl: string;
  }[] = [];

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');

  for (let i = 1; i <= totalPages; i++) {
    if (onProgress) onProgress(i, totalPages);

    const page = await pdfJsDoc.getPage(i);

    // 1. Extract text content
    let text = '';
    try {
      const textContent = await page.getTextContent();
      text = textContent.items
        .map((item: any) => item.str)
        .join(' ')
        .trim()
        .toLowerCase()
        .replace(/\s+/g, ' ');
    } catch {
      // Ignore text extraction error
    }

    // 2. Render small visual thumbnail for fingerprinting
    let dataUrl = '';
    const viewport = page.getViewport({ scale: 0.3 });
    canvas.width = viewport.width;
    canvas.height = viewport.height;

    if (ctx) {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({
        canvasContext: ctx,
        viewport: viewport,
      } as any).promise;

      dataUrl = canvas.toDataURL('image/jpeg', 0.6);
    }

    pageData.push({
      pageNumber: i,
      text,
      dataUrl,
    });
  }

  const groups: DuplicateGroup[] = [];
  const processed = new Set<number>();
  const duplicatePageNumbers: number[] = [];

  for (let i = 0; i < pageData.length; i++) {
    const current = pageData[i];
    if (processed.has(current.pageNumber)) continue;

    const dupes: number[] = [];
    const duplicateThumbnails: Record<number, string> = {};
    let matchType: 'exact_text' | 'visual_layout' | 'identical_content' = 'identical_content';

    for (let j = i + 1; j < pageData.length; j++) {
      const compare = pageData[j];
      if (processed.has(compare.pageNumber)) continue;

      let isMatch = false;

      // Check 1: Text match if pages have significant text
      if (current.text.length >= 15 && compare.text.length >= 15) {
        if (current.text === compare.text) {
          isMatch = true;
          matchType = 'exact_text';
        }
      }

      // Check 2: Visual layout match
      if (!isMatch && current.dataUrl && compare.dataUrl) {
        if (current.dataUrl === compare.dataUrl) {
          isMatch = true;
          matchType = 'visual_layout';
        }
      }

      if (isMatch) {
        dupes.push(compare.pageNumber);
        duplicateThumbnails[compare.pageNumber] = compare.dataUrl;
        processed.add(compare.pageNumber);
        duplicatePageNumbers.push(compare.pageNumber);
      }
    }

    if (dupes.length > 0) {
      processed.add(current.pageNumber);
      groups.push({
        originalPage: current.pageNumber,
        duplicates: dupes,
        matchType,
        textSnippet: current.text.slice(0, 120),
        dataUrl: current.dataUrl,
        duplicateThumbnails,
      });
    }
  }

  return {
    hasDuplicates: groups.length > 0,
    totalDuplicatesCount: duplicatePageNumbers.length,
    groups,
    duplicatePageNumbers,
  };
}

export interface BlankPageInfo {
  pageNumber: number; // 1-based index
  isBlank: boolean;
  nonWhitePercentage: number;
  textLength: number;
  textSnippet: string;
  dataUrl: string;
  confidence: 'high' | 'medium' | 'low';
  reason: string;
}

export interface BlankDetectionResult {
  hasBlankPages: boolean;
  totalBlankCount: number;
  blankPageNumbers: number[];
  blankPages: BlankPageInfo[];
  allPages: BlankPageInfo[];
}

export interface BlankScanOptions {
  sensitivity?: 'strict' | 'standard' | 'aggressive'; // strict = 0.1%, standard = 0.25%, aggressive = 0.5%
  ignoreHeaderFooter?: boolean;
}

/**
 * Scan PDF for empty or blank pages using text content and visual pixel density analysis
 */
export async function detectBlankPages(
  pdfBuffer: ArrayBuffer,
  options: BlankScanOptions = {},
  onProgress?: (current: number, total: number) => void
): Promise<BlankDetectionResult> {
  const { sensitivity = 'standard' } = options;

  let pixelThresholdPercent = 0.25;
  let maxTextLength = 10;

  if (sensitivity === 'strict') {
    pixelThresholdPercent = 0.1;
    maxTextLength = 3;
  } else if (sensitivity === 'aggressive') {
    pixelThresholdPercent = 0.5;
    maxTextLength = 20;
  }

  const pdfJsDoc = await loadPdfJsDoc(pdfBuffer);
  const totalPages = pdfJsDoc.numPages;

  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');

  const allPages: BlankPageInfo[] = [];
  const blankPages: BlankPageInfo[] = [];
  const blankPageNumbers: number[] = [];

  for (let i = 1; i <= totalPages; i++) {
    if (onProgress) onProgress(i, totalPages);

    const page = await pdfJsDoc.getPage(i);

    // 1. Extract text
    let text = '';
    try {
      const textContent = await page.getTextContent();
      text = textContent.items
        .map((item: any) => item.str)
        .join(' ')
        .trim();
    } catch {
      // Ignore text extraction error
    }

    const cleanText = text.replace(/\s+/g, '');
    const textLength = cleanText.length;

    // 2. Render small thumbnail to inspect pixel density
    let dataUrl = '';
    let nonWhitePercentage = 0;

    const viewport = page.getViewport({ scale: 0.25 });
    canvas.width = viewport.width;
    canvas.height = viewport.height;

    if (ctx) {
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      await page.render({
        canvasContext: ctx,
        viewport: viewport,
      } as any).promise;

      dataUrl = canvas.toDataURL('image/jpeg', 0.6);

      try {
        const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imgData.data;
        let nonWhitePixels = 0;
        const totalPixels = canvas.width * canvas.height;

        for (let p = 0; p < data.length; p += 4) {
          const r = data[p];
          const g = data[p + 1];
          const b = data[p + 2];
          const a = data[p + 3];

          // Check if pixel is visibly non-white/dark
          if (a > 30 && (r < 240 || g < 240 || b < 240)) {
            nonWhitePixels++;
          }
        }

        nonWhitePercentage = (nonWhitePixels / totalPixels) * 100;
      } catch {
        // ImageData access error fallback
      }
    }

    // 3. Determine if page is blank
    let isBlank = false;
    let confidence: 'high' | 'medium' | 'low' = 'low';
    let reason = 'Page contains visual content';

    if (textLength === 0 && nonWhitePercentage <= pixelThresholdPercent) {
      isBlank = true;
      confidence = 'high';
      reason = '100% Empty page (No text & clear white canvas)';
    } else if (textLength <= maxTextLength && nonWhitePercentage <= pixelThresholdPercent) {
      isBlank = true;
      confidence = 'high';
      reason = `Empty page (${textLength} noise chars, ${nonWhitePercentage.toFixed(2)}% pixel density)`;
    } else if (textLength <= maxTextLength * 1.5 && nonWhitePercentage <= pixelThresholdPercent * 1.2) {
      isBlank = true;
      confidence = 'medium';
      reason = `Near-blank page (${nonWhitePercentage.toFixed(2)}% pixel density)`;
    }

    const pageInfo: BlankPageInfo = {
      pageNumber: i,
      isBlank,
      nonWhitePercentage: Number(nonWhitePercentage.toFixed(3)),
      textLength,
      textSnippet: text.slice(0, 80),
      dataUrl,
      confidence,
      reason,
    };

    allPages.push(pageInfo);

    if (isBlank) {
      blankPages.push(pageInfo);
      blankPageNumbers.push(i);
    }
  }

  return {
    hasBlankPages: blankPages.length > 0,
    totalBlankCount: blankPages.length,
    blankPageNumbers,
    blankPages,
    allPages,
  };
}

export interface PageSizeInfo {
  pageNumber: number;
  widthPt: number;
  heightPt: number;
  widthMm: number;
  heightMm: number;
  widthIn: number;
  heightIn: number;
  label: string;
}

export interface DocumentPageSizeSummary {
  totalPages: number;
  isUniform: boolean;
  uniqueSizesCount: number;
  pageSizes: PageSizeInfo[];
  firstPageWidthPt: number;
  firstPageHeightPt: number;
}

export const STANDARD_PAGE_SIZES: Record<string, { name: string; widthPt: number; heightPt: number; description: string }> = {
  A4: { name: 'A4', widthPt: 595.28, heightPt: 841.89, description: '210 x 297 mm (Standard International)' },
  LETTER: { name: 'US Letter', widthPt: 612, heightPt: 792, description: '8.5 x 11 in (Standard US)' },
  LEGAL: { name: 'US Legal', widthPt: 612, heightPt: 1008, description: '8.5 x 14 in (Legal Documents)' },
  A3: { name: 'A3', widthPt: 841.89, heightPt: 1190.55, description: '297 x 420 mm (Large Format)' },
  A5: { name: 'A5', widthPt: 419.53, heightPt: 595.28, description: '148 x 210 mm (Booklet / Small)' },
  TABLOID: { name: 'Tabloid / Ledger', widthPt: 792, heightPt: 1224, description: '11 x 17 in (Newspaper / Large)' },
  EXECUTIVE: { name: 'Executive', widthPt: 522, heightPt: 756, description: '7.25 x 10.5 in (Monograph / Notes)' },
};

export interface PageNormalizeOptions {
  preset: 'A4' | 'LETTER' | 'LEGAL' | 'A3' | 'A5' | 'TABLOID' | 'EXECUTIVE' | 'MATCH_PAGE_1' | 'CUSTOM';
  customWidthPt?: number;
  customHeightPt?: number;
  orientation?: 'portrait' | 'landscape' | 'auto';
  scaleMode?: 'fit' | 'fill' | 'stretch';
}

/**
 * Extract dimension details and check if pages are uniform
 */
export async function getDocumentPageSizes(pdfBuffer: ArrayBuffer): Promise<DocumentPageSizeSummary> {
  const pdfDoc = await loadPdfDoc(pdfBuffer);
  const pages = pdfDoc.getPages();
  const pageSizes: PageSizeInfo[] = [];
  const sizeKeys = new Set<string>();

  for (let i = 0; i < pages.length; i++) {
    const p = pages[i];
    const { width, height } = p.getSize();
    const widthPt = Math.round(width * 100) / 100;
    const heightPt = Math.round(height * 100) / 100;

    const widthMm = Math.round((widthPt / 2.83465) * 10) / 10;
    const heightMm = Math.round((heightPt / 2.83465) * 10) / 10;
    const widthIn = Math.round((widthPt / 72) * 100) / 100;
    const heightIn = Math.round((heightPt / 72) * 100) / 100;

    let label = `${widthPt} x ${heightPt} pt (${widthIn}" x ${heightIn}")`;
    for (const [, val] of Object.entries(STANDARD_PAGE_SIZES)) {
      if (
        (Math.abs(val.widthPt - widthPt) < 5 && Math.abs(val.heightPt - heightPt) < 5) ||
        (Math.abs(val.heightPt - widthPt) < 5 && Math.abs(val.widthPt - heightPt) < 5)
      ) {
        label = `${val.name} (${widthIn}" x ${heightIn}")`;
        break;
      }
    }

    const key = `${widthPt.toFixed(1)}_${heightPt.toFixed(1)}`;
    sizeKeys.add(key);

    pageSizes.push({
      pageNumber: i + 1,
      widthPt,
      heightPt,
      widthMm,
      heightMm,
      widthIn,
      heightIn,
      label,
    });
  }

  const firstPage = pageSizes[0] || { widthPt: 595.28, heightPt: 841.89 };

  return {
    totalPages: pages.length,
    isUniform: sizeKeys.size <= 1,
    uniqueSizesCount: sizeKeys.size,
    pageSizes,
    firstPageWidthPt: firstPage.widthPt,
    firstPageHeightPt: firstPage.heightPt,
  };
}

/**
 * Resizes and normalizes all PDF pages to a selected uniform page size
 */
export async function normalizePageSizes(
  pdfBuffer: ArrayBuffer,
  options: PageNormalizeOptions
): Promise<Uint8Array> {
  const {
    preset,
    customWidthPt = 595.28,
    customHeightPt = 841.89,
    orientation = 'auto',
    scaleMode = 'fit',
  } = options;

  const srcPdfDoc = await loadPdfDoc(pdfBuffer);
  const newPdfDoc = await PDFDocument.create();

  const pages = srcPdfDoc.getPages();
  if (pages.length === 0) return await srcPdfDoc.save();

  let baseWidth = 595.28;
  let baseHeight = 841.89;

  if (preset === 'MATCH_PAGE_1') {
    const firstSize = pages[0].getSize();
    baseWidth = firstSize.width;
    baseHeight = firstSize.height;
  } else if (preset === 'CUSTOM') {
    baseWidth = Math.max(72, customWidthPt);
    baseHeight = Math.max(72, customHeightPt);
  } else if (STANDARD_PAGE_SIZES[preset]) {
    baseWidth = STANDARD_PAGE_SIZES[preset].widthPt;
    baseHeight = STANDARD_PAGE_SIZES[preset].heightPt;
  }

  let targetPortraitWidth = Math.min(baseWidth, baseHeight);
  let targetPortraitHeight = Math.max(baseWidth, baseHeight);

  if (preset === 'MATCH_PAGE_1' || preset === 'CUSTOM') {
    targetPortraitWidth = baseWidth;
    targetPortraitHeight = baseHeight;
  }

  for (let i = 0; i < pages.length; i++) {
    const srcPage = pages[i];
    const embeddedPage = await newPdfDoc.embedPage(srcPage);
    const origW = embeddedPage.width;
    const origH = embeddedPage.height;

    let finalTargetW = targetPortraitWidth;
    let finalTargetH = targetPortraitHeight;

    if (orientation === 'landscape') {
      finalTargetW = Math.max(targetPortraitWidth, targetPortraitHeight);
      finalTargetH = Math.min(targetPortraitWidth, targetPortraitHeight);
    } else if (orientation === 'portrait') {
      finalTargetW = Math.min(targetPortraitWidth, targetPortraitHeight);
      finalTargetH = Math.max(targetPortraitWidth, targetPortraitHeight);
    } else if (orientation === 'auto') {
      const origIsLandscape = origW > origH;
      if (origIsLandscape) {
        finalTargetW = Math.max(targetPortraitWidth, targetPortraitHeight);
        finalTargetH = Math.min(targetPortraitWidth, targetPortraitHeight);
      } else {
        finalTargetW = Math.min(targetPortraitWidth, targetPortraitHeight);
        finalTargetH = Math.max(targetPortraitWidth, targetPortraitHeight);
      }
    }

    const newPage = newPdfDoc.addPage([finalTargetW, finalTargetH]);

    let drawW = finalTargetW;
    let drawH = finalTargetH;
    let x = 0;
    let y = 0;

    if (scaleMode === 'fit') {
      const scale = Math.min(finalTargetW / origW, finalTargetH / origH);
      drawW = origW * scale;
      drawH = origH * scale;
      x = (finalTargetW - drawW) / 2;
      y = (finalTargetH - drawH) / 2;
    } else if (scaleMode === 'fill') {
      const scale = Math.max(finalTargetW / origW, finalTargetH / origH);
      drawW = origW * scale;
      drawH = origH * scale;
      x = (finalTargetW - drawW) / 2;
      y = (finalTargetH - drawH) / 2;
    } else if (scaleMode === 'stretch') {
      drawW = finalTargetW;
      drawH = finalTargetH;
      x = 0;
      y = 0;
    }

    newPage.drawPage(embeddedPage, {
      x,
      y,
      width: drawW,
      height: drawH,
    });
  }

  return await newPdfDoc.save();
}

