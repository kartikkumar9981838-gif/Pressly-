import createQpdf from '@neslinesli93/qpdf-wasm';

export interface QpdfEmscriptenFS {
  writeFile(path: string, data: Uint8Array | string, opts?: any): void;
  readFile(path: string, opts?: any): Uint8Array;
  unlink(path: string): void;
  mkdir(path: string): void;
}

export interface QpdfWasmInstance {
  callMain(args: string[]): number;
  FS: QpdfEmscriptenFS;
  print?: (text: string) => void;
  printErr?: (text: string) => void;
}

let qpdfInstancePromise: Promise<QpdfWasmInstance> | null = null;

/**
 * Initializes and caches the singleton QPDF WASM instance.
 */
export async function getQpdfInstance(): Promise<QpdfWasmInstance> {
  if (qpdfInstancePromise) {
    return qpdfInstancePromise;
  }

  qpdfInstancePromise = (async () => {
    let wasmBinary: Uint8Array | undefined;

    // Try fetching /qpdf.wasm from public directory in browser
    if (typeof window !== 'undefined' && typeof fetch !== 'undefined') {
      try {
        const response = await fetch('/qpdf.wasm');
        if (response.ok) {
          const buffer = await response.arrayBuffer();
          wasmBinary = new Uint8Array(buffer);
        }
      } catch (e) {
        console.warn('Failed to pre-fetch /qpdf.wasm, relying on locateFile:', e);
      }
    }

    const instance = await (createQpdf as any)({
      wasmBinary: wasmBinary,
      locateFile: (path: string) => {
        if (path.endsWith('.wasm')) {
          return '/qpdf.wasm';
        }
        return path;
      },
      print: (text: string) => {
        console.log('[QPDF]:', text);
      },
      printErr: (text: string) => {
        console.warn('[QPDF Err]:', text);
      },
      noInitialRun: true,
    });

    return instance as unknown as QpdfWasmInstance;
  })();

  return qpdfInstancePromise;
}

export interface DecryptResult {
  decryptedBytes: Uint8Array;
}

/**
 * Decrypts a password-protected PDF using the client-side QPDF WebAssembly engine.
 *
 * @param encryptedBytes Original encrypted PDF buffer or Uint8Array
 * @param password The user-supplied password
 * @returns The decrypted Uint8Array bytes (unprotected, RC4/AES decrypted)
 */
export async function decryptPdfWithQpdf(
  encryptedBytes: ArrayBuffer | Uint8Array,
  password: string
): Promise<Uint8Array> {
  const qpdf = await getQpdfInstance();

  const uint8Input = encryptedBytes instanceof Uint8Array 
    ? encryptedBytes 
    : new Uint8Array(encryptedBytes);

  const fileId = Math.random().toString(36).substring(2, 9);
  const inPath = `/input_${fileId}.pdf`;
  const outPath = `/output_${fileId}.pdf`;

  let stderrLog = '';
  let stdoutLog = '';

  // Temporarily hook into print & printErr or capture logs
  const origPrint = (qpdf as any).print;
  const origPrintErr = (qpdf as any).printErr;
  (qpdf as any).print = (text: string) => {
    stdoutLog += text + '\n';
  };
  (qpdf as any).printErr = (text: string) => {
    stderrLog += text + '\n';
  };

  try {
    // Write encrypted bytes to Emscripten virtual file system
    qpdf.FS.writeFile(inPath, uint8Input);

    // Run QPDF decrypt command
    const exitCode = qpdf.callMain([
      `--password=${password}`,
      '--decrypt',
      inPath,
      outPath,
    ]);

    if (exitCode === 0) {
      // Check if output file was generated
      const outputData = qpdf.FS.readFile(outPath);
      if (!outputData || outputData.length === 0) {
        throw new Error('Unable to process this PDF\'s encryption. It may use an unsupported security method.');
      }
      return outputData;
    }

    // Exit code non-zero: inspect stderr & error output
    const combinedLog = (stderrLog + ' ' + stdoutLog).toLowerCase();

    if (
      exitCode === 2 || 
      combinedLog.includes('invalid password') || 
      combinedLog.includes('incorrect password') ||
      combinedLog.includes('password')
    ) {
      throw new Error('Incorrect password. Please try again.');
    }

    throw new Error('Unable to process this PDF\'s encryption. It may use an unsupported security method.');
  } catch (err: any) {
    const msg = err?.message || String(err);
    if (
      msg.includes('Incorrect password') ||
      msg.toLowerCase().includes('invalid password')
    ) {
      throw new Error('Incorrect password. Please try again.');
    } else if (msg.includes('Unable to process')) {
      throw err;
    }
    throw new Error('Unable to process this PDF\'s encryption. It may use an unsupported security method.');
  } finally {
    // Restore logger hooks
    (qpdf as any).print = origPrint;
    (qpdf as any).printErr = origPrintErr;

    // Clean up temporary virtual files
    try {
      qpdf.FS.unlink(inPath);
    } catch {}
    try {
      qpdf.FS.unlink(outPath);
    } catch {}
  }
}
