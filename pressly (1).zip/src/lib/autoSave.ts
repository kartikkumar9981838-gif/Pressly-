// src/lib/autoSave.ts
/**
 * Auto-Save Engine for Pressly PDF Editor
 * Persists editor state (metadata, active page, sequence, drafts) and PDF buffer
 * to localStorage and IndexedDB to ensure zero data loss during tab refreshes.
 */

export interface AutoSaveMeta {
  id: string;
  fileName: string;
  pageCount: number;
  activePage: number;
  pageSequence: number[];
  selectedFlow: string;
  savedAt: number;
  savedAtFormatted: string;
  sizeBytes: number;
  hasBuffer: boolean;
}

export interface AutoSavePayload {
  buffer: ArrayBuffer;
  fileName: string;
  pageCount: number;
  activePage: number;
  pageSequence: number[];
  selectedFlow?: string;
  extraMeta?: Record<string, any>;
}

const META_STORAGE_KEY = 'pressly_autosave_meta';
const BUFFER_FALLBACK_KEY = 'pressly_autosave_buffer_b64';
const DB_NAME = 'pressly_pdf_storage_v1';
const STORE_NAME = 'editor_sessions';
const SESSION_KEY = 'active_editor_pdf_session';

// --- IndexedDB Core Utilities ---

function getIndexedDB(): IDBFactory | null {
  if (typeof window !== 'undefined' && window.indexedDB) {
    return window.indexedDB;
  }
  return null;
}

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const idb = getIndexedDB();
    if (!idb) {
      return reject(new Error('IndexedDB is not supported in this browser'));
    }

    const request = idb.open(DB_NAME, 1);

    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('Failed to open database'));
  });
}

async function idbSet(key: string, value: any): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(value, key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    } catch (err) {
      reject(err);
    }
  });
}

async function idbGet<T>(key: string): Promise<T | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result !== undefined ? req.result : null);
      req.onerror = () => reject(req.error);
    } catch (err) {
      reject(err);
    }
  });
}

async function idbDelete(key: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    try {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    } catch (err) {
      reject(err);
    }
  });
}

// --- ArrayBuffer to Base64 Chunked Encoding (Safe for localStorage) ---

export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  const CHUNK_SIZE = 0x8000; // 32KB chunks to prevent maximum call stack error
  for (let i = 0; i < len; i += CHUNK_SIZE) {
    const chunk = bytes.subarray(i, Math.min(i + CHUNK_SIZE, len));
    binary += String.fromCharCode.apply(null, chunk as unknown as number[]);
  }
  return btoa(binary);
}

export function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

export function formatTimeAgo(epoch: number): string {
  const diffMs = Date.now() - epoch;
  const diffSec = Math.floor(diffMs / 1000);
  if (diffSec < 5) return 'Just now';
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  return new Date(epoch).toLocaleDateString();
}

export function formatFileSize(bytes: number): string {
  if (bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
}

// --- Main Auto-Save API ---

/**
 * Check synchronously if an auto-saved session exists in localStorage
 */
export function getAutoSaveMeta(): AutoSaveMeta | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(META_STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as AutoSaveMeta;
  } catch (err) {
    console.warn('Error reading autosave metadata:', err);
    return null;
  }
}

/**
 * Save current PDF Editor state & buffer to localStorage + IndexedDB
 */
export async function saveEditorSession(payload: AutoSavePayload): Promise<AutoSaveMeta> {
  const now = Date.now();
  const timeFormatted = new Date(now).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const sizeBytes = payload.buffer.byteLength;

  const meta: AutoSaveMeta = {
    id: `session_${now}`,
    fileName: payload.fileName || 'document.pdf',
    pageCount: payload.pageCount || 1,
    activePage: payload.activePage || 1,
    pageSequence:
      payload.pageSequence && payload.pageSequence.length > 0
        ? payload.pageSequence
        : Array.from({ length: payload.pageCount || 1 }, (_, i) => i + 1),
    selectedFlow: payload.selectedFlow || 'upload',
    savedAt: now,
    savedAtFormatted: timeFormatted,
    sizeBytes,
    hasBuffer: true,
  };

  // 1. Write metadata to localStorage
  try {
    localStorage.setItem(META_STORAGE_KEY, JSON.stringify(meta));
  } catch (err) {
    console.warn('Could not write autosave meta to localStorage:', err);
  }

  // 2. Persist binary buffer into IndexedDB
  let idbSuccess = false;
  try {
    await idbSet(SESSION_KEY, {
      meta,
      buffer: payload.buffer,
      timestamp: now,
    });
    idbSuccess = true;
  } catch (err) {
    console.warn('IndexedDB auto-save failed, attempting localStorage fallback:', err);
  }

  // 3. Fallback to localStorage base64 if IndexedDB failed or for small files (< 2MB)
  if (!idbSuccess || sizeBytes < 2 * 1024 * 1024) {
    try {
      const b64 = arrayBufferToBase64(payload.buffer);
      localStorage.setItem(BUFFER_FALLBACK_KEY, b64);
    } catch (quotaErr) {
      // Quota exceeded in localStorage, which is normal for large PDFs; IndexedDB already holds it
      console.info('localStorage quota full for buffer (handled cleanly):', quotaErr);
    }
  }

  return meta;
}

/**
 * Load auto-saved session (metadata + PDF ArrayBuffer)
 */
export async function loadEditorSession(): Promise<{
  buffer: ArrayBuffer | null;
  meta: AutoSaveMeta | null;
} | null> {
  const meta = getAutoSaveMeta();

  // Try loading from IndexedDB first
  try {
    const record = await idbGet<{ meta: AutoSaveMeta; buffer: ArrayBuffer }>(SESSION_KEY);
    if (record && record.buffer && record.buffer.byteLength > 0) {
      return {
        buffer: record.buffer,
        meta: record.meta || meta,
      };
    }
  } catch (err) {
    console.warn('Error reading from IndexedDB:', err);
  }

  // Fallback to localStorage base64
  try {
    const rawB64 = localStorage.getItem(BUFFER_FALLBACK_KEY);
    if (rawB64 && meta) {
      const buffer = base64ToArrayBuffer(rawB64);
      return {
        buffer,
        meta,
      };
    }
  } catch (err) {
    console.warn('Error decoding fallback buffer from localStorage:', err);
  }

  if (meta) {
    return { buffer: null, meta };
  }

  return null;
}

/**
 * Clear auto-saved session from both localStorage and IndexedDB
 */
export async function clearEditorSession(): Promise<void> {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(META_STORAGE_KEY);
    localStorage.removeItem(BUFFER_FALLBACK_KEY);
  } catch (err) {
    console.warn('Error clearing localStorage autosave:', err);
  }

  try {
    await idbDelete(SESSION_KEY);
  } catch (err) {
    console.warn('Error clearing IndexedDB autosave:', err);
  }
}
