import React from 'react';
import { PageType } from '../types';
import { PresslyIcon } from './Logos';
import { Shield, Lock, Trash2, Heart } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: PageType, sectionId?: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-[#1B2740] text-white pt-16 pb-12 border-t border-[#1B2740]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          {/* Col 1 & 2: Brand Info */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="p-1 bg-white rounded-lg">
                <PresslyIcon size={32} />
              </div>
              <span className="font-fraunces text-2xl font-medium tracking-tight text-white">pressly</span>
            </div>
            <p className="text-[#6B7280] text-sm max-w-sm leading-relaxed">
              Every PDF tool in one place. Merge, split, edit, convert, sign, and protect your PDF files in your browser with zero data retention.
            </p>
            <div className="flex items-center space-x-6 text-xs text-white/70 pt-2">
              <span className="inline-flex items-center gap-1.5">
                <Lock size={14} className="text-[#C4432E]" /> 256-Bit SSL
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Trash2 size={14} className="text-[#C4432E]" /> Auto-Purge 1h
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Shield size={14} className="text-[#C4432E]" /> No Storage
              </span>
            </div>
          </div>

          {/* Col 3: Tools */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white/50 mb-4 font-ibm-mono">
              Popular Tools
            </h4>
            <ul className="space-y-2.5 text-sm text-white/80">
              <li>
                <button
                  onClick={() => onNavigate('editor')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  Merge PDF
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('editor')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  Split PDF
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('editor')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  Compress PDF
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('editor')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  PDF to Word
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('editor')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  E-Sign PDF
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('editor')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  Protect & Encrypt
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Company */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white/50 mb-4 font-ibm-mono">
              Company
            </h4>
            <ul className="space-y-2.5 text-sm text-white/80">
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  About Pressly
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('home')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  100% Free Access
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('faq')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  Help & FAQ
                </button>
              </li>
              <li>
                <a href="#contact" className="hover:text-[#C4432E] transition-colors cursor-pointer">
                  Contact Support
                </a>
              </li>
            </ul>
          </div>

          {/* Col 5: Legal & Social */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-white/50 mb-4 font-ibm-mono">
              Legal & Compliance
            </h4>
            <ul className="space-y-2.5 text-sm text-white/80">
              <li>
                <button
                  onClick={() => onNavigate('privacy')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('privacy')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  Terms of Service
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('privacy')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  Security Standards
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('privacy')}
                  className="hover:text-[#C4432E] transition-colors cursor-pointer"
                >
                  GDPR & HIPAA
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-white/50 gap-4">
          <p>© {new Date().getFullYear()} Pressly Inc. All rights reserved.</p>
          <p className="inline-flex items-center gap-1">
            Engineered with <Heart size={12} className="text-[#C4432E] fill-[#C4432E]" /> for zero friction PDF workflows.
          </p>
        </div>
      </div>
    </footer>
  );
};
