import React, { useState } from 'react';
import { PageType } from '../types';
import { PresslyFullLockup } from './Logos';
import { Menu, X, ArrowRight, Download, WifiOff, CheckCircle2, Sparkles } from 'lucide-react';

interface HeaderProps {
  currentPage: PageType;
  onNavigate: (page: PageType, toolId?: string) => void;
  isOnline?: boolean;
  isInstallable?: boolean;
  isInstalled?: boolean;
  onInstallClick?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  onNavigate,
  isOnline = true,
  isInstallable = false,
  isInstalled = false,
  onInstallClick,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { label: string; page: PageType }[] = [
    { label: 'Tools', page: 'home' },
    { label: 'Editor', page: 'editor' },
    { label: 'FAQ', page: 'faq' },
    { label: 'Privacy', page: 'privacy' },
  ];

  const handleNavClick = (page: PageType, sectionId?: string) => {
    setMobileMenuOpen(false);
    onNavigate(page);
    if (sectionId && page === 'home') {
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-[#E8E8E6] transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 sm:h-20 flex items-center justify-between">
        {/* Left: Brand Logo Lockup & Offline Status Badge */}
        <div className="flex items-center gap-3 sm:gap-4">
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2 text-left focus:outline-none group cursor-pointer"
            aria-label="Pressly Home"
          >
            <PresslyFullLockup height={32} className="transition-transform group-hover:scale-[1.01]" />
          </button>

          {/* Real-time Offline Ready Badge */}
          <div
            className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-ibm-mono font-semibold border transition-colors cursor-default"
            title={
              isOnline
                ? 'Online • 100% Real-time client-side processing without server uploads'
                : 'Offline Mode Active • Real-time processing enabled'
            }
          >
            {isOnline ? (
              <span className="flex items-center gap-1.5 text-emerald-700 bg-emerald-50 border border-emerald-200/80 px-2 py-0.5 rounded-full">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>100% Offline Ready</span>
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-amber-700 bg-amber-50 border border-amber-200/80 px-2 py-0.5 rounded-full">
                <WifiOff size={11} className="text-amber-600" />
                <span>Offline Mode</span>
              </span>
            )}
          </div>
        </div>

        {/* Center-Right: Desktop Nav */}
        <nav className="hidden md:flex items-center space-x-7">
          <button
            onClick={() => handleNavClick('home', 'tools-grid')}
            className="text-sm font-medium text-[#6B7280] hover:text-[#1B2740] transition-colors cursor-pointer"
          >
            Tools
          </button>
          <button
            onClick={() => handleNavClick('editor')}
            className={`text-sm font-medium transition-colors cursor-pointer ${
              currentPage === 'editor' ? 'text-[#C4432E] font-semibold' : 'text-[#6B7280] hover:text-[#1B2740]'
            }`}
          >
            Editor
          </button>
          <button
            onClick={() => handleNavClick('faq')}
            className={`text-sm font-medium transition-colors cursor-pointer ${
              currentPage === 'faq' ? 'text-[#C4432E] font-semibold' : 'text-[#6B7280] hover:text-[#1B2740]'
            }`}
          >
            FAQ
          </button>
          <button
            onClick={() => handleNavClick('privacy')}
            className={`text-sm font-medium transition-colors cursor-pointer ${
              currentPage === 'privacy' ? 'text-[#C4432E] font-semibold' : 'text-[#6B7280] hover:text-[#1B2740]'
            }`}
          >
            Privacy
          </button>
        </nav>

        {/* Right CTA & PWA Install Button */}
        <div className="hidden md:flex items-center space-x-3.5">
          {/* PWA Install Button */}
          {!isInstalled && onInstallClick && (
            <button
              id="header-install-pwa-btn"
              type="button"
              onClick={onInstallClick}
              className="inline-flex items-center gap-1.5 bg-[#F6F6F4] hover:bg-[#E8E8E6] text-[#1B2740] hover:text-[#C4432E] text-xs font-semibold px-3.5 py-2 rounded-lg border border-[#E8E8E6] transition-all cursor-pointer shadow-2xs"
              title="Install Pressly to your desktop or mobile device for offline use"
            >
              <Download size={14} className="text-[#C4432E]" />
              <span>Install App</span>
            </button>
          )}

          {isInstalled && (
            <div className="inline-flex items-center gap-1 text-xs text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-1.5 rounded-lg border border-emerald-100 font-ibm-mono">
              <CheckCircle2 size={13} className="text-emerald-600" />
              <span>Installed</span>
            </div>
          )}

          <button
            onClick={() => handleNavClick('editor')}
            className="text-sm font-medium text-[#1B2740] hover:text-[#C4432E] transition-colors cursor-pointer"
          >
            Sign in
          </button>
          <button
            onClick={() => handleNavClick('editor')}
            className="inline-flex items-center gap-2 bg-[#C4432E] hover:bg-[#a83623] text-white text-sm font-medium px-5 py-2.5 rounded-lg shadow-xs transition-all transform hover:-translate-y-0.5 cursor-pointer"
          >
            Try Free
            <ArrowRight size={15} />
          </button>
        </div>

        {/* Mobile Buttons */}
        <div className="flex md:hidden items-center gap-2">
          {!isInstalled && onInstallClick && (
            <button
              id="mobile-header-install-btn"
              type="button"
              onClick={onInstallClick}
              className="inline-flex items-center gap-1 bg-[#F6F6F4] text-[#1B2740] text-xs font-semibold px-2.5 py-1.5 rounded-md border border-[#E8E8E6] cursor-pointer"
            >
              <Download size={13} className="text-[#C4432E]" />
              <span>Install</span>
            </button>
          )}

          <button
            onClick={() => handleNavClick('editor')}
            className="bg-[#C4432E] text-white text-xs font-medium px-3 py-1.5 rounded-md cursor-pointer"
          >
            Try Free
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-[#1B2740] hover:bg-[#F6F6F4] focus:outline-none"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-[#E8E8E6] px-4 pt-3 pb-6 space-y-3 animate-in fade-in duration-150">
          {/* Offline Status Badge in Mobile Menu */}
          <div className="px-3 py-2 bg-[#F6F6F4] rounded-lg border border-[#E8E8E6] flex items-center justify-between text-xs font-ibm-mono">
            <span className="text-[#6B7280]">Connection Status:</span>
            {isOnline ? (
              <span className="text-emerald-700 font-bold flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500" />
                100% Offline Ready
              </span>
            ) : (
              <span className="text-amber-700 font-bold flex items-center gap-1">
                <WifiOff size={12} />
                Offline Mode
              </span>
            )}
          </div>

          {!isInstalled && onInstallClick && (
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onInstallClick();
              }}
              className="w-full text-left px-3 py-2.5 text-sm font-bold text-white bg-[#C4432E] rounded-lg flex items-center gap-2 shadow-xs"
            >
              <Download size={16} />
              <span>Install Pressly App to Home Screen</span>
            </button>
          )}

          <button
            onClick={() => handleNavClick('editor')}
            className="w-full text-left px-3 py-2 text-base font-medium text-[#1B2740] bg-[#F6F6F4] rounded-lg"
          >
            Launch Online Editor
          </button>
          <button
            onClick={() => handleNavClick('home', 'tools-grid')}
            className="w-full text-left px-3 py-2 text-base font-medium text-[#6B7280] hover:text-[#1B2740]"
          >
            All Tools
          </button>
          <button
            onClick={() => handleNavClick('faq')}
            className="w-full text-left px-3 py-2 text-base font-medium text-[#6B7280] hover:text-[#1B2740]"
          >
            FAQ
          </button>
          <button
            onClick={() => handleNavClick('privacy')}
            className="w-full text-left px-3 py-2 text-base font-medium text-[#6B7280] hover:text-[#1B2740]"
          >
            Privacy Policy
          </button>
          <div className="pt-2 border-t border-[#E8E8E6] flex justify-between items-center px-3">
            <span className="text-sm text-[#6B7280]">Account</span>
            <button
              onClick={() => handleNavClick('editor')}
              className="text-sm font-semibold text-[#C4432E]"
            >
              Sign In
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

