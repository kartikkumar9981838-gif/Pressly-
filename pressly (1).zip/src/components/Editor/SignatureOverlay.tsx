import React, { useState, useRef } from 'react';
import { SignatureDraft } from '../../types';
import { Check, X, Move, Maximize2 } from 'lucide-react';

interface SignatureOverlayProps {
  signature: SignatureDraft;
  onUpdateSignature: (updated: SignatureDraft) => void;
  onBake: () => void;
  onCancel: () => void;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  zoomLevel?: number;
}

export const SignatureOverlay: React.FC<SignatureOverlayProps> = ({
  signature,
  onUpdateSignature,
  onBake,
  onCancel,
  canvasRef,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);

  const dragStartRef = useRef<{ mouseX: number; mouseY: number; initXRatio: number; initYRatio: number }>({
    mouseX: 0,
    mouseY: 0,
    initXRatio: 0.5,
    initYRatio: 0.5,
  });

  const resizeStartRef = useRef<{ mouseX: number; initWidthRatio: number }>({
    mouseX: 0,
    initWidthRatio: 0.25,
  });

  // DRAG HANDLERS
  const handlePointerDownDrag = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
    dragStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      initXRatio: signature.xRatio,
      initYRatio: signature.yRatio,
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMoveDrag = (e: React.PointerEvent) => {
    if (!isDragging || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    const dx = e.clientX - dragStartRef.current.mouseX;
    const dy = e.clientY - dragStartRef.current.mouseY;

    let newXRatio = dragStartRef.current.initXRatio + dx / rect.width;
    let newYRatio = dragStartRef.current.initYRatio + dy / rect.height;

    // Constrain within bounds (5% to 95%)
    newXRatio = Math.max(0.05, Math.min(0.95, newXRatio));
    newYRatio = Math.max(0.05, Math.min(0.95, newYRatio));

    onUpdateSignature({
      ...signature,
      xRatio: newXRatio,
      yRatio: newYRatio,
    });
  };

  const handlePointerUpDrag = (e: React.PointerEvent) => {
    if (isDragging) {
      setIsDragging(false);
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {}
    }
  };

  // RESIZE HANDLERS (Corner drag)
  const handlePointerDownResize = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsResizing(true);
    resizeStartRef.current = {
      mouseX: e.clientX,
      initWidthRatio: signature.widthRatio,
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMoveResize = (e: React.PointerEvent) => {
    if (!isResizing || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    if (rect.width === 0) return;

    const dx = e.clientX - resizeStartRef.current.mouseX;
    const dxRatio = dx / rect.width;

    const newWidthRatio = Math.max(0.08, Math.min(0.85, resizeStartRef.current.initWidthRatio + dxRatio * 1.5));
    onUpdateSignature({
      ...signature,
      widthRatio: newWidthRatio,
    });
  };

  const handlePointerUpResize = (e: React.PointerEvent) => {
    if (isResizing) {
      setIsResizing(false);
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {}
    }
  };

  const posXPercent = signature.xRatio * 100;
  const posYPercent = signature.yRatio * 100;
  const widthPercent = signature.widthRatio * 100;

  return (
    <div className="absolute inset-0 pointer-events-none z-30 overflow-visible">
      <div
        style={{
          left: `${posXPercent}%`,
          top: `${posYPercent}%`,
          width: `${widthPercent}%`,
          transform: 'translate(-50%, -50%)',
        }}
        className="absolute pointer-events-auto group cursor-move select-none touch-none"
        onPointerDown={handlePointerDownDrag}
        onPointerMove={handlePointerMoveDrag}
        onPointerUp={handlePointerUpDrag}
      >
        <div
          className={`relative p-2 rounded-xl border-2 transition-all ${
            isDragging
              ? 'border-[#C4432E] shadow-2xl bg-[#C4432E]/10 scale-102'
              : 'border-dashed border-[#C4432E] bg-white/20 hover:bg-white/30 hover:border-[#C4432E] shadow-xl backdrop-blur-xs'
          }`}
        >
          {/* ACTION BAR DIRECTLY ABOVE SIGNATURE BOX */}
          <div
            className="absolute -top-11 left-1/2 -translate-x-1/2 flex items-center space-x-1.5 bg-[#1B2740] text-white px-2.5 py-1 rounded-lg shadow-2xl border border-white/20 opacity-95 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 pointer-events-auto"
            onPointerDown={(e) => e.stopPropagation()}
          >
            <div className="flex items-center space-x-1 text-[10px] text-gray-300 font-medium mr-1">
              <Move size={11} className="text-[#C4432E]" />
              <span>Drag signature to position</span>
            </div>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onBake();
              }}
              className="px-2.5 py-0.5 rounded bg-[#C4432E] hover:bg-[#a83522] text-white text-[11px] font-bold shadow transition-transform cursor-pointer flex items-center space-x-1 active:scale-95"
              title="Bake signature into PDF at this exact position"
            >
              <Check size={12} />
              <span>Bake</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onCancel();
              }}
              className="p-0.5 rounded hover:bg-white/20 text-gray-300 hover:text-white cursor-pointer"
              title="Cancel"
            >
              <X size={12} />
            </button>
          </div>

          {/* RENDERED SIGNATURE IMAGE */}
          <img
            src={signature.imageDataUrl}
            alt="E-Signature"
            className="w-full h-auto object-contain pointer-events-none drop-shadow-sm select-none"
          />

          {/* CORNER RESIZE HANDLE (BOTTOM-RIGHT) */}
          <div
            onPointerDown={handlePointerDownResize}
            onPointerMove={handlePointerMoveResize}
            onPointerUp={handlePointerUpResize}
            className="absolute -bottom-3 -right-3 w-7 h-7 bg-[#C4432E] text-white rounded-full flex items-center justify-center cursor-nwse-resize shadow-xl border-2 border-white hover:scale-125 transition-transform"
            title="Drag to resize signature"
          >
            <Maximize2 size={13} />
          </div>
        </div>
      </div>
    </div>
  );
};
