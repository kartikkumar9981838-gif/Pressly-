import React, { useState, useRef, useEffect, useLayoutEffect } from 'react';
import { EditorMode, PDFTool, WatermarkDraft, SignatureDraft, ImageDraft } from '../../types';
import { WatermarkOverlay } from './WatermarkOverlay';
import { SignatureOverlay } from './SignatureOverlay';
import { ImageOverlay } from './ImageOverlay';
import { EditTextOverlay } from './EditTextOverlay';
import { FindReplaceHighlightOverlay } from './FindReplaceHighlightOverlay';
import { FindMatchItem } from '../../lib/pdfEngine';
import {
  FileText,
  Upload,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Grid,
  Trash2,
  Sparkles,
  CheckCircle2,
  Plus,
  Check,
  RefreshCw,
  Download,
  FileCheck,
  ArrowRight,
  X,
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  List,
  ListOrdered,
  Table as TableIcon,
  Image as ImageIcon,
  Link as LinkIcon,
  Undo2,
  Redo2,
  Highlighter,
  Baseline,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  ArrowUp,
  ArrowDown,
  FileEdit,
  Archive,
  FileImage,
  Eye,
} from 'lucide-react';

import {
  loadPdfJsDoc,
  renderPageToCanvas,
  convertImagesToPdf,
  downloadPdfBytes,
  convertPdfToImages,
  downloadSingleImage,
  downloadImagesAsZip,
  PdfToImageResult,
} from '../../lib/pdfEngine';

interface EditorCanvasProps {
  selectedFlow: EditorMode | null;
  onSelectFlow: (flow: EditorMode) => void;
  hasFile: boolean;
  pdfBuffer: ArrayBuffer | null;
  pdfFileName: string;
  pageCount: number;
  activePage: number;
  setActivePage: (p: number) => void;
  thumbnails: string[];
  isLoadingFile: boolean;
  uploadError: string | null;
  onUploadPdfFile: (file: File) => void;
  onResetFile: () => void;
  activeTool: PDFTool | null;
  activeToolMessage: string | null;
  onUpdatePdfBuffer?: (newBuffer: ArrayBuffer, message: string, fileName?: string) => void;
  watermarkDraft?: WatermarkDraft | null;
  setWatermarkDraft?: (draft: WatermarkDraft | null) => void;
  onBakeWatermark?: (draft: WatermarkDraft) => void;
  signatureDraft?: SignatureDraft | null;
  setSignatureDraft?: (draft: SignatureDraft | null) => void;
  onBakeSignature?: (draft: SignatureDraft) => void;
  imageDraft?: ImageDraft | null;
  setImageDraft?: (draft: ImageDraft | null) => void;
  onBakeImage?: (draft: ImageDraft) => void;
  isEditTextActive?: boolean;
  setIsEditTextActive?: (val: boolean) => void;
  isFindReplaceActive?: boolean;
  setIsFindReplaceActive?: (val: boolean) => void;
  findReplaceMatchesByPage?: Record<number, FindMatchItem[]>;
  focusedMatchId?: string | null;
  onSelectMatch?: (match: FindMatchItem) => void;
}

export interface DocBlock {
  id: string;
  type: 'heading' | 'subtitle' | 'paragraph' | 'bullet' | 'number';
  text: string;
  fontFamily: 'font-ibm-sans' | 'font-fraunces' | 'font-mono' | 'font-serif';
  fontSize: string;
  isBold: boolean;
  isItalic: boolean;
  isUnderline: boolean;
  alignment: 'left' | 'center' | 'right' | 'justify';
  textColor: string;
  highlightColor: string;
}

const CONVERSION_CHIPS = [
  'Image to PDF',
  'Word to PDF',
  'Excel to PDF',
  'PPT to PDF',
  'HTML to PDF',
  'PDF to Word',
  'PDF to Excel',
  'PDF to PPT',
  'PDF to JPG',
];

export const EditorCanvas: React.FC<EditorCanvasProps> = ({
  selectedFlow,
  onSelectFlow,
  hasFile,
  pdfBuffer,
  pdfFileName,
  pageCount,
  activePage,
  setActivePage,
  thumbnails,
  isLoadingFile,
  uploadError,
  onUploadPdfFile,
  onResetFile,
  activeTool,
  activeToolMessage,
  onUpdatePdfBuffer,
  watermarkDraft,
  setWatermarkDraft,
  onBakeWatermark,
  signatureDraft,
  setSignatureDraft,
  onBakeSignature,
  imageDraft,
  setImageDraft,
  onBakeImage,
  isEditTextActive,
  setIsEditTextActive,
  isFindReplaceActive,
  setIsFindReplaceActive,
  findReplaceMatchesByPage,
  focusedMatchId,
  onSelectMatch,
}) => {
  // Canvas & File Input Refs
  const pdfCanvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Upload & Edit Mode State
  const [zoomLevel, setZoomLevel] = useState(100);
  const [rotation, setRotation] = useState(0);
  const [showGrid, setShowGrid] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  // Keep activePage bounded to valid pageCount range
  useEffect(() => {
    if (pageCount > 0 && activePage > pageCount) {
      setActivePage(pageCount);
    }
  }, [pageCount, activePage, setActivePage]);

  // Render PDF Page to Canvas using PDF.js engine
  useEffect(() => {
    let isMounted = true;
    if (pdfBuffer && pdfCanvasRef.current && hasFile && selectedFlow === 'upload') {
      loadPdfJsDoc(pdfBuffer)
        .then((jsDoc) => {
          if (isMounted && pdfCanvasRef.current) {
            const scale = (zoomLevel / 100) * 1.5;
            renderPageToCanvas(jsDoc, activePage, pdfCanvasRef.current, scale);
          }
        })
        .catch((err) => console.error('Error rendering page to canvas:', err));
    }
    return () => {
      isMounted = false;
    };
  }, [pdfBuffer, activePage, zoomLevel, rotation, hasFile, selectedFlow]);

  // Convert Mode State
  const [convertFile, setConvertFile] = useState<string | null>(null);
  const [selectedChip, setSelectedChip] = useState<string | null>(null);
  const [isConvertModalOpen, setIsConvertModalOpen] = useState(false);
  const [convertedOutputName, setConvertedOutputName] = useState<string>('document_converted.pdf');

  // Default content for Page 1 - Completely blank page
  const defaultPage1Blocks: DocBlock[] = [
    {
      id: 'block-p1-1',
      type: 'paragraph',
      text: '',
      fontFamily: 'font-serif',
      fontSize: '12pt',
      isBold: false,
      isItalic: false,
      isUnderline: false,
      alignment: 'left',
      textColor: '#1B2740',
      highlightColor: 'transparent',
    },
  ];

  // MS Word Style "Create PDF" State - Per-Page Block-Based Editor
  const [pagesBlocks, setPagesBlocks] = useState<Record<number, DocBlock[]>>({
    1: defaultPage1Blocks,
  });

  const [wordPageCount, setWordPageCount] = useState<number>(1);
  const [activeWordPage, setActiveWordPage] = useState<number>(1);

  // Current active page blocks
  const blocks = pagesBlocks[activeWordPage] || [
    {
      id: `block-p${activeWordPage}-1`,
      type: 'paragraph',
      text: '',
      fontFamily: 'font-serif',
      fontSize: '12pt',
      isBold: false,
      isItalic: false,
      isUnderline: false,
      alignment: 'left',
      textColor: '#1B2740',
      highlightColor: 'transparent',
    },
  ];

  // Helper to update current page blocks
  const setCurrentPageBlocks = (updater: DocBlock[] | ((prev: DocBlock[]) => DocBlock[])) => {
    setPagesBlocks((prevPages) => {
      const current = prevPages[activeWordPage] || [];
      const nextBlocks = typeof updater === 'function' ? updater(current) : updater;
      return {
        ...prevPages,
        [activeWordPage]: nextBlocks,
      };
    });
  };

  // Stack-based History State for Undo / Redo
  const [history, setHistory] = useState<Record<number, DocBlock[]>[]>([
    {
      1: defaultPage1Blocks,
    },
  ]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);

  // Auto-Save Notification Toast State
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving'>('saved');
  const saveTimerRef = useRef<NodeJS.Timeout | null>(null);

  const triggerAutoSave = () => {
    setSaveStatus('saving');
    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current);
    }
    saveTimerRef.current = setTimeout(() => {
      setSaveStatus('saved');
    }, 2000);
  };

  const pushToHistory = (newBlocks: DocBlock[]) => {
    const updatedPagesBlocks = {
      ...pagesBlocks,
      [activeWordPage]: newBlocks,
    };
    setHistory((prevHistory) => {
      const sliced = prevHistory.slice(0, historyIndex + 1);
      return [...sliced, updatedPagesBlocks];
    });
    setHistoryIndex((prev) => prev + 1);
    setCurrentPageBlocks(newBlocks);
    triggerAutoSave();
  };

  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < history.length - 1;

  const handleUndo = () => {
    if (historyIndex > 0) {
      const prevIndex = historyIndex - 1;
      setHistoryIndex(prevIndex);
      setPagesBlocks(history[prevIndex]);
      triggerAutoSave();
    }
  };

  const handleRedo = () => {
    if (historyIndex < history.length - 1) {
      const nextIndex = historyIndex + 1;
      setHistoryIndex(nextIndex);
      setPagesBlocks(history[nextIndex]);
      triggerAutoSave();
    }
  };

  // Keyboard shortcut listener for Ctrl+Z and Ctrl+Y
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedFlow !== 'create') return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        if (e.shiftKey) {
          e.preventDefault();
          handleRedo();
        } else {
          e.preventDefault();
          handleUndo();
        }
      } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault();
        handleRedo();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedFlow, historyIndex, history]);

  const [activeBlockId, setActiveBlockId] = useState<string>('block-p1-1');
  const [insertedElements, setInsertedElements] = useState<('table' | 'image' | 'link')[]>([]);
  const [showOnboardingTip, setShowOnboardingTip] = useState<boolean>(true);

  // Paper Sheet Container Ref for strictly preventing internal scroll / hiding
  const paperRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    if (paperRef.current) {
      paperRef.current.scrollTop = 0;
    }
  }, [activeWordPage, blocks]);

  useEffect(() => {
    if (selectedFlow === 'create') {
      const el = document.getElementById('textarea-block-p1-1') as HTMLTextAreaElement;
      if (el) {
        el.focus({ preventScroll: true });
      }
    }
  }, [selectedFlow]);

  const getTextAreaRows = (text: string, charsPerLine = 60) => {
    if (!text) return 1;
    const lines = text.split('\n');
    let totalRows = 0;
    for (const line of lines) {
      totalRows += Math.max(1, Math.ceil((line.length || 1) / charsPerLine));
    }
    return Math.max(1, totalRows);
  };

  // Active Block Helper
  const activeBlock = blocks.find((b) => b.id === activeBlockId) || blocks[0];

  // Update Active Block Properties from Top Toolbar
  const updateActiveBlock = (updates: Partial<DocBlock>) => {
    if (!activeBlockId) return;
    const updated = blocks.map((block) =>
      block.id === activeBlockId ? { ...block, ...updates } : block
    );
    pushToHistory(updated);
  };

  // Text Change and Blur Handlers
  const handleBlockTextChange = (id: string, text: string) => {
    setCurrentPageBlocks((prev) => prev.map((b) => (b.id === id ? { ...b, text } : b)));
    triggerAutoSave();
  };

  const handleBlockBlur = (id: string, text: string) => {
    if (text.trim() === '' && blocks.length > 1) {
      const block = blocks.find((b) => b.id === id);
      if (block && block.type === 'paragraph') {
        setCurrentPageBlocks((prev) => prev.filter((b) => b.id !== id));
      }
    }
  };

  // Enter / Backspace keyboard handling inside text blocks
  const handleBlockKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>, blockId: string) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      const currIndex = blocks.findIndex((b) => b.id === blockId);

      // Calculate total rows on current page
      let totalPageRows = 0;
      for (const b of blocks) {
        totalPageRows += getTextAreaRows(b.text, b.type === 'heading' ? 28 : 60);
      }

      // If page capacity reached (>= 14 rows), move overflow content to a new separate page
      if (totalPageRows >= 14 || (currIndex === blocks.length - 1 && totalPageRows >= 13)) {
        const nextP = activeWordPage + 1;
        const newBlockId = `block-p${nextP}-${Date.now()}`;
        const newPageBlock: DocBlock = {
          id: newBlockId,
          type: 'paragraph',
          text: '',
          fontFamily: activeBlock ? activeBlock.fontFamily : 'font-serif',
          fontSize: '12pt',
          isBold: false,
          isItalic: false,
          isUnderline: false,
          alignment: activeBlock ? activeBlock.alignment : 'left',
          textColor: '#1B2740',
          highlightColor: 'transparent',
        };

        setPagesBlocks((prev) => ({
          ...prev,
          [nextP]: prev[nextP] ? [...prev[nextP], newPageBlock] : [newPageBlock],
        }));
        if (nextP > wordPageCount) {
          setWordPageCount(nextP);
        }
        setActiveWordPage(nextP);
        setActiveBlockId(newBlockId);
        setTimeout(() => {
          const el = document.getElementById(`textarea-${newBlockId}`) as HTMLTextAreaElement;
          if (el) el.focus({ preventScroll: true });
        }, 50);
        return;
      }

      const newId = `block-p${activeWordPage}-${Date.now()}`;
      const newBlock: DocBlock = {
        id: newId,
        type: 'paragraph',
        text: '',
        fontFamily: activeBlock ? activeBlock.fontFamily : 'font-serif',
        fontSize: '12pt',
        isBold: false,
        isItalic: false,
        isUnderline: false,
        alignment: activeBlock ? activeBlock.alignment : 'left',
        textColor: '#1B2740',
        highlightColor: 'transparent',
      };
      const nextBlocks = [
        ...blocks.slice(0, currIndex + 1),
        newBlock,
        ...blocks.slice(currIndex + 1),
      ];
      pushToHistory(nextBlocks);
      setActiveBlockId(newId);
      setTimeout(() => {
        const el = document.getElementById(`textarea-${newId}`);
        if (el) el.focus({ preventScroll: true });
      }, 50);
    } else if (e.key === 'Backspace') {
      const block = blocks.find((b) => b.id === blockId);
      if (block && block.text === '') {
        if (blocks.length > 1) {
          e.preventDefault();
          const currIndex = blocks.findIndex((b) => b.id === blockId);
          const prevBlock = blocks[currIndex - 1] || blocks[currIndex + 1];
          const nextBlocks = blocks.filter((b) => b.id !== blockId);
          pushToHistory(nextBlocks);
          if (prevBlock) {
            setActiveBlockId(prevBlock.id);
            setTimeout(() => {
              const el = document.getElementById(`textarea-${prevBlock.id}`) as HTMLTextAreaElement;
              if (el) {
                el.focus({ preventScroll: true });
                el.setSelectionRange(el.value.length, el.value.length);
              }
            }, 50);
          }
        } else if (activeWordPage > 1) {
          // On empty page, Backspace moves back to previous page
          e.preventDefault();
          const prevP = activeWordPage - 1;
          setActiveWordPage(prevP);
          const prevBlocks = pagesBlocks[prevP] || [];
          const lastPrevBlock = prevBlocks[prevBlocks.length - 1];
          if (lastPrevBlock) {
            setActiveBlockId(lastPrevBlock.id);
            setTimeout(() => {
              const el = document.getElementById(`textarea-${lastPrevBlock.id}`) as HTMLTextAreaElement;
              if (el) {
                el.focus({ preventScroll: true });
                el.setSelectionRange(el.value.length, el.value.length);
              }
            }, 50);
          }
        }
      }
    }
  };

  // Add a new paragraph block at bottom when clicking empty paper space or focus last block
  const handleAddParagraphBlock = () => {
    let totalPageRows = 0;
    for (const b of blocks) {
      totalPageRows += getTextAreaRows(b.text, b.type === 'heading' ? 28 : 60);
    }
    if (totalPageRows >= 14) {
      handleAddPage();
      return;
    }

    const lastBlock = blocks[blocks.length - 1];
    if (lastBlock) {
      setActiveBlockId(lastBlock.id);
      setTimeout(() => {
        const el = document.getElementById(`textarea-${lastBlock.id}`) as HTMLTextAreaElement;
        if (el) {
          el.focus({ preventScroll: true });
          el.setSelectionRange(el.value.length, el.value.length);
        }
      }, 20);
      if (lastBlock.text === '') return;
    }
    const newId = `block-p${activeWordPage}-${Date.now()}`;
    const newBlock: DocBlock = {
      id: newId,
      type: 'paragraph',
      text: '',
      fontFamily: activeBlock ? activeBlock.fontFamily : 'font-serif',
      fontSize: '12pt',
      isBold: false,
      isItalic: false,
      isUnderline: false,
      alignment: activeBlock ? activeBlock.alignment : 'left',
      textColor: '#1B2740',
      highlightColor: 'transparent',
    };
    pushToHistory([...blocks, newBlock]);
    setActiveBlockId(newId);
    setTimeout(() => {
      const el = document.getElementById(`textarea-${newId}`) as HTMLTextAreaElement;
      if (el) el.focus({ preventScroll: true });
    }, 50);
  };

  // Add new page action - creates a completely blank new page
  const handleAddPage = () => {
    const nextP = wordPageCount + 1;
    const newBlockId = `block-p${nextP}-1`;
    const newBlankBlocks: DocBlock[] = [
      {
        id: newBlockId,
        type: 'paragraph',
        text: '',
        fontFamily: 'font-serif',
        fontSize: '12pt',
        isBold: false,
        isItalic: false,
        isUnderline: false,
        alignment: 'left',
        textColor: '#1B2740',
        highlightColor: 'transparent',
      },
    ];

    setPagesBlocks((prev) => ({
      ...prev,
      [nextP]: newBlankBlocks,
    }));
    setWordPageCount(nextP);
    setActiveWordPage(nextP);
    setActiveBlockId(newBlockId);

    setTimeout(() => {
      const el = document.getElementById(`textarea-${newBlockId}`) as HTMLTextAreaElement;
      if (el) el.focus({ preventScroll: true });
    }, 50);
  };

  // Switch active page
  const handleGoToPage = (targetPage: number) => {
    if (targetPage >= 1 && targetPage <= pageCount) {
      setActiveWordPage(targetPage);
      const targetBlocks = pagesBlocks[targetPage] || [];
      if (targetBlocks.length > 0) {
        const firstBlock = targetBlocks[0];
        setActiveBlockId(firstBlock.id);
        setTimeout(() => {
          const el = document.getElementById(`textarea-${firstBlock.id}`) as HTMLTextAreaElement;
          if (el) el.focus({ preventScroll: true });
        }, 50);
      }
    }
  };

  const handleZoom = (delta: number) => {
    setZoomLevel((prev) => Math.min(150, Math.max(50, prev + delta)));
  };

  const handleRotatePage = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  // Image to PDF Conversion State
  const [convertImages, setConvertImages] = useState<{ id: string; name: string; dataUrl: string; sizeStr: string }[]>([]);
  const [convertPageSize, setConvertPageSize] = useState<'a4' | 'letter' | 'fit'>('fit');
  const [convertOrientation, setConvertOrientation] = useState<'auto' | 'portrait' | 'landscape'>('auto');
  const [convertMargin, setConvertMargin] = useState<'none' | 'small' | 'medium' | 'large'>('none');
  const [isConvertingImages, setIsConvertingImages] = useState(false);
  const [convertError, setConvertError] = useState<string | null>(null);
  const [activeConvertMode, setActiveConvertMode] = useState<'image-to-pdf' | 'pdf-to-image' | 'ppt-to-pdf' | 'excel-to-pdf'>('image-to-pdf');

  // Conversion Output Result (stays inside Convert Mode!)
  const [conversionResult, setConversionResult] = useState<{
    bytes: Uint8Array;
    fileName: string;
    pageCount: number;
    sizeStr: string;
  } | null>(null);

  const handleAddImagesToConvert = (files: FileList | File[]) => {
    const arr = Array.from(files);
    setConvertError(null);
    arr.forEach((file) => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        if (dataUrl) {
          const sz = file.size >= 1024 * 1024 ? `${(file.size / (1024 * 1024)).toFixed(1)} MB` : `${Math.round(file.size / 1024)} KB`;
          setConvertImages((prev) => [
            ...prev,
            { id: `cimg-${Date.now()}-${Math.random()}`, name: file.name, dataUrl, sizeStr: sz },
          ]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRunImageToPdfConversion = async () => {
    if (convertImages.length === 0) {
      setConvertError('Please select or drag at least one image file (JPG, PNG, WebP) to convert.');
      return;
    }
    setIsConvertingImages(true);
    setConvertError(null);
    try {
      const urls = convertImages.map((i) => i.dataUrl);
      const pdfBytes = await convertImagesToPdf(urls, {
        pageSize: convertPageSize,
        orientation: convertOrientation,
        margin: convertMargin,
      });

      const sizeKb = (pdfBytes.byteLength / 1024).toFixed(1);
      const sizeStr = pdfBytes.byteLength >= 1024 * 1024
        ? `${(pdfBytes.byteLength / (1024 * 1024)).toFixed(2)} MB`
        : `${sizeKb} KB`;

      setConversionResult({
        bytes: pdfBytes,
        fileName: `converted_images_${Date.now().toString().slice(-4)}.pdf`,
        pageCount: convertImages.length,
        sizeStr,
      });
    } catch (err: any) {
      console.error('Image to PDF error:', err);
      setConvertError(err.message || 'Failed to convert images to PDF.');
    } finally {
      setIsConvertingImages(false);
    }
  };

  const handleOpenConvertedInEditor = () => {
    if (!conversionResult) return;
    if (onUpdatePdfBuffer) {
      onUpdatePdfBuffer(
        conversionResult.bytes.buffer,
        `Loaded converted PDF into editor!`,
        conversionResult.fileName
      );
    }
    onSelectFlow('upload');
  };

  const handleDownloadConverted = () => {
    if (!conversionResult) return;
    downloadPdfBytes(conversionResult.bytes, conversionResult.fileName);
  };

  // PDF to Image Conversion State
  const [pdfToImgFile, setPdfToImgFile] = useState<File | null>(null);
  const [pdfToImgFormat, setPdfToImgFormat] = useState<'png' | 'jpeg' | 'webp'>('png');
  const [pdfToImgDpi, setPdfToImgDpi] = useState<number>(2.0);
  const [isConvertingPdfToImg, setIsConvertingPdfToImg] = useState<boolean>(false);
  const [pdfToImgResults, setPdfToImgResults] = useState<PdfToImageResult[] | null>(null);

  const handleAddPdfToConvert = (files: FileList | File[]) => {
    const arr = Array.from(files);
    const pdf = arr.find((f) => f.type === 'application/pdf' || f.name.toLowerCase().endsWith('.pdf'));
    if (pdf) {
      setPdfToImgFile(pdf);
      setConvertError(null);
      setPdfToImgResults(null);
    } else {
      setConvertError('Please select a valid PDF file.');
    }
  };

  const handleRunPdfToImageConversion = async () => {
    let bufferToUse: ArrayBuffer | null = null;

    if (pdfToImgFile) {
      bufferToUse = await pdfToImgFile.arrayBuffer();
    } else if (pdfBuffer) {
      bufferToUse = pdfBuffer;
    } else {
      setConvertError('Please select or upload a PDF file to convert to images.');
      return;
    }

    setIsConvertingPdfToImg(true);
    setConvertError(null);

    try {
      const results = await convertPdfToImages(bufferToUse, {
        format: pdfToImgFormat,
        scale: pdfToImgDpi,
        quality: 0.95,
      });

      setPdfToImgResults(results);
    } catch (err: any) {
      console.error('PDF to Image error:', err);
      setConvertError(err.message || 'Failed to convert PDF into images.');
    } finally {
      setIsConvertingPdfToImg(false);
    }
  };

  const handleDownloadAllImagesZip = async () => {
    if (!pdfToImgResults || pdfToImgResults.length === 0) return;
    const base = pdfToImgFile
      ? pdfToImgFile.name.replace(/\.[^/.]+$/, '')
      : (pdfFileName ? pdfFileName.replace(/\.[^/.]+$/, '') : 'converted_pdf');
    await downloadImagesAsZip(pdfToImgResults, `${base}_images.zip`);
  };

  return (
    <div className={`flex-1 bg-[#F6F6F4] relative flex flex-col min-h-0 overflow-hidden ${selectedFlow === 'create' ? '' : 'bg-dot-pattern'}`}>
      {/* ----------------- STEP 1: SELECTION SCREEN (WHEN NO FLOW SELECTED) ----------------- */}
      {selectedFlow === null && (
        <div className="w-full flex-1 flex flex-col items-center justify-start p-6 sm:p-10 md:p-12 overflow-y-auto animate-fade-in-slide my-auto">
          <div className="text-center max-w-2xl mx-auto my-6 sm:my-8 space-y-3">
            <h1 className="font-fraunces text-3xl sm:text-4xl lg:text-5xl font-medium text-[#1B2740]">
              What would you like to do?
            </h1>
            <p className="text-sm sm:text-base text-[#6B7280] font-ibm-sans">
              Select a workflow below to start processing your documents.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 w-full max-w-5xl mx-auto pb-16 px-2">
            {/* Card 1: Upload PDF */}
            <div
              onClick={() => onSelectFlow('upload')}
              className="bg-white rounded-2xl border border-[#E8E8E6] p-8 sm:p-10 soft-card-shadow hover:shadow-xl hover:border-[#C4432E] transform hover:-translate-y-1.5 transition-all duration-200 cursor-pointer group flex flex-col justify-between space-y-6 relative"
            >
              <div className="space-y-5">
                <div className="w-14 h-14 rounded-2xl bg-[#1B2740]/8 group-hover:bg-[#C4432E]/10 text-[#1B2740] group-hover:text-[#C4432E] flex items-center justify-center transition-colors">
                  <FileText size={28} />
                </div>
                <div>
                  <h2 className="font-fraunces text-2xl font-medium text-[#1B2740] group-hover:text-[#C4432E] transition-colors mb-2">
                    Upload PDF
                  </h2>
                  <p className="text-xs sm:text-sm text-[#6B7280] leading-relaxed">
                    Edit, merge, split, sign an existing PDF
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-[#E8E8E6] flex items-center justify-between text-xs font-semibold text-[#1B2740] group-hover:text-[#C4432E] font-ibm-mono transition-colors">
                <span>Start Flow</span>
                <ArrowRight size={16} className="transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Card 2: Create PDF */}
            <div
              onClick={() => onSelectFlow('create')}
              className="bg-white rounded-2xl border border-[#E8E8E6] p-8 sm:p-10 soft-card-shadow hover:shadow-xl hover:border-[#C4432E] transform hover:-translate-y-1.5 transition-all duration-200 cursor-pointer group flex flex-col justify-between space-y-6 relative"
            >
              <div className="space-y-5">
                <div className="w-14 h-14 rounded-2xl bg-[#1B2740]/8 group-hover:bg-[#C4432E]/10 text-[#1B2740] group-hover:text-[#C4432E] flex items-center justify-center transition-colors">
                  <Plus size={28} />
                </div>
                <div>
                  <h2 className="font-fraunces text-2xl font-medium text-[#1B2740] group-hover:text-[#C4432E] transition-colors mb-2">
                    Create PDF
                  </h2>
                  <p className="text-xs sm:text-sm text-[#6B7280] leading-relaxed">
                    Design a new PDF from a blank canvas
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-[#E8E8E6] flex items-center justify-between text-xs font-semibold text-[#1B2740] group-hover:text-[#C4432E] font-ibm-mono transition-colors">
                <span>Blank Canvas</span>
                <ArrowRight size={16} className="transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>

            {/* Card 3: Convert PDF */}
            <div
              onClick={() => onSelectFlow('convert')}
              className="bg-white rounded-2xl border border-[#E8E8E6] p-8 sm:p-10 soft-card-shadow hover:shadow-xl hover:border-[#C4432E] transform hover:-translate-y-1.5 transition-all duration-200 cursor-pointer group flex flex-col justify-between space-y-6 relative"
            >
              <div className="space-y-5">
                <div className="w-14 h-14 rounded-2xl bg-[#1B2740]/8 group-hover:bg-[#C4432E]/10 text-[#1B2740] group-hover:text-[#C4432E] flex items-center justify-center transition-colors">
                  <RefreshCw size={28} />
                </div>
                <div>
                  <h2 className="font-fraunces text-2xl font-medium text-[#1B2740] group-hover:text-[#C4432E] transition-colors mb-2">
                    Convert PDF
                  </h2>
                  <p className="text-xs sm:text-sm text-[#6B7280] leading-relaxed">
                    Convert between PDF, Word, JPG, and more
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t border-[#E8E8E6] flex items-center justify-between text-xs font-semibold text-[#1B2740] group-hover:text-[#C4432E] font-ibm-mono transition-colors">
                <span>Convert Format</span>
                <ArrowRight size={16} className="transform group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Hidden File Input for PDF Upload */}
      <input
        type="file"
        ref={fileInputRef}
        accept=".pdf"
        className="hidden"
        onChange={(e) => {
          if (e.target.files && e.target.files[0]) {
            onUploadPdfFile(e.target.files[0]);
          }
        }}
      />

      {/* ----------------- STEP 2: FLOW 1 - UPLOAD & EDIT ----------------- */}
      {selectedFlow === 'upload' && !hasFile && (
        <div className="flex-1 flex flex-col items-center justify-center p-6 sm:p-10 animate-fade-in-slide my-auto">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                onUploadPdfFile(e.dataTransfer.files[0]);
              }
            }}
            className={`w-full max-w-xl p-10 sm:p-14 rounded-2xl border-2 border-dashed transition-all text-center flex flex-col items-center justify-center soft-card-shadow my-auto ${
              dragOver
                ? 'border-[#C4432E] bg-[#C4432E]/5 scale-[1.01]'
                : 'border-[#1B2740]/25 hover:border-[#C4432E] bg-white'
            }`}
          >
            {isLoadingFile ? (
              <div className="flex flex-col items-center justify-center space-y-3 py-6">
                <Sparkles size={36} className="text-[#C4432E] animate-spin" />
                <p className="font-fraunces text-lg text-[#1B2740]">Loading & Parsing PDF Document...</p>
                <p className="text-xs text-[#6B7280]">Rendering high-resolution vector pages client-side...</p>
              </div>
            ) : (
              <>
                <div className="w-16 h-16 rounded-2xl bg-[#1B2740]/8 flex items-center justify-center mb-4 text-[#1B2740]">
                  <FileText size={32} className="text-[#1B2740]" />
                </div>
                <h3 className="font-fraunces text-2xl sm:text-3xl font-medium text-[#1B2740] mb-2">
                  Upload PDF
                </h3>
                <p className="text-xs sm:text-sm text-[#6B7280] mb-6 max-w-sm leading-relaxed font-ibm-sans">
                  Upload your PDF file to edit, annotate, sign, or organize your document.
                </p>

                {uploadError && (
                  <div className="mb-6 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 text-left w-full">
                    <p className="font-semibold mb-1">Error Loading Document:</p>
                    <p>{uploadError}</p>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row items-center gap-3">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-[#C4432E] hover:bg-[#a83623] text-white text-sm font-medium px-8 py-3.5 rounded-xl red-glow transition-all transform hover:-translate-y-0.5 cursor-pointer shadow-md"
                  >
                    <Upload size={18} />
                    <span>Upload PDF</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => onSelectFlow(null as any)}
                    className="w-full sm:w-auto text-xs text-[#6B7280] hover:text-[#1B2740] px-4 py-2.5 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
                  >
                    Change Workflow
                  </button>
                </div>

                <div className="mt-8 flex items-center space-x-4 text-xs text-[#6B7280]">
                  <span>Supported Format: Standard PDF</span>
                  <span>•</span>
                  <span>100% Client-Side Private</span>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Loaded PDF Document View - Real PDF.js Canvas Preview */}
      {selectedFlow === 'upload' && hasFile && (
        <div className="flex-1 flex w-full h-full relative overflow-hidden animate-fade-in-slide">
          {/* Left Thumbnails Strip */}
          <div className="w-40 sm:w-48 bg-white border-r border-[#E8E8E6] p-3 overflow-y-auto space-y-3 shrink-0 soft-card-shadow hidden sm:block">
            <div className="text-[11px] font-semibold uppercase text-[#6B7280] tracking-wider font-ibm-mono px-1 flex justify-between items-center">
              <span>Pages ({pageCount})</span>
              <span className="text-[9px] text-[#C4432E] font-bold">PDF.js</span>
            </div>

            {thumbnails.length > 0 ? (
              thumbnails.map((thumb, idx) => {
                const pageNum = idx + 1;
                return (
                  <button
                    key={pageNum}
                    onClick={() => setActivePage(pageNum)}
                    className={`w-full text-left p-2 rounded-lg border transition-all cursor-pointer group ${
                      activePage === pageNum
                        ? 'border-[#C4432E] bg-[#C4432E]/5 shadow-xs'
                        : 'border-[#E8E8E6] hover:border-[#1B2740] bg-white'
                    }`}
                  >
                    <div className="aspect-3/4 bg-[#F6F6F4] border border-[#E8E8E6] rounded p-1 flex items-center justify-center overflow-hidden relative group-hover:shadow-2xs">
                      <img
                        src={thumb}
                        alt={`Page ${pageNum}`}
                        className="max-h-full max-w-full object-contain rounded-xs shadow-xs"
                      />
                    </div>
                    <div className="mt-1.5 flex items-center justify-between text-[11px] font-ibm-mono text-[#6B7280]">
                      <span>PAGE {String(pageNum).padStart(2, '0')}</span>
                      {activePage === pageNum && <span className="text-[#C4432E] font-bold">• Active</span>}
                    </div>
                  </button>
                );
              })
            ) : (
              Array.from({ length: pageCount }, (_, i) => i + 1).map((pageNum) => (
                <button
                  key={pageNum}
                  onClick={() => setActivePage(pageNum)}
                  className={`w-full text-left p-2 rounded-lg border transition-all cursor-pointer ${
                    activePage === pageNum
                      ? 'border-[#C4432E] bg-[#C4432E]/5'
                      : 'border-[#E8E8E6] hover:border-[#1B2740] bg-white'
                  }`}
                >
                  <div className="aspect-3/4 bg-[#F6F6F4] border border-[#E8E8E6] rounded flex items-center justify-center text-xs font-ibm-mono text-[#6B7280]">
                    Page {pageNum}
                  </div>
                </button>
              ))
            )}
          </div>

          {/* Main Document Canvas View */}
          <div className="flex-1 flex flex-col items-center justify-start p-3 sm:p-6 pb-44 relative overflow-y-auto w-full">
            <div
              style={{
                transform: `rotate(${rotation}deg)`,
                transition: 'transform 0.2s ease',
              }}
              className={`relative flex flex-col items-center justify-center transition-all mb-8 ${
                showGrid ? 'bg-[radial-gradient(#1B2740_1px,transparent_1px)] [background-size:16px_16px] p-4 rounded-xl' : ''
              }`}
            >
              {/* REAL PDF CANVAS ELEMENT */}
              <div className="relative inline-block max-w-full">
                <canvas
                  ref={pdfCanvasRef}
                  className="rounded-xl shadow-2xl border border-[#E8E8E6] max-w-full bg-white transition-all block"
                />
                {watermarkDraft && setWatermarkDraft && onBakeWatermark && (
                  <WatermarkOverlay
                    watermark={watermarkDraft}
                    onUpdateWatermark={(updated) => setWatermarkDraft(updated)}
                    onBake={() => onBakeWatermark(watermarkDraft)}
                    onCancel={() => setWatermarkDraft(null)}
                    canvasRef={pdfCanvasRef}
                    pageCount={pageCount}
                    activePage={activePage}
                    zoomLevel={zoomLevel}
                  />
                )}
                {signatureDraft && setSignatureDraft && onBakeSignature && signatureDraft.pageNumber === activePage && (
                  <SignatureOverlay
                    signature={signatureDraft}
                    onUpdateSignature={(updated) => setSignatureDraft(updated)}
                    onBake={() => onBakeSignature(signatureDraft)}
                    onCancel={() => setSignatureDraft(null)}
                    canvasRef={pdfCanvasRef}
                    zoomLevel={zoomLevel}
                  />
                )}
                {imageDraft && setImageDraft && onBakeImage && imageDraft.pageNumber === activePage && (
                  <ImageOverlay
                    imageDraft={imageDraft}
                    onUpdateImageDraft={(updated) => setImageDraft(updated)}
                    onBake={() => onBakeImage(imageDraft)}
                    onCancel={() => setImageDraft(null)}
                    canvasRef={pdfCanvasRef}
                    zoomLevel={zoomLevel}
                    activePage={activePage}
                    pageCount={pageCount}
                  />
                )}
                {isEditTextActive && pdfBuffer && onUpdatePdfBuffer && (
                  <EditTextOverlay
                    pdfBuffer={pdfBuffer}
                    pageNumber={activePage}
                    pageCount={pageCount}
                    canvasRef={pdfCanvasRef}
                    zoomLevel={zoomLevel}
                    rotation={rotation}
                    onApplyEdit={(newBuffer, msg) => onUpdatePdfBuffer(newBuffer, msg)}
                    isActive={isEditTextActive}
                    onClose={() => setIsEditTextActive && setIsEditTextActive(false)}
                  />
                )}
                {isFindReplaceActive && pdfBuffer && (
                  <FindReplaceHighlightOverlay
                    pdfBuffer={pdfBuffer}
                    pageNumber={activePage}
                    zoomLevel={zoomLevel}
                    rotation={rotation}
                    pageMatches={findReplaceMatchesByPage?.[activePage] || []}
                    focusedMatchId={focusedMatchId || null}
                    onSelectMatch={onSelectMatch || (() => {})}
                    isActive={isFindReplaceActive}
                  />
                )}
              </div>
            </div>

            {/* SINGLE COMBINED FLOATING CONTROL BAR AT BOTTOM CENTER */}
            <div className="fixed bottom-36 left-1/2 -translate-x-1/2 z-20 flex items-center justify-center max-w-[calc(100vw-2rem)] pointer-events-auto">
              <div className="bg-white/95 backdrop-blur-md border border-[#E8E8E6] rounded-full px-3.5 py-2 shadow-xl flex items-center gap-2.5 sm:gap-3 text-xs sm:text-sm text-[#1B2740] overflow-x-auto no-scrollbar">
                {/* 1. Page Navigation */}
                <div className="flex items-center space-x-1 shrink-0">
                  <button
                    onClick={() => setActivePage(Math.max(1, activePage - 1))}
                    disabled={activePage <= 1}
                    className="p-1 rounded-full text-[#1B2740] hover:bg-[#F6F6F4] disabled:opacity-25 disabled:hover:bg-transparent cursor-pointer transition-colors"
                    title="Previous Page"
                  >
                    <ChevronLeft size={16} />
                  </button>

                  <span className="font-ibm-mono text-xs sm:text-sm font-semibold text-[#1B2740] px-1.5 select-none whitespace-nowrap">
                    Page {activePage} of {pageCount}
                  </span>

                  <button
                    onClick={() => setActivePage(Math.min(pageCount, activePage + 1))}
                    disabled={activePage >= pageCount}
                    className="p-1 rounded-full text-[#1B2740] hover:bg-[#F6F6F4] disabled:opacity-25 disabled:hover:bg-transparent cursor-pointer transition-colors"
                    title="Next Page"
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>

                {/* Thin Divider */}
                <div className="h-4 w-px bg-[#E8E8E6] shrink-0" />

                {/* 2. Zoom Controls */}
                <div className="flex items-center space-x-1 shrink-0">
                  <button
                    onClick={() => handleZoom(-10)}
                    className="p-1 text-[#1B2740] hover:bg-[#F6F6F4] rounded-md transition-colors cursor-pointer"
                    title="Zoom Out"
                  >
                    <ZoomOut size={15} />
                  </button>

                  <span className="font-ibm-mono font-medium text-[#1B2740] w-10 text-center text-[11px] sm:text-xs select-none">
                    {zoomLevel}%
                  </span>

                  <button
                    onClick={() => handleZoom(10)}
                    className="p-1 text-[#1B2740] hover:bg-[#F6F6F4] rounded-md transition-colors cursor-pointer"
                    title="Zoom In"
                  >
                    <ZoomIn size={15} />
                  </button>
                </div>

                {/* Thin Divider */}
                <div className="h-4 w-px bg-[#E8E8E6] shrink-0" />

                {/* 3. Refresh, Grid View, Delete */}
                <div className="flex items-center space-x-1.5 shrink-0">
                  <button
                    onClick={handleRotatePage}
                    className="p-1 text-[#1B2740] hover:bg-[#F6F6F4] rounded-md transition-colors cursor-pointer"
                    title="Rotate Page"
                  >
                    <RotateCw size={15} />
                  </button>

                  <button
                    onClick={() => setShowGrid(!showGrid)}
                    className={`p-1 rounded-md transition-colors cursor-pointer ${
                      showGrid ? 'bg-[#C4432E]/10 text-[#C4432E]' : 'text-[#1B2740] hover:bg-[#F6F6F4]'
                    }`}
                    title="Grid Overlay"
                  >
                    <Grid size={15} />
                  </button>

                  <button
                    onClick={onResetFile}
                    className="p-1 text-[#6B7280] hover:text-[#C4432E] hover:bg-[#F6F6F4] rounded-md transition-colors cursor-pointer"
                    title="Close PDF Document"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- STEP 2: FLOW 2 - MS WORD STYLE "CREATE PDF" ----------------- */}
      {selectedFlow === 'create' && (
        <div className="flex-1 flex flex-col w-full h-full relative overflow-hidden animate-fade-in-slide">
          {/* TOP MINIMAL FORMATTING TOOLBAR MATCHING REFERENCE DESIGN */}
          <div className="w-full bg-white border-b border-[#E8E8E6] px-4 py-2 z-20 shrink-0">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5 text-xs select-none">
              {/* Font Family Dropdown */}
              <div className="relative shrink-0">
                <select
                  value={activeBlock.fontFamily}
                  onChange={(e) => updateActiveBlock({ fontFamily: e.target.value as any })}
                  className="appearance-none bg-white border border-[#E8E8E6] rounded-md pl-3 pr-7 py-1.5 text-xs sm:text-sm text-[#1B2740] font-serif font-medium focus:outline-none focus:border-[#1B2740]/40 cursor-pointer shadow-2xs"
                  title="Font Family"
                >
                  <option value="font-serif">Georgia</option>
                  <option value="font-ibm-sans">IBM Plex Sans</option>
                  <option value="font-fraunces">Fraunces</option>
                  <option value="font-mono">Courier</option>
                </select>
                <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-[#1B2740] pointer-events-none" />
              </div>

              {/* Font Size Dropdown */}
              <div className="relative shrink-0">
                <select
                  value={activeBlock.fontSize}
                  onChange={(e) => updateActiveBlock({ fontSize: e.target.value })}
                  className="appearance-none bg-white border border-[#E8E8E6] rounded-md pl-3 pr-6 py-1.5 text-xs sm:text-sm text-[#1B2740] font-sans font-medium focus:outline-none focus:border-[#1B2740]/40 cursor-pointer shadow-2xs"
                  title="Font Size"
                >
                  <option value="10pt">10</option>
                  <option value="11pt">11</option>
                  <option value="12pt">12</option>
                  <option value="14pt">14</option>
                  <option value="16pt">16</option>
                  <option value="18pt">18</option>
                  <option value="24pt">24</option>
                  <option value="28pt">28</option>
                  <option value="32pt">32</option>
                </select>
                <ChevronDown size={12} className="absolute right-2 top-1/2 -translate-y-1/2 text-[#1B2740] pointer-events-none" />
              </div>

              {/* B, I, U Buttons */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => updateActiveBlock({ isBold: !activeBlock.isBold })}
                  className={`w-8 h-8 rounded-md border flex items-center justify-center font-bold text-xs sm:text-sm transition-colors cursor-pointer shadow-2xs ${
                    activeBlock.isBold
                      ? 'bg-[#1B2740]/10 border-[#1B2740]/40 text-[#1B2740]'
                      : 'bg-white border-[#E8E8E6] text-[#1B2740] hover:bg-[#F6F6F4]'
                  }`}
                  title="Bold (B)"
                >
                  B
                </button>

                <button
                  onClick={() => updateActiveBlock({ isItalic: !activeBlock.isItalic })}
                  className={`w-8 h-8 rounded-md border flex items-center justify-center italic font-serif text-xs sm:text-sm transition-colors cursor-pointer shadow-2xs ${
                    activeBlock.isItalic
                      ? 'bg-[#1B2740]/10 border-[#1B2740]/40 text-[#1B2740]'
                      : 'bg-white border-[#E8E8E6] text-[#1B2740] hover:bg-[#F6F6F4]'
                  }`}
                  title="Italic (I)"
                >
                  I
                </button>

                <button
                  onClick={() => updateActiveBlock({ isUnderline: !activeBlock.isUnderline })}
                  className={`w-8 h-8 rounded-md border flex items-center justify-center underline text-xs sm:text-sm transition-colors cursor-pointer shadow-2xs ${
                    activeBlock.isUnderline
                      ? 'bg-[#1B2740]/10 border-[#1B2740]/40 text-[#1B2740]'
                      : 'bg-white border-[#E8E8E6] text-[#1B2740] hover:bg-[#F6F6F4]'
                  }`}
                  title="Underline (U)"
                >
                  U
                </button>
              </div>

              {/* Text Color Dropdown Control */}
              <div className="relative shrink-0">
                <button
                  onClick={() => {
                    const colors = ['#1B2740', '#C4432E', '#059669', '#2563EB', '#374151'];
                    const nextIndex = (colors.indexOf(activeBlock.textColor) + 1) % colors.length;
                    updateActiveBlock({ textColor: colors[nextIndex] });
                  }}
                  className="bg-white border border-[#E8E8E6] px-2.5 py-1.5 rounded-md text-xs sm:text-sm font-bold text-[#1B2740] flex items-center gap-1 transition-colors cursor-pointer shadow-2xs hover:bg-[#F6F6F4]"
                  title="Text Color (A)"
                >
                  <span className="relative font-serif text-sm border-b-2 leading-none pb-0.5" style={{ borderColor: activeBlock.textColor }}>
                    A
                  </span>
                  <ChevronDown size={12} className="text-[#1B2740]" />
                </button>
              </div>
            </div>
          </div>

          {/* MAIN DOCUMENT CANVAS AREA */}
          <div className="flex-1 flex flex-col items-center justify-center p-3 sm:p-5 relative bg-[#F6F6F4] w-full pb-20 overflow-hidden">
            {/* CLEAN A4-PROPORTIONED WHITE DOCUMENT SHEET */}
            <div
              ref={paperRef}
              key={activeWordPage}
              onScroll={(e) => {
                e.currentTarget.scrollTop = 0;
              }}
              onClick={() => {
                handleAddParagraphBlock();
              }}
              style={{
                aspectRatio: '1 / 1.4142',
                height: 'calc(100vh - 210px)',
                maxHeight: '880px',
                minHeight: '480px',
              }}
              className="w-auto bg-white shadow-md border border-[#E8E8E6] rounded-sm p-8 sm:p-14 relative my-auto transition-none flex flex-col justify-start cursor-text shrink-0 overflow-hidden select-none animate-in fade-in duration-200"
            >
              {/* DOCUMENT CONTENT BLOCKS */}
              <div
                className="space-y-4 relative z-10 w-full h-full cursor-text overflow-hidden flex flex-col justify-start"
                onClick={() => {
                  handleAddParagraphBlock();
                }}
              >
                {blocks.map((block) => {
                  const inlineStyle = {
                    color: block.textColor,
                    backgroundColor: block.highlightColor !== 'transparent' ? block.highlightColor : undefined,
                  };

                  return (
                    <div
                      key={block.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveBlockId(block.id);
                      }}
                      className="relative p-0 transition-all border-none bg-transparent shadow-none outline-none"
                    >
                      {block.type === 'heading' && (
                        <textarea
                          id={`textarea-${block.id}`}
                          value={block.text}
                          onChange={(e) => handleBlockTextChange(block.id, e.target.value)}
                          onFocus={() => setActiveBlockId(block.id)}
                          onBlur={() => handleBlockBlur(block.id, block.text)}
                          onKeyDown={(e) => handleBlockKeyDown(e, block.id)}
                          onClick={(e) => e.stopPropagation()}
                          rows={getTextAreaRows(block.text, 28)}
                          className="w-full bg-transparent border-none focus:outline-none focus:ring-0 shadow-none font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#1B2740] leading-tight resize-none p-0 my-0"
                          style={inlineStyle}
                          placeholder=""
                        />
                      )}

                      {block.type === 'subtitle' && (
                        <textarea
                          id={`textarea-${block.id}`}
                          value={block.text}
                          onChange={(e) => handleBlockTextChange(block.id, e.target.value)}
                          onFocus={() => setActiveBlockId(block.id)}
                          onBlur={() => handleBlockBlur(block.id, block.text)}
                          onKeyDown={(e) => handleBlockKeyDown(e, block.id)}
                          onClick={(e) => e.stopPropagation()}
                          rows={getTextAreaRows(block.text, 42)}
                          className="w-full bg-transparent border-none focus:outline-none focus:ring-0 shadow-none font-serif text-lg sm:text-xl lg:text-2xl text-[#1B2740] leading-normal resize-none p-0 my-0"
                          style={inlineStyle}
                          placeholder=""
                        />
                      )}

                      {block.type === 'paragraph' && (
                        <textarea
                          id={`textarea-${block.id}`}
                          value={block.text}
                          onChange={(e) => handleBlockTextChange(block.id, e.target.value)}
                          onFocus={() => setActiveBlockId(block.id)}
                          onBlur={() => handleBlockBlur(block.id, block.text)}
                          onKeyDown={(e) => handleBlockKeyDown(e, block.id)}
                          onClick={(e) => e.stopPropagation()}
                          rows={getTextAreaRows(block.text, 65)}
                          className="w-full bg-transparent border-none focus:outline-none focus:ring-0 shadow-none font-serif text-sm sm:text-base lg:text-lg text-[#1B2740] leading-relaxed resize-none p-0 my-0"
                          style={inlineStyle}
                          placeholder=""
                        />
                      )}

                      {block.type === 'bullet' && (
                        <div className="flex items-start gap-2">
                          <span className="font-bold text-[#1B2740] text-base mt-0.5">•</span>
                          <textarea
                            id={`textarea-${block.id}`}
                            value={block.text}
                            onChange={(e) => handleBlockTextChange(block.id, e.target.value)}
                            onFocus={() => setActiveBlockId(block.id)}
                            onBlur={() => handleBlockBlur(block.id, block.text)}
                            onKeyDown={(e) => handleBlockKeyDown(e, block.id)}
                            onClick={(e) => e.stopPropagation()}
                            rows={getTextAreaRows(block.text, 60)}
                            className="w-full bg-transparent border-none focus:outline-none focus:ring-0 shadow-none font-serif text-sm sm:text-base text-[#1B2740] leading-relaxed resize-none p-0 my-0"
                            style={inlineStyle}
                            placeholder=""
                          />
                        </div>
                      )}

                      {block.type === 'number' && (
                        <div className="flex items-start gap-2">
                          <span className="font-bold text-[#1B2740] text-sm mt-0.5">1.</span>
                          <textarea
                            id={`textarea-${block.id}`}
                            value={block.text}
                            onChange={(e) => handleBlockTextChange(block.id, e.target.value)}
                            onFocus={() => setActiveBlockId(block.id)}
                            onBlur={() => handleBlockBlur(block.id, block.text)}
                            onKeyDown={(e) => handleBlockKeyDown(e, block.id)}
                            onClick={(e) => e.stopPropagation()}
                            rows={getTextAreaRows(block.text, 60)}
                            className="w-full bg-transparent border-none focus:outline-none focus:ring-0 shadow-none font-serif text-sm sm:text-base text-[#1B2740] leading-relaxed resize-none p-0 my-0"
                            style={inlineStyle}
                            placeholder=""
                          />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* SINGLE SLIM FLOATING PILL TOOLBAR AT BOTTOM */}
            <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-30 flex items-center justify-center pointer-events-auto">
              <div className="bg-white/95 backdrop-blur-md border border-[#E8E8E6] rounded-full px-4 py-2 shadow-lg flex items-center gap-3 text-xs sm:text-sm text-[#1B2740]">
                {/* Previous Page Chevron */}
                <button
                  onClick={() => handleGoToPage(activeWordPage - 1)}
                  disabled={activeWordPage <= 1}
                  className="p-1 rounded-full text-[#1B2740] hover:bg-[#F6F6F4] disabled:opacity-30 disabled:hover:bg-transparent cursor-pointer transition-colors"
                  title="Previous Page"
                >
                  <ChevronLeft size={16} />
                </button>

                {/* Page Text */}
                <span className="font-sans font-medium text-xs sm:text-sm text-[#1B2740] px-1 select-none">
                  Page {activeWordPage} of {wordPageCount}
                </span>

                {/* Next Page Chevron */}
                <button
                  onClick={() => handleGoToPage(activeWordPage + 1)}
                  disabled={activeWordPage >= wordPageCount}
                  className="p-1 rounded-full text-[#1B2740] hover:bg-[#F6F6F4] disabled:opacity-30 disabled:hover:bg-transparent cursor-pointer transition-colors"
                  title="Next Page"
                >
                  <ChevronRight size={16} />
                </button>

                {/* Thin Vertical Divider */}
                <div className="h-4 w-px bg-[#E8E8E6] mx-1" />

                {/* Red Add Page Button */}
                <button
                  onClick={handleAddPage}
                  className="inline-flex items-center gap-1 bg-[#C4432E] hover:bg-[#a83623] text-white font-medium text-xs sm:text-sm px-4 py-1.5 rounded-full red-glow shadow-xs transition-all cursor-pointer"
                  title="Add new page"
                >
                  <Plus size={14} />
                  <span>Add Page</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- STEP 2: FLOW 3 - CONVERT MODE VIEW ----------------- */}
      {selectedFlow === 'convert' && (
        <div className="flex-1 flex flex-col items-center justify-start p-6 sm:p-10 w-full overflow-y-auto my-auto">
          <div className="w-full max-w-3xl space-y-6 animate-fade-in-slide my-auto">
            {/* Header Banner */}
            <div className="text-center space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#C4432E]/10 text-[#C4432E] rounded-full text-xs font-bold font-ibm-mono">
                <ImageIcon size={14} />
                <span>Real-Time Document Conversion Engine</span>
              </div>
              <h2 className="font-fraunces text-2xl sm:text-3xl font-medium text-[#1B2740]">
                Convert Files to PDF
              </h2>
              <p className="text-xs sm:text-sm text-[#6B7280] max-w-lg mx-auto">
                Select your preferred conversion tool to convert files into clean, professional PDF documents.
              </p>

              {/* Conversion Type Selectors */}
              <div className="flex flex-wrap justify-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setActiveConvertMode('image-to-pdf');
                    setConversionResult(null);
                  }}
                  className={`px-4 py-2 rounded-full text-xs font-bold font-ibm-mono border transition-all cursor-pointer flex items-center gap-1.5 ${
                    activeConvertMode === 'image-to-pdf'
                      ? 'bg-[#C4432E] text-white border-[#C4432E] shadow-sm'
                      : 'bg-white text-[#1B2740] border-[#E8E8E6] hover:bg-[#F6F6F4]'
                  }`}
                >
                  <ImageIcon size={14} />
                  <span>Image to PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveConvertMode('pdf-to-image')}
                  className={`px-4 py-2 rounded-full text-xs font-medium font-ibm-mono border transition-all cursor-pointer ${
                    activeConvertMode === 'pdf-to-image'
                      ? 'bg-[#1B2740] text-white border-[#1B2740]'
                      : 'bg-white text-[#6B7280] border-[#E8E8E6] hover:bg-[#F6F6F4]'
                  }`}
                >
                  <span>PDF to Image</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveConvertMode('ppt-to-pdf')}
                  className={`px-4 py-2 rounded-full text-xs font-medium font-ibm-mono border transition-all cursor-pointer ${
                    activeConvertMode === 'ppt-to-pdf'
                      ? 'bg-[#1B2740] text-white border-[#1B2740]'
                      : 'bg-white text-[#6B7280] border-[#E8E8E6] hover:bg-[#F6F6F4]'
                  }`}
                >
                  <span>PPT to PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveConvertMode('excel-to-pdf')}
                  className={`px-4 py-2 rounded-full text-xs font-medium font-ibm-mono border transition-all cursor-pointer ${
                    activeConvertMode === 'excel-to-pdf'
                      ? 'bg-[#1B2740] text-white border-[#1B2740]'
                      : 'bg-white text-[#6B7280] border-[#E8E8E6] hover:bg-[#F6F6F4]'
                  }`}
                >
                  <span>Excel to PDF</span>
                </button>
              </div>
            </div>

            {/* Error Message */}
            {convertError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl text-center">
                {convertError}
              </div>
            )}

            {/* IF CONVERSION RESULT IS READY: SHOW OUTPUT CARD ON THIS PAGE */}
            {conversionResult ? (
              <div className="bg-white p-8 rounded-2xl border border-[#E8E8E6] shadow-xl space-y-6 text-center animate-fade-in">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                  <CheckCircle2 size={36} />
                </div>

                <div className="space-y-1">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-full font-ibm-mono uppercase">
                    <Sparkles size={12} />
                    <span>Conversion Successful</span>
                  </div>
                  <h3 className="font-fraunces text-2xl font-semibold text-[#1B2740]">
                    Images Converted to PDF!
                  </h3>
                  <p className="text-xs text-[#6B7280]">
                    Your PDF has been generated without loss of resolution. Download it directly or open it in the PDF Editor.
                  </p>
                </div>

                {/* File Details summary */}
                <div className="p-4 bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl flex items-center justify-between text-left">
                  <div className="flex items-center gap-3 overflow-hidden">
                    <div className="w-10 h-10 rounded-xl bg-[#C4432E]/10 text-[#C4432E] flex items-center justify-center shrink-0">
                      <FileText size={20} />
                    </div>
                    <div className="truncate">
                      <span className="font-bold text-sm text-[#1B2740] block truncate">
                        {conversionResult.fileName}
                      </span>
                      <span className="text-xs text-[#6B7280] font-ibm-mono">
                        {conversionResult.pageCount} {conversionResult.pageCount === 1 ? 'Page' : 'Pages'} • {conversionResult.sizeStr}
                      </span>
                    </div>
                  </div>
                  <span className="px-2.5 py-1 bg-emerald-100 text-emerald-700 font-bold text-[10px] rounded-md font-ibm-mono uppercase shrink-0">
                    Ready
                  </span>
                </div>

                {/* Two Action Options */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleDownloadConverted}
                    className="py-3.5 px-5 bg-[#C4432E] hover:bg-[#a83623] text-white font-semibold text-sm rounded-xl red-glow flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md hover:-translate-y-0.5"
                  >
                    <Download size={18} />
                    <span>Download Output PDF</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleOpenConvertedInEditor}
                    className="py-3.5 px-5 bg-[#1B2740] hover:bg-[#2C3E60] text-white font-semibold text-sm rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md hover:-translate-y-0.5"
                  >
                    <FileEdit size={18} />
                    <span>Open in PDF Editor Mode</span>
                  </button>
                </div>

                <div className="border-t border-[#E8E8E6] pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setConversionResult(null);
                      setConvertImages([]);
                    }}
                    className="text-xs font-semibold text-[#6B7280] hover:text-[#C4432E] inline-flex items-center gap-1.5 cursor-pointer font-ibm-mono"
                  >
                    <RefreshCw size={14} />
                    <span>Convert More Images</span>
                  </button>
                </div>
              </div>
            ) : activeConvertMode === 'image-to-pdf' ? (
              /* IMAGE TO PDF CONVERSION INPUT UI */
              <>
                {/* Center Drag and Drop Zone */}
                <label
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragOver(true);
                  }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setDragOver(false);
                    if (e.dataTransfer.files) {
                      handleAddImagesToConvert(e.dataTransfer.files);
                    }
                  }}
                  className={`w-full p-8 sm:p-10 rounded-2xl border-2 border-dashed transition-all text-center flex flex-col items-center justify-center cursor-pointer soft-card-shadow ${
                    dragOver
                      ? 'border-[#C4432E] bg-[#C4432E]/5 scale-[1.01]'
                      : 'border-[#1B2740]/30 hover:border-[#C4432E] bg-white'
                  }`}
                >
                  <input
                    type="file"
                    accept="image/*,.jpg,.jpeg,.png,.webp,.gif,.bmp"
                    multiple
                    className="hidden"
                    onChange={(e) => {
                      if (e.target.files) {
                        handleAddImagesToConvert(e.target.files);
                      }
                    }}
                  />
                  <div className="w-14 h-14 rounded-2xl bg-[#1B2740]/8 flex items-center justify-center mb-3 text-[#1B2740]">
                    <Upload size={28} className="text-[#C4432E]" />
                  </div>
                  <p className="text-base font-semibold text-[#1B2740] mb-1">
                    Drag & drop image files here, or <span className="text-[#C4432E] underline">Browse</span>
                  </p>
                  <p className="text-xs text-[#6B7280]">
                    Supports JPG, PNG, WebP, GIF, BMP • Multiple files allowed
                  </p>
                </label>

                {/* Uploaded Images Gallery List */}
                {convertImages.length > 0 && (
                  <div className="bg-white p-5 rounded-2xl border border-[#E8E8E6] shadow-sm space-y-4">
                    <div className="flex justify-between items-center text-xs font-bold text-[#1B2740] font-ibm-mono uppercase">
                      <span>Uploaded Images ({convertImages.length})</span>
                      <button
                        type="button"
                        onClick={() => setConvertImages([])}
                        className="text-[#C4432E] hover:underline normal-case cursor-pointer text-xs font-normal"
                      >
                        Remove all
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-60 overflow-y-auto p-1">
                      {convertImages.map((img, idx) => (
                        <div
                          key={img.id}
                          className="p-3 bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl flex items-center justify-between gap-3 text-xs"
                        >
                          <div className="flex items-center gap-3 overflow-hidden">
                            <span className="w-5 h-5 rounded-full bg-[#1B2740] text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                              {idx + 1}
                            </span>
                            <img
                              src={img.dataUrl}
                              alt={img.name}
                              className="w-10 h-10 object-cover rounded-lg border border-[#E8E8E6] bg-white shrink-0"
                            />
                            <div className="truncate">
                              <span className="font-semibold text-[#1B2740] truncate block">{img.name}</span>
                              <span className="text-[10px] text-[#6B7280] font-ibm-mono">{img.sizeStr}</span>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              disabled={idx === 0}
                              onClick={() => {
                                const copy = [...convertImages];
                                const temp = copy[idx];
                                copy[idx] = copy[idx - 1];
                                copy[idx - 1] = temp;
                                setConvertImages(copy);
                              }}
                              className="p-1 text-[#1B2740] hover:bg-white rounded cursor-pointer disabled:opacity-20"
                              title="Move Up"
                            >
                              <ArrowUp size={14} />
                            </button>
                            <button
                              type="button"
                              disabled={idx === convertImages.length - 1}
                              onClick={() => {
                                const copy = [...convertImages];
                                const temp = copy[idx];
                                copy[idx] = copy[idx + 1];
                                copy[idx + 1] = temp;
                                setConvertImages(copy);
                              }}
                              className="p-1 text-[#1B2740] hover:bg-white rounded cursor-pointer disabled:opacity-20"
                              title="Move Down"
                            >
                              <ArrowDown size={14} />
                            </button>
                            <button
                              type="button"
                              onClick={() => setConvertImages((prev) => prev.filter((i) => i.id !== img.id))}
                              className="p-1 text-[#6B7280] hover:text-[#C4432E] hover:bg-white rounded cursor-pointer"
                              title="Remove"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Layout Customization Toolbar */}
                <div className="bg-white p-5 rounded-2xl border border-[#E8E8E6] shadow-sm space-y-3">
                  <span className="text-xs font-bold text-[#1B2740] uppercase font-ibm-mono block">
                    Page Layout Settings
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {/* Page Size */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-[#6B7280] uppercase block">
                        Page Format
                      </label>
                      <select
                        value={convertPageSize}
                        onChange={(e) => setConvertPageSize(e.target.value as any)}
                        className="w-full bg-[#F6F6F4] border border-[#E8E8E6] text-xs text-[#1B2740] font-medium rounded-xl p-2.5 focus:outline-none focus:border-[#C4432E]"
                      >
                        <option value="fit">Fit to Image Size (Exact Ratio)</option>
                        <option value="a4">A4 Standard (595 x 842 pt)</option>
                        <option value="letter">US Letter (612 x 792 pt)</option>
                      </select>
                    </div>

                    {/* Orientation */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-[#6B7280] uppercase block">
                        Orientation
                      </label>
                      <select
                        value={convertOrientation}
                        onChange={(e) => setConvertOrientation(e.target.value as any)}
                        className="w-full bg-[#F6F6F4] border border-[#E8E8E6] text-xs text-[#1B2740] font-medium rounded-xl p-2.5 focus:outline-none focus:border-[#C4432E]"
                      >
                        <option value="auto">Auto Detect Orientation</option>
                        <option value="portrait">Portrait Mode</option>
                        <option value="landscape">Landscape Mode</option>
                      </select>
                    </div>

                    {/* Margin */}
                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-[#6B7280] uppercase block">
                        Margin Padding
                      </label>
                      <select
                        value={convertMargin}
                        onChange={(e) => setConvertMargin(e.target.value as any)}
                        className="w-full bg-[#F6F6F4] border border-[#E8E8E6] text-xs text-[#1B2740] font-medium rounded-xl p-2.5 focus:outline-none focus:border-[#C4432E]"
                      >
                        <option value="none">No Margin (0px)</option>
                        <option value="small">Small Margin (0.25")</option>
                        <option value="medium">Medium Margin (0.5")</option>
                        <option value="large">Large Margin (0.75")</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Main Action Convert CTA Button */}
                <div className="pt-2 text-center">
                  <button
                    type="button"
                    onClick={handleRunImageToPdfConversion}
                    disabled={convertImages.length === 0 || isConvertingImages}
                    className={`w-full max-w-md py-4 rounded-xl font-semibold text-sm transition-all cursor-pointer inline-flex items-center justify-center gap-2 ${
                      convertImages.length > 0 && !isConvertingImages
                        ? 'bg-[#C4432E] hover:bg-[#a83623] text-white red-glow transform hover:-translate-y-0.5 shadow-lg'
                        : 'bg-gray-200 text-gray-400 cursor-not-allowed border-none shadow-none opacity-60'
                    }`}
                  >
                    {isConvertingImages ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Converting Images to PDF...</span>
                      </>
                    ) : (
                      <>
                        <RefreshCw size={18} />
                        <span>Convert Images to PDF Now</span>
                      </>
                    )}
                  </button>
                  {convertImages.length === 0 && (
                    <p className="text-[11px] text-[#6B7280] mt-2 font-ibm-mono">
                      Please add at least one image file to enable conversion.
                    </p>
                  )}
                </div>
              </>
            ) : activeConvertMode === 'pdf-to-image' ? (
              /* PDF TO IMAGE CONVERSION UI */
              pdfToImgResults ? (
                /* CONVERTED PDF TO IMAGES RESULT VIEW */
                <div className="bg-white p-6 sm:p-8 rounded-2xl border border-[#E8E8E6] shadow-xl space-y-6 animate-fade-in">
                  <div className="text-center space-y-2">
                    <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-sm">
                      <CheckCircle2 size={32} />
                    </div>
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-full font-ibm-mono uppercase">
                      <Sparkles size={12} />
                      <span>Conversion Completed</span>
                    </div>
                    <h3 className="font-fraunces text-2xl font-semibold text-[#1B2740]">
                      PDF Converted to {pdfToImgResults.length} Image{pdfToImgResults.length > 1 ? 's' : ''}!
                    </h3>
                    <p className="text-xs text-[#6B7280] max-w-md mx-auto">
                      All pages have been extracted as high-resolution {pdfToImgFormat.toUpperCase()} images. Download individual images or get them all in a ZIP file.
                    </p>
                  </div>

                  {/* Main Download All CTA Button */}
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={handleDownloadAllImagesZip}
                      className="w-full sm:w-auto py-3.5 px-6 bg-[#C4432E] hover:bg-[#a83623] text-white font-semibold text-sm rounded-xl red-glow flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md hover:-translate-y-0.5"
                    >
                      <Archive size={18} />
                      <span>Download All Pages as ZIP</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPdfToImgResults(null);
                        setPdfToImgFile(null);
                      }}
                      className="w-full sm:w-auto py-3.5 px-5 bg-[#F6F6F4] hover:bg-[#E8E8E6] text-[#1B2740] font-semibold text-xs rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      <RefreshCw size={14} />
                      <span>Convert Another PDF</span>
                    </button>
                  </div>

                  {/* Grid of Converted Page Images */}
                  <div className="space-y-3 border-t border-[#E8E8E6] pt-5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-[#1B2740] font-ibm-mono uppercase">
                        Page Image Previews ({pdfToImgResults.length})
                      </span>
                      <span className="text-[11px] text-[#6B7280] font-ibm-mono">
                        Format: {pdfToImgFormat.toUpperCase()}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[500px] overflow-y-auto p-1">
                      {pdfToImgResults.map((item) => (
                        <div
                          key={item.pageNumber}
                          className="p-3 bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl space-y-2 flex flex-col justify-between"
                        >
                          <div className="flex justify-between items-center text-xs font-semibold text-[#1B2740]">
                            <span className="bg-[#1B2740] text-white text-[11px] font-bold px-2 py-0.5 rounded-md font-ibm-mono">
                              Page {item.pageNumber}
                            </span>
                            <span className="text-[10px] text-[#6B7280] font-ibm-mono">
                              {item.width} × {item.height} px
                            </span>
                          </div>

                          <div className="bg-white rounded-lg border border-[#E8E8E6] p-1 flex items-center justify-center max-h-48 overflow-hidden">
                            <img
                              src={item.dataUrl}
                              alt={`Page ${item.pageNumber}`}
                              className="max-h-44 object-contain rounded"
                            />
                          </div>

                          <button
                            type="button"
                            onClick={() => downloadSingleImage(item.dataUrl, item.filename)}
                            className="w-full py-2 bg-white hover:bg-[#C4432E] hover:text-white border border-[#E8E8E6] text-[#1B2740] font-medium text-xs rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-2xs"
                          >
                            <Download size={14} />
                            <span>Download Page {item.pageNumber}</span>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                /* PDF TO IMAGE INPUT / UPLOAD FORM */
                <>
                  {/* File Selection Box */}
                  {pdfToImgFile ? (
                    <div className="bg-white p-5 rounded-2xl border border-[#E8E8E6] shadow-sm flex items-center justify-between gap-4">
                      <div className="flex items-center gap-3 overflow-hidden">
                        <div className="w-12 h-12 rounded-xl bg-[#C4432E]/10 text-[#C4432E] flex items-center justify-center shrink-0">
                          <FileText size={24} />
                        </div>
                        <div className="truncate">
                          <span className="font-bold text-sm text-[#1B2740] block truncate">
                            {pdfToImgFile.name}
                          </span>
                          <span className="text-xs text-[#6B7280] font-ibm-mono">
                            {pdfToImgFile.size >= 1024 * 1024
                              ? `${(pdfToImgFile.size / (1024 * 1024)).toFixed(2)} MB`
                              : `${Math.round(pdfToImgFile.size / 1024)} KB`}
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setPdfToImgFile(null)}
                        className="p-2 text-[#6B7280] hover:text-[#C4432E] hover:bg-[#F6F6F4] rounded-xl cursor-pointer"
                        title="Remove File"
                      >
                        <X size={18} />
                      </button>
                    </div>
                  ) : pdfBuffer ? (
                    <div className="bg-white p-5 rounded-2xl border border-[#E8E8E6] shadow-sm space-y-3">
                      <div className="flex items-center justify-between text-xs font-bold text-[#1B2740] font-ibm-mono uppercase">
                        <span>Selected Document Source</span>
                        <span className="text-emerald-600 font-semibold text-[11px] normal-case flex items-center gap-1">
                          <CheckCircle2 size={12} /> Loaded in Memory
                        </span>
                      </div>
                      <div className="p-3 bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl flex items-center justify-between">
                        <div className="flex items-center gap-3 overflow-hidden">
                          <div className="w-10 h-10 rounded-xl bg-[#1B2740]/10 text-[#1B2740] flex items-center justify-center shrink-0">
                            <FileText size={20} />
                          </div>
                          <div className="truncate">
                            <span className="font-semibold text-xs text-[#1B2740] block truncate">
                              {pdfFileName || 'Current PDF Document'}
                            </span>
                            <span className="text-[10px] text-[#6B7280] font-ibm-mono">
                              {pageCount} {pageCount === 1 ? 'Page' : 'Pages'}
                            </span>
                          </div>
                        </div>
                      </div>
                      <p className="text-[11px] text-[#6B7280]">
                        Or drop a new PDF file below to convert a different document:
                      </p>
                      <label
                        onDragOver={(e) => {
                          e.preventDefault();
                          setDragOver(true);
                        }}
                        onDragLeave={() => setDragOver(false)}
                        onDrop={(e) => {
                          e.preventDefault();
                          setDragOver(false);
                          if (e.dataTransfer.files) {
                            handleAddPdfToConvert(e.dataTransfer.files);
                          }
                        }}
                        className="block p-4 rounded-xl border border-dashed border-[#1B2740]/20 hover:border-[#C4432E] bg-[#F6F6F4] text-center cursor-pointer transition-all"
                      >
                        <input
                          type="file"
                          accept="application/pdf,.pdf"
                          className="hidden"
                          onChange={(e) => {
                            if (e.target.files) handleAddPdfToConvert(e.target.files);
                          }}
                        />
                        <span className="text-xs font-semibold text-[#1B2740]">
                          Click or drag a new PDF here
                        </span>
                      </label>
                    </div>
                  ) : (
                    /* Drag & drop zone */
                    <label
                      onDragOver={(e) => {
                        e.preventDefault();
                        setDragOver(true);
                      }}
                      onDragLeave={() => setDragOver(false)}
                      onDrop={(e) => {
                        e.preventDefault();
                        setDragOver(false);
                        if (e.dataTransfer.files) {
                          handleAddPdfToConvert(e.dataTransfer.files);
                        }
                      }}
                      className={`w-full p-8 sm:p-10 rounded-2xl border-2 border-dashed transition-all text-center flex flex-col items-center justify-center cursor-pointer soft-card-shadow ${
                        dragOver
                          ? 'border-[#C4432E] bg-[#C4432E]/5 scale-[1.01]'
                          : 'border-[#1B2740]/30 hover:border-[#C4432E] bg-white'
                      }`}
                    >
                      <input
                        type="file"
                        accept="application/pdf,.pdf"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files) handleAddPdfToConvert(e.target.files);
                        }}
                      />
                      <div className="w-14 h-14 rounded-2xl bg-[#1B2740]/8 flex items-center justify-center mb-3 text-[#1B2740]">
                        <Upload size={28} className="text-[#C4432E]" />
                      </div>
                      <p className="text-base font-semibold text-[#1B2740] mb-1">
                        Drag & drop a PDF file here, or <span className="text-[#C4432E] underline">Browse</span>
                      </p>
                      <p className="text-xs text-[#6B7280]">
                        Supports single or multi-page PDF documents
                      </p>
                    </label>
                  )}

                  {/* Image Format and Resolution Settings */}
                  <div className="bg-white p-5 rounded-2xl border border-[#E8E8E6] shadow-sm space-y-3">
                    <span className="text-xs font-bold text-[#1B2740] uppercase font-ibm-mono block">
                      Output Image Settings
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {/* Format */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-[#6B7280] uppercase block">
                          Image Format
                        </label>
                        <select
                          value={pdfToImgFormat}
                          onChange={(e) => setPdfToImgFormat(e.target.value as any)}
                          className="w-full bg-[#F6F6F4] border border-[#E8E8E6] text-xs text-[#1B2740] font-medium rounded-xl p-2.5 focus:outline-none focus:border-[#C4432E]"
                        >
                          <option value="png">PNG (Lossless High Quality)</option>
                          <option value="jpeg">JPG / JPEG (Small File Size)</option>
                          <option value="webp">WebP (Modern Compact Format)</option>
                        </select>
                      </div>

                      {/* Quality Scale / DPI */}
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-[#6B7280] uppercase block">
                          Image Resolution (DPI)
                        </label>
                        <select
                          value={pdfToImgDpi}
                          onChange={(e) => setPdfToImgDpi(parseFloat(e.target.value))}
                          className="w-full bg-[#F6F6F4] border border-[#E8E8E6] text-xs text-[#1B2740] font-medium rounded-xl p-2.5 focus:outline-none focus:border-[#C4432E]"
                        >
                          <option value={1.5}>HD Standard (150 DPI)</option>
                          <option value={2.0}>Full HD Crisp (200 DPI - Recommended)</option>
                          <option value={3.0}>Ultra HD Print (300 DPI)</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Main Action CTA Button */}
                  <div className="pt-2 text-center">
                    <button
                      type="button"
                      onClick={handleRunPdfToImageConversion}
                      disabled={(!pdfToImgFile && !pdfBuffer) || isConvertingPdfToImg}
                      className={`w-full max-w-md py-4 rounded-xl font-semibold text-sm transition-all cursor-pointer inline-flex items-center justify-center gap-2 ${
                        (pdfToImgFile || pdfBuffer) && !isConvertingPdfToImg
                          ? 'bg-[#C4432E] hover:bg-[#a83623] text-white red-glow transform hover:-translate-y-0.5 shadow-lg'
                          : 'bg-gray-200 text-gray-400 cursor-not-allowed border-none shadow-none opacity-60'
                      }`}
                    >
                      {isConvertingPdfToImg ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          <span>Converting PDF Pages into Images...</span>
                        </>
                      ) : (
                        <>
                          <RefreshCw size={18} />
                          <span>Convert PDF to Images Now</span>
                        </>
                      )}
                    </button>
                    {!pdfToImgFile && !pdfBuffer && (
                      <p className="text-[11px] text-[#6B7280] mt-2 font-ibm-mono">
                        Please select or drag a PDF document to enable conversion.
                      </p>
                    )}
                  </div>
                </>
              )
            ) : (
              /* PLACEHOLDER CARD FOR OTHER CONVERSION MODES */
              <div className="bg-white p-8 rounded-2xl border border-[#E8E8E6] text-center space-y-4">
                <div className="w-12 h-12 bg-[#1B2740]/10 text-[#1B2740] rounded-2xl flex items-center justify-center mx-auto">
                  <RefreshCw size={24} />
                </div>
                <h3 className="font-fraunces text-xl font-medium text-[#1B2740]">
                  {activeConvertMode.toUpperCase().replace(/-/g, ' ')} Converter
                </h3>
                <p className="text-xs text-[#6B7280] max-w-sm mx-auto">
                  Please select Image to PDF or PDF to Image for instant conversion.
                </p>
                <div className="flex justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => setActiveConvertMode('image-to-pdf')}
                    className="px-4 py-2 bg-[#C4432E] text-white text-xs font-semibold rounded-xl red-glow cursor-pointer"
                  >
                    Image to PDF
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveConvertMode('pdf-to-image')}
                    className="px-4 py-2 bg-[#1B2740] text-white text-xs font-semibold rounded-xl cursor-pointer"
                  >
                    PDF to Image
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ----------------- CONVERT COMPLETE MODAL POPUP ----------------- */}
      {isConvertModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1B2740]/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-[#E8E8E6] w-full max-w-md p-6 text-center space-y-5 relative">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-xs">
              <Check size={26} strokeWidth={3} />
            </div>

            <div className="space-y-1">
              <h3 className="font-fraunces text-2xl font-medium text-[#1B2740]">
                Conversion complete
              </h3>
              <p className="text-xs text-[#6B7280]">
                Your file has been transformed with zero data loss.
              </p>
            </div>

            <div className="p-4 bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl flex items-center space-x-3 text-left">
              <div className="w-10 h-12 bg-white border border-[#1B2740]/20 rounded-md p-1 flex flex-col justify-between shrink-0 shadow-2xs">
                <div className="w-full h-1 bg-[#1B2740]/30 rounded-xs" />
                <span className="text-[8px] font-ibm-mono text-[#C4432E] font-bold text-center">
                  {convertedOutputName.split('.').pop()?.toUpperCase()}
                </span>
              </div>
              <div className="overflow-hidden">
                <div className="font-ibm-mono text-xs font-semibold text-[#1B2740] truncate">
                  {convertedOutputName}
                </div>
                <div className="text-[10px] text-[#6B7280] font-ibm-mono">
                  Size: 1.4 MB • Pressly Engine 2026
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => {
                  alert(`Downloading ${convertedOutputName}...`);
                  setIsConvertModalOpen(false);
                }}
                className="flex-1 py-3 px-4 rounded-xl border border-[#1B2740] text-[#1B2740] hover:bg-[#F6F6F4] text-xs sm:text-sm font-medium transition-colors cursor-pointer inline-flex items-center justify-center gap-1.5"
              >
                <Download size={16} />
                Download
              </button>

              <button
                onClick={handleOpenConvertedInEditor}
                className="flex-1 py-3 px-4 rounded-xl bg-[#C4432E] hover:bg-[#a83623] text-white text-xs sm:text-sm font-medium red-glow transition-all cursor-pointer inline-flex items-center justify-center gap-1.5"
              >
                <FileText size={16} />
                Open in Editor
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
