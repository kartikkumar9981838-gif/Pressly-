import React, { useState, useRef, useEffect } from 'react';
import { ImageDraft } from '../../types';
import { ImageCropModal } from './ImageCropModal';
import {
  Check,
  X,
  Move,
  Maximize2,
  RotateCw,
  Sun,
  Image as ImageIcon,
  CheckCircle2,
  Crop,
  RotateCcw,
} from 'lucide-react';

interface ImageOverlayProps {
  imageDraft: ImageDraft;
  onUpdateImageDraft: (updated: ImageDraft) => void;
  onBake: () => void;
  onCancel: () => void;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  zoomLevel?: number;
  activePage: number;
  pageCount: number;
}

export const ImageOverlay: React.FC<ImageOverlayProps> = ({
  imageDraft,
  onUpdateImageDraft,
  onBake,
  onCancel,
  canvasRef,
  activePage,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [isRotating, setIsRotating] = useState(false);
  const [isCropModalOpen, setIsCropModalOpen] = useState(false);

  const dragStartRef = useRef<{ mouseX: number; mouseY: number; initXRatio: number; initYRatio: number }>({
    mouseX: 0,
    mouseY: 0,
    initXRatio: 0.5,
    initYRatio: 0.5,
  });

  const resizeStartRef = useRef<{
    mouseX: number;
    mouseY: number;
    initWidthRatio: number;
    handle: string;
  }>({
    mouseX: 0,
    mouseY: 0,
    initWidthRatio: 0.3,
    handle: 'se',
  });

  const rotateStartRef = useRef<{ initAngle: number; startPointerAngle: number }>({
    initAngle: 0,
    startPointerAngle: 0,
  });

  // Global window pointermove and pointerup listeners for ultra-reliable tracking
  useEffect(() => {
    const handleGlobalPointerMove = (e: PointerEvent) => {
      if (!canvasRef.current) return;
      const rect = canvasRef.current.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;

      // 1. DRAGGING
      if (isDragging) {
        const dx = e.clientX - dragStartRef.current.mouseX;
        const dy = e.clientY - dragStartRef.current.mouseY;

        let newXRatio = dragStartRef.current.initXRatio + dx / rect.width;
        let newYRatio = dragStartRef.current.initYRatio + dy / rect.height;

        // Constrain within visible bounds (2% to 98%)
        newXRatio = Math.max(0.02, Math.min(0.98, newXRatio));
        newYRatio = Math.max(0.02, Math.min(0.98, newYRatio));

        onUpdateImageDraft({
          ...imageDraft,
          xRatio: newXRatio,
          yRatio: newYRatio,
        });
      }

      // 2. RESIZING & SIDE ADJUSTING
      else if (isResizing) {
        const dx = e.clientX - resizeStartRef.current.mouseX;
        const dy = e.clientY - resizeStartRef.current.mouseY;
        const handle = resizeStartRef.current.handle;

        let factor = 1;
        if (handle.includes('w')) factor = -1;
        if (handle === 'n') factor = -1;

        let deltaRatio = 0;
        if (handle === 'n' || handle === 's') {
          deltaRatio = (dy * factor) / rect.height;
        } else {
          deltaRatio = (dx * factor) / rect.width;
        }

        const newWidthRatio = Math.max(
          0.05,
          Math.min(0.95, resizeStartRef.current.initWidthRatio + deltaRatio * 1.5)
        );

        onUpdateImageDraft({
          ...imageDraft,
          widthRatio: newWidthRatio,
        });
      }

      // 3. ROTATING
      else if (isRotating) {
        const centerX = rect.left + imageDraft.xRatio * rect.width;
        const centerY = rect.top + imageDraft.yRatio * rect.height;

        const currentAngle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * (180 / Math.PI);
        const delta = currentAngle - rotateStartRef.current.startPointerAngle;
        let newRot = Math.round(rotateStartRef.current.initAngle + delta);

        // Normalize to 0..359
        newRot = ((newRot % 360) + 360) % 360;

        // Snap to 0, 90, 180, 270 if close (within 4 degrees)
        if (Math.abs(newRot - 0) <= 4 || Math.abs(newRot - 360) <= 4) newRot = 0;
        else if (Math.abs(newRot - 90) <= 4) newRot = 90;
        else if (Math.abs(newRot - 180) <= 4) newRot = 180;
        else if (Math.abs(newRot - 270) <= 4) newRot = 270;

        onUpdateImageDraft({
          ...imageDraft,
          rotation: newRot,
        });
      }
    };

    const handleGlobalPointerUp = () => {
      if (isDragging) setIsDragging(false);
      if (isResizing) setIsResizing(false);
      if (isRotating) setIsRotating(false);
    };

    if (isDragging || isResizing || isRotating) {
      window.addEventListener('pointermove', handleGlobalPointerMove);
      window.addEventListener('pointerup', handleGlobalPointerUp);
    }

    return () => {
      window.removeEventListener('pointermove', handleGlobalPointerMove);
      window.removeEventListener('pointerup', handleGlobalPointerUp);
    };
  }, [isDragging, isResizing, isRotating, imageDraft, onUpdateImageDraft, canvasRef]);

  // DRAG ON-PAGE DRAFT
  const handlePointerDownDrag = (e: React.PointerEvent) => {
    // If clicking inside a button, input, slider, or handle, DO NOT start drag
    if ((e.target as HTMLElement).closest('button, input, select, [data-control-handle], [data-no-drag]')) {
      return;
    }
    if (e.button !== 0 && e.pointerType === 'mouse') return;

    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
    dragStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      initXRatio: imageDraft.xRatio,
      initYRatio: imageDraft.yRatio,
    };
  };

  // RESIZE ON-PAGE DRAFT FROM CORNERS OR EDGES
  const handlePointerDownResize = (e: React.PointerEvent, handle: string) => {
    e.preventDefault();
    e.stopPropagation();
    setIsResizing(true);
    resizeStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      initWidthRatio: imageDraft.widthRatio,
      handle,
    };
  };

  // ROTATE FROM TOP HANDLE
  const handlePointerDownRotate = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!canvasRef.current) return;

    setIsRotating(true);
    const rect = canvasRef.current.getBoundingClientRect();
    const centerX = rect.left + imageDraft.xRatio * rect.width;
    const centerY = rect.top + imageDraft.yRatio * rect.height;

    const startAngle = Math.atan2(e.clientY - centerY, e.clientX - centerX) * (180 / Math.PI);

    rotateStartRef.current = {
      initAngle: imageDraft.rotation,
      startPointerAngle: startAngle,
    };
  };

  // APPLY CROP (Updates draft image immediately on canvas without baking yet)
  const handleApplyCrop = (cropped: {
    buffer: ArrayBuffer;
    dataUrl: string;
    width: number;
    height: number;
    aspectRatio: number;
  }) => {
    onUpdateImageDraft({
      ...imageDraft,
      imageBytes: cropped.buffer,
      imageDataUrl: cropped.dataUrl,
      naturalWidth: cropped.width,
      naturalHeight: cropped.height,
      aspectRatio: cropped.aspectRatio,
      originalImageBytes: imageDraft.originalImageBytes || imageDraft.imageBytes,
      originalImageDataUrl: imageDraft.originalImageDataUrl || imageDraft.imageDataUrl,
      originalWidth: imageDraft.originalWidth || imageDraft.naturalWidth,
      originalHeight: imageDraft.originalHeight || imageDraft.naturalHeight,
      isCropped: true,
    });
  };

  // RESET TO ORIGINAL UNCROPPED
  const handleResetCrop = () => {
    if (!imageDraft.originalImageBytes || !imageDraft.originalImageDataUrl) return;
    const origW = imageDraft.originalWidth || imageDraft.naturalWidth;
    const origH = imageDraft.originalHeight || imageDraft.naturalHeight;
    onUpdateImageDraft({
      ...imageDraft,
      imageBytes: imageDraft.originalImageBytes,
      imageDataUrl: imageDraft.originalImageDataUrl,
      naturalWidth: origW,
      naturalHeight: origH,
      aspectRatio: origW / origH,
      isCropped: false,
    });
  };

  const posXPercent = imageDraft.xRatio * 100;
  const posYPercent = imageDraft.yRatio * 100;
  const widthPercent = imageDraft.widthRatio * 100;

  return (
    <div className="absolute inset-0 pointer-events-none z-30 overflow-visible">
      {/* 1. TOP COMPACT FLOATING TOOLBAR */}
      <div
        className="absolute top-3 left-1/2 -translate-x-1/2 z-40 bg-white/95 backdrop-blur-md rounded-2xl shadow-xl border border-[#E8E8E6] px-4 py-2.5 text-[#1B2740] pointer-events-auto max-w-[96%] flex flex-wrap items-center justify-between gap-3 text-xs animate-in fade-in slide-in-from-top-2 duration-200"
        onPointerDown={(e) => e.stopPropagation()}
        data-no-drag="true"
      >
        {/* Left: Image Info */}
        <div className="flex items-center space-x-2">
          <div className="w-6 h-6 rounded-lg bg-[#C4432E]/10 text-[#C4432E] flex items-center justify-center shrink-0">
            <ImageIcon size={14} />
          </div>
          <div className="truncate max-w-[140px] sm:max-w-[200px]">
            <span className="font-bold text-[#1B2740] truncate block text-[11px]">
              {imageDraft.fileName || 'Inserted Image'}
            </span>
            <span className="text-[9px] text-[#6B7280] font-ibm-mono block uppercase">
              {imageDraft.imageFormat.toUpperCase()} • {imageDraft.naturalWidth}×{imageDraft.naturalHeight} • P.{activePage}
            </span>
          </div>
        </div>

        {/* Crop Toolbar Action */}
        <div className="flex items-center space-x-1.5">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsCropModalOpen(true);
            }}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition-colors cursor-pointer ${
              imageDraft.isCropped
                ? 'bg-[#C4432E]/10 text-[#C4432E] border border-[#C4432E]/30 hover:bg-[#C4432E]/20'
                : 'bg-[#F6F6F4] text-[#1B2740] border border-[#E8E8E6] hover:border-[#C4432E]'
            }`}
            title="Crop and trim edges with interactive bounding box"
          >
            <Crop size={13} className="text-[#C4432E]" />
            <span>{imageDraft.isCropped ? 'Re-crop' : 'Crop & Trim'}</span>
          </button>

          {imageDraft.isCropped && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleResetCrop();
              }}
              className="p-1 rounded-lg bg-[#F6F6F4] border border-[#E8E8E6] text-[#6B7280] hover:text-[#1B2740] hover:bg-gray-100 transition-colors cursor-pointer"
              title="Reset to uncropped original image"
            >
              <RotateCcw size={12} />
            </button>
          )}
        </div>

        {/* Quick Rotation Buttons */}
        <div className="flex items-center space-x-1">
          <RotateCw size={13} className="text-[#C4432E] shrink-0 mr-1 hidden sm:block" />
          {[0, 90, 180, 270].map((deg) => (
            <button
              key={deg}
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onUpdateImageDraft({ ...imageDraft, rotation: deg });
              }}
              className={`px-2 py-0.5 rounded text-[10px] font-bold border transition-colors cursor-pointer ${
                imageDraft.rotation === deg
                  ? 'bg-[#C4432E] text-white border-[#C4432E]'
                  : 'bg-[#F6F6F4] text-[#1B2740] border-[#E8E8E6] hover:border-[#C4432E]'
              }`}
            >
              {deg}°
            </button>
          ))}
        </div>

        {/* Opacity Slider */}
        <div className="hidden md:flex items-center space-x-1.5">
          <Sun size={13} className="text-[#C4432E] shrink-0" />
          <input
            type="range"
            min={0.1}
            max={1.0}
            step={0.05}
            value={imageDraft.opacity}
            onChange={(e) =>
              onUpdateImageDraft({ ...imageDraft, opacity: parseFloat(e.target.value) })
            }
            className="w-16 accent-[#C4432E] cursor-pointer"
          />
          <span className="font-ibm-mono text-[10px] font-bold text-[#C4432E] w-7">
            {Math.round(imageDraft.opacity * 100)}%
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-1.5 ml-auto">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onCancel();
            }}
            className="px-2.5 py-1 rounded-lg border border-[#E8E8E6] text-[#6B7280] hover:text-[#1B2740] hover:bg-gray-100 transition-colors cursor-pointer text-xs font-medium flex items-center space-x-1"
            title="Cancel Adding Image"
          >
            <X size={14} />
            <span>Cancel</span>
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onBake();
            }}
            className="px-3.5 py-1 rounded-lg bg-[#C4432E] hover:bg-[#a83522] text-white text-xs font-bold shadow-md transition-all cursor-pointer flex items-center space-x-1.5 active:scale-95"
            title="Bake and embed image permanently into PDF"
          >
            <CheckCircle2 size={14} />
            <span>Apply Image</span>
          </button>
        </div>
      </div>

      {/* 2. ON-PAGE DRAGGABLE, RESIZABLE, & ROTATABLE DRAFT IMAGE */}
      <div
        style={{
          left: `${posXPercent}%`,
          top: `${posYPercent}%`,
          width: `${widthPercent}%`,
          transform: `translate(-50%, -50%) rotate(${imageDraft.rotation}deg)`,
        }}
        className="absolute pointer-events-auto group cursor-move select-none touch-none"
        onPointerDown={handlePointerDownDrag}
      >
        <div
          className={`relative p-1 rounded-xl border-2 transition-all ${
            isDragging
              ? 'border-[#C4432E] shadow-2xl bg-[#C4432E]/10 scale-102 ring-2 ring-[#C4432E]/40'
              : 'border-dashed border-[#C4432E] bg-white/20 hover:bg-white/30 hover:border-[#C4432E] shadow-xl backdrop-blur-xs'
          }`}
        >
          {/* FLOATING ACTION HEADER DIRECTLY ON TOP OF DRAFT ELEMENT */}
          <div
            className="absolute -top-11 left-1/2 -translate-x-1/2 flex items-center space-x-1.5 bg-[#1B2740] text-white px-2.5 py-1 rounded-lg shadow-2xl border border-white/20 opacity-95 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 pointer-events-auto"
            onPointerDown={(e) => e.stopPropagation()}
            data-no-drag="true"
          >
            <div className="flex items-center space-x-1 text-[10px] text-gray-300 font-medium mr-1">
              <Move size={11} className="text-[#C4432E]" />
              <span>Drag</span>
            </div>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setIsCropModalOpen(true);
              }}
              className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/20 text-white text-[11px] font-semibold transition-colors cursor-pointer flex items-center space-x-1"
              title="Crop image edges"
            >
              <Crop size={11} className="text-[#C4432E]" />
              <span>Crop</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onBake();
              }}
              className="px-2.5 py-0.5 rounded bg-[#C4432E] hover:bg-[#a83522] text-white text-[11px] font-bold shadow transition-transform cursor-pointer flex items-center space-x-1 active:scale-95"
              title="Apply image into PDF at this exact position"
            >
              <Check size={12} />
              <span>Apply</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onCancel();
              }}
              className="p-0.5 rounded hover:bg-white/20 text-gray-300 hover:text-white cursor-pointer"
              title="Discard draft image"
            >
              <X size={12} />
            </button>
          </div>

          {/* ROTATION HANDLE AT TOP CENTER */}
          <div
            data-control-handle="rotate"
            onPointerDown={handlePointerDownRotate}
            className="absolute -top-5 left-1/2 -translate-x-1/2 w-6 h-6 bg-white text-[#1B2740] border-2 border-[#C4432E] rounded-full flex items-center justify-center cursor-grab active:cursor-grabbing shadow-md hover:scale-125 transition-transform z-40"
            title="Drag to rotate image"
          >
            <RotateCw size={11} className="text-[#C4432E]" />
          </div>

          {/* DRAFT IMAGE PREVIEW */}
          <img
            src={imageDraft.imageDataUrl}
            alt={imageDraft.fileName || 'Inserted Image'}
            style={{
              opacity: imageDraft.opacity,
              display: 'block',
              width: '100%',
              height: 'auto',
              borderRadius: '6px',
              userSelect: 'none',
              pointerEvents: 'none',
            }}
            draggable={false}
          />

          {/* 4 CORNER RESIZE HANDLES */}
          {/* Bottom-Right (SE) */}
          <div
            data-control-handle="se"
            onPointerDown={(e) => handlePointerDownResize(e, 'se')}
            className="absolute -bottom-3 -right-3 w-7 h-7 bg-[#C4432E] text-white rounded-full flex items-center justify-center cursor-nwse-resize shadow-xl border-2 border-white hover:scale-125 active:scale-130 transition-transform z-40"
            title="Drag corner to scale image"
          >
            <Maximize2 size={13} />
          </div>

          {/* Top-Right (NE) */}
          <div
            data-control-handle="ne"
            onPointerDown={(e) => handlePointerDownResize(e, 'ne')}
            className="absolute -top-3 -right-3 w-6 h-6 bg-white text-[#C4432E] rounded-full flex items-center justify-center cursor-nesw-resize shadow-md border-2 border-[#C4432E] hover:scale-125 active:scale-130 transition-transform z-40"
            title="Drag corner to scale image"
          >
            <div className="w-2 h-2 rounded-full bg-[#C4432E]" />
          </div>

          {/* Bottom-Left (SW) */}
          <div
            data-control-handle="sw"
            onPointerDown={(e) => handlePointerDownResize(e, 'sw')}
            className="absolute -bottom-3 -left-3 w-6 h-6 bg-white text-[#C4432E] rounded-full flex items-center justify-center cursor-nesw-resize shadow-md border-2 border-[#C4432E] hover:scale-125 active:scale-130 transition-transform z-40"
            title="Drag corner to scale image"
          >
            <div className="w-2 h-2 rounded-full bg-[#C4432E]" />
          </div>

          {/* Top-Left (NW) */}
          <div
            data-control-handle="nw"
            onPointerDown={(e) => handlePointerDownResize(e, 'nw')}
            className="absolute -top-3 -left-3 w-6 h-6 bg-white text-[#C4432E] rounded-full flex items-center justify-center cursor-nwse-resize shadow-md border-2 border-[#C4432E] hover:scale-125 active:scale-130 transition-transform z-40"
            title="Drag corner to scale image"
          >
            <div className="w-2 h-2 rounded-full bg-[#C4432E]" />
          </div>

          {/* 4 SIDE / EDGE ADJUSTMENT HANDLES */}
          {/* Top Edge (N) */}
          <div
            data-control-handle="n"
            onPointerDown={(e) => handlePointerDownResize(e, 'n')}
            className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-8 h-2.5 bg-white border border-[#C4432E] rounded-full cursor-ns-resize shadow hover:scale-115 transition-transform z-35"
            title="Adjust vertical size"
          />
          {/* Bottom Edge (S) */}
          <div
            data-control-handle="s"
            onPointerDown={(e) => handlePointerDownResize(e, 's')}
            className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-8 h-2.5 bg-white border border-[#C4432E] rounded-full cursor-ns-resize shadow hover:scale-115 transition-transform z-35"
            title="Adjust vertical size"
          />
          {/* Left Edge (W) */}
          <div
            data-control-handle="w"
            onPointerDown={(e) => handlePointerDownResize(e, 'w')}
            className="absolute -left-1.5 top-1/2 -translate-y-1/2 w-2.5 h-8 bg-white border border-[#C4432E] rounded-full cursor-ew-resize shadow hover:scale-115 transition-transform z-35"
            title="Adjust horizontal size"
          />
          {/* Right Edge (E) */}
          <div
            data-control-handle="e"
            onPointerDown={(e) => handlePointerDownResize(e, 'e')}
            className="absolute -right-1.5 top-1/2 -translate-y-1/2 w-2.5 h-8 bg-white border border-[#C4432E] rounded-full cursor-ew-resize shadow hover:scale-115 transition-transform z-35"
            title="Adjust horizontal size"
          />
        </div>
      </div>

      {/* 3. BOUNDING-BOX CROP MODAL */}
      <ImageCropModal
        isOpen={isCropModalOpen}
        onClose={() => setIsCropModalOpen(false)}
        sourceDataUrl={imageDraft.originalImageDataUrl || imageDraft.imageDataUrl}
        sourceWidth={imageDraft.originalWidth || imageDraft.naturalWidth}
        sourceHeight={imageDraft.originalHeight || imageDraft.naturalHeight}
        imageFormat={imageDraft.imageFormat}
        fileName={imageDraft.fileName}
        onApplyCrop={handleApplyCrop}
      />
    </div>
  );
};
