import React, { useEffect, useState } from 'react';
import { FindMatchItem, loadPdfJsDoc } from '../../lib/pdfEngine';

interface FindReplaceHighlightOverlayProps {
  pdfBuffer: ArrayBuffer;
  pageNumber: number;
  zoomLevel: number;
  rotation: number;
  pageMatches: FindMatchItem[];
  focusedMatchId: string | null;
  onSelectMatch: (match: FindMatchItem) => void;
  isActive: boolean;
}

interface HighlightBox {
  match: FindMatchItem;
  canvasX: number;
  canvasY: number;
  canvasWidth: number;
  canvasHeight: number;
  isFocused: boolean;
}

export const FindReplaceHighlightOverlay: React.FC<FindReplaceHighlightOverlayProps> = ({
  pdfBuffer,
  pageNumber,
  zoomLevel,
  rotation,
  pageMatches,
  focusedMatchId,
  onSelectMatch,
  isActive,
}) => {
  const [boxes, setBoxes] = useState<HighlightBox[]>([]);

  useEffect(() => {
    let isCancelled = false;
    if (!isActive || !pdfBuffer || !pageMatches || pageMatches.length === 0) {
      setBoxes([]);
      return;
    }

    const computeHighlights = async () => {
      try {
        const pdfJsDoc = await loadPdfJsDoc(pdfBuffer);
        const page = await pdfJsDoc.getPage(pageNumber);
        const scale = (zoomLevel / 100) * 1.5;
        const viewport = page.getViewport({ scale, rotation });

        const computed: HighlightBox[] = [];

        for (const match of pageMatches) {
          const [x1, y1] = viewport.convertToViewportPoint(match.pdfX, match.pdfY);
          const [x2, y2] = viewport.convertToViewportPoint(
            match.pdfX + match.pdfWidth,
            match.pdfY + match.pdfHeight
          );

          const canvasX = Math.min(x1, x2);
          const canvasY = Math.min(y1, y2);
          const canvasWidth = Math.max(Math.abs(x2 - x1), 10);
          const canvasHeight = Math.max(Math.abs(y2 - y1), 10);

          computed.push({
            match,
            canvasX,
            canvasY,
            canvasWidth,
            canvasHeight,
            isFocused: match.id === focusedMatchId,
          });
        }

        if (!isCancelled) {
          setBoxes(computed);
        }
      } catch (err) {
        console.error('Error computing highlight boxes:', err);
      }
    };

    computeHighlights();

    return () => {
      isCancelled = true;
    };
  }, [pdfBuffer, pageNumber, zoomLevel, rotation, pageMatches, focusedMatchId, isActive]);

  if (!isActive || boxes.length === 0) return null;

  return (
    <div className="absolute inset-0 z-20 pointer-events-none select-none overflow-hidden">
      {boxes.map((box) => {
        const { match, canvasX, canvasY, canvasWidth, canvasHeight, isFocused } = box;
        return (
          <div
            key={match.id}
            onClick={(e) => {
              e.stopPropagation();
              onSelectMatch(match);
            }}
            title={`Match: "${match.matchText}" (Click to focus)`}
            style={{
              left: `${canvasX}px`,
              top: `${canvasY}px`,
              width: `${canvasWidth}px`,
              height: `${canvasHeight}px`,
            }}
            className={`absolute pointer-events-auto cursor-pointer rounded-xs transition-all duration-150 ${
              isFocused
                ? 'bg-amber-300/60 ring-2 ring-[#C4432E] ring-offset-1 shadow-md z-30 animate-pulse'
                : 'bg-yellow-200/40 hover:bg-yellow-300/60 border border-amber-400/60 z-10'
            }`}
          >
            {isFocused && (
              <span className="absolute -top-5 left-1/2 -translate-x-1/2 bg-[#C4432E] text-white text-[9px] font-bold font-ibm-mono px-1.5 py-0.5 rounded shadow-xs whitespace-nowrap">
                Focused
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
};
