import React, { useState, useRef, useEffect } from 'react';
import { EditorMode, PDFTool } from '../../types';
import { PresslyIcon } from '../Logos';
import {
  Settings,
  Download,
  Share2,
  Sparkles,
  CheckCircle2,
  ArrowLeft,
  Menu,
  Printer,
  RotateCcw,
  Save,
  CloudCheck,
  WifiOff,
  PlusSquare,
} from 'lucide-react';

interface EditorHeaderProps {
  selectedFlow: EditorMode | null;
  onStartOver: () => void;
  activeTool: PDFTool | null;
  hasFile: boolean;
  onDownload: () => void;
  onHomeClick: () => void;
  onOpenSettings: () => void;
  onOpenPrint?: () => void;
  autoSaveStatus?: 'saved' | 'saving' | 'error' | 'disabled' | 'idle';
  lastSavedTime?: string | null;
  onManualSave?: () => void;
  isOnline?: boolean;
  isInstalled?: boolean;
  onInstallClick?: () => void;
}

export const EditorHeader: React.FC<EditorHeaderProps> = ({
  selectedFlow,
  onStartOver,
  activeTool,
  hasFile,
  onDownload,
  onHomeClick,
  onOpenSettings,
  onOpenPrint,
  autoSaveStatus = 'idle',
  lastSavedTime,
  onManualSave,
  isOnline = true,
  isInstalled = false,
  onInstallClick,
}) => {
  const [downloading, setDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const isInEditor = (selectedFlow === 'upload' && hasFile) || selectedFlow === 'create';

  // Close menu on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleDownloadClick = () => {
    setDownloading(true);
    setMenuOpen(false);
    setTimeout(() => {
      setDownloading(false);
      setDownloadSuccess(true);
      onDownload();
      setTimeout(() => setDownloadSuccess(false), 2500);
    }, 1000);
  };

  return (
    <header className="h-16 bg-white border-b border-[#E8E8E6] px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30 shadow-2xs">
      {/* Left: Pressly Icon Mark + Wordmark Together + Start Over Link */}
      <div className="flex items-center space-x-2 sm:space-x-3">
        <button
          onClick={onHomeClick}
          className="flex items-center space-x-2 group focus:outline-none cursor-pointer"
          title="Back to Pressly Home"
        >
          <div className="p-1 rounded-lg hover:bg-[#F6F6F4] transition-colors flex items-center gap-2">
            <PresslyIcon size={28} />
            <span className="font-fraunces font-medium text-lg sm:text-xl text-[#1B2740] tracking-tight">
              pressly
            </span>
          </div>
        </button>

        {selectedFlow && (
          <button
            onClick={onStartOver}
            className="inline-flex items-center gap-1 text-xs text-[#1B2740] hover:text-[#C4432E] font-medium font-ibm-mono transition-colors pl-2.5 sm:pl-3 border-l border-[#E8E8E6] cursor-pointer h-7"
            title="Start Over - return to workflow selection"
          >
            <ArrowLeft size={14} />
            <span>Start Over</span>
          </button>
        )}

        {activeTool && selectedFlow && (
          <div className="hidden lg:flex items-center pl-3 border-l border-[#E8E8E6] text-xs">
            <span className="bg-[#C4432E]/10 text-[#C4432E] font-medium px-2.5 py-1 rounded-md font-ibm-mono">
              Active: {activeTool.name}
            </span>
          </div>
        )}
      </div>

      {/* Right: Auto-Save Status, Menu & Settings Gear */}
      {isInEditor ? (
        <div className="flex items-center space-x-2 sm:space-x-3 relative" ref={menuRef}>
          {/* Auto-Save Badge */}
          {hasFile && (
            <button
              type="button"
              onClick={onManualSave}
              title={
                autoSaveStatus === 'saving'
                  ? 'Auto-saving editor state...'
                  : lastSavedTime
                  ? `Last saved at ${lastSavedTime}. Click to save now.`
                  : 'Auto-save active. Click to save now.'
              }
              className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-ibm-mono transition-all cursor-pointer bg-[#F6F6F4] hover:bg-gray-200/70 border-[#E8E8E6]"
            >
              {autoSaveStatus === 'saving' ? (
                <>
                  <Sparkles size={12} className="animate-spin text-[#C4432E]" />
                  <span className="text-[11px] text-[#C4432E] font-medium">Saving...</span>
                </>
              ) : autoSaveStatus === 'saved' || lastSavedTime ? (
                <>
                  <CheckCircle2 size={12} className="text-emerald-600" />
                  <span className="text-[11px] text-[#1B2740] font-medium">
                    Saved <span className="text-gray-400 font-normal">{lastSavedTime || 'recently'}</span>
                  </span>
                </>
              ) : (
                <>
                  <Save size={12} className="text-gray-400" />
                  <span className="text-[11px] text-gray-500">Auto-save on</span>
                </>
              )}
            </button>
          )}

          {/* Hamburger Menu Icon */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className={`w-9 h-9 flex items-center justify-center rounded-full text-[#1B2740] transition-colors cursor-pointer ${
              menuOpen ? 'bg-[#1B2740] text-white' : 'hover:bg-[#F6F6F4]'
            }`}
            title="Menu Options"
          >
            <Menu size={20} />
          </button>

          {/* Settings Gear Icon */}
          <button
            onClick={onOpenSettings}
            className="w-9 h-9 flex items-center justify-center rounded-full text-[#1B2740] hover:bg-[#F6F6F4] transition-colors cursor-pointer"
            title="Editor Settings"
          >
            <Settings size={20} />
          </button>

          {/* Hamburger Dropdown Menu */}
          {menuOpen && (
            <div className="absolute right-0 top-12 w-60 bg-white border border-[#E8E8E6] rounded-xl shadow-xl py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
              <div className="px-3 py-1.5 border-b border-[#E8E8E6] mb-1 flex items-center justify-between">
                <span className="text-[10px] font-ibm-mono uppercase font-semibold text-[#6B7280] tracking-wider">
                  Document Actions
                </span>
                {isOnline ? (
                  <span className="text-[9px] font-ibm-mono text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded font-bold">
                    Offline Ready
                  </span>
                ) : (
                  <span className="text-[9px] font-ibm-mono text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded font-bold flex items-center gap-1">
                    <WifiOff size={9} /> Offline
                  </span>
                )}
              </div>

              {!isInstalled && onInstallClick && (
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onInstallClick();
                  }}
                  className="w-full px-3.5 py-2 text-left text-xs sm:text-sm font-semibold text-[#C4432E] hover:bg-[#C4432E]/10 flex items-center gap-2.5 transition-colors cursor-pointer"
                >
                  <Download size={16} />
                  <span>Install Pressly PWA</span>
                </button>
              )}

              {hasFile && onManualSave && (
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onManualSave();
                  }}
                  className="w-full px-3.5 py-2 text-left text-xs sm:text-sm font-medium text-[#1B2740] hover:bg-[#F6F6F4] hover:text-[#C4432E] flex items-center gap-2.5 transition-colors cursor-pointer"
                >
                  <Save size={16} />
                  <span>Save Progress Now</span>
                </button>
              )}

              <button
                onClick={handleDownloadClick}
                disabled={downloading}
                className="w-full px-3.5 py-2 text-left text-xs sm:text-sm font-medium text-[#1B2740] hover:bg-[#F6F6F4] hover:text-[#C4432E] flex items-center gap-2.5 transition-colors cursor-pointer"
              >
                {downloading ? (
                  <Sparkles size={16} className="animate-spin text-[#C4432E]" />
                ) : downloadSuccess ? (
                  <CheckCircle2 size={16} className="text-emerald-600" />
                ) : (
                  <Download size={16} />
                )}
                <span>{downloading ? 'Exporting PDF...' : downloadSuccess ? 'Export Complete!' : 'Export & Download PDF'}</span>
              </button>

              <button
                onClick={() => {
                  setMenuOpen(false);
                  if (navigator.clipboard) {
                    navigator.clipboard.writeText(window.location.href);
                  }
                  alert('Share link copied to clipboard!');
                }}
                className="w-full px-3.5 py-2 text-left text-xs sm:text-sm font-medium text-[#1B2740] hover:bg-[#F6F6F4] hover:text-[#C4432E] flex items-center gap-2.5 transition-colors cursor-pointer"
              >
                <Share2 size={16} />
                <span>Share Link</span>
              </button>

              <button
                onClick={() => {
                  setMenuOpen(false);
                  if (onOpenPrint) {
                    onOpenPrint();
                  } else {
                    window.print();
                  }
                }}
                className="w-full px-3.5 py-2 text-left text-xs sm:text-sm font-medium text-[#1B2740] hover:bg-[#F6F6F4] hover:text-[#C4432E] flex items-center gap-2.5 transition-colors cursor-pointer"
              >
                <Printer size={16} />
                <span>Print Document</span>
              </button>

              {selectedFlow && (
                <button
                  onClick={() => {
                    setMenuOpen(false);
                    onStartOver();
                  }}
                  className="w-full px-3.5 py-2 text-left text-xs sm:text-sm font-medium text-[#1B2740] hover:bg-[#F6F6F4] hover:text-[#C4432E] flex items-center gap-2.5 transition-colors cursor-pointer border-t border-[#E8E8E6] mt-1 pt-2"
                >
                  <RotateCcw size={16} />
                  <span>Start Over</span>
                </button>
              )}

              <button
                onClick={() => {
                  setMenuOpen(false);
                  onOpenSettings();
                }}
                className="w-full px-3.5 py-2 text-left text-xs sm:text-sm font-medium text-[#1B2740] hover:bg-[#F6F6F4] hover:text-[#C4432E] flex items-center gap-2.5 transition-colors cursor-pointer"
              >
                <Settings size={16} />
                <span>Editor Settings</span>
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="flex items-center space-x-2 text-xs text-[#6B7280] font-ibm-mono">
          <span>Choose Mode</span>
        </div>
      )}
    </header>
  );
};

