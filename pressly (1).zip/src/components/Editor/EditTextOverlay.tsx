import React, { useState, useEffect, useRef } from 'react';
import {
  extractPageTextOverlayItems,
  applyInPlaceTextEdit,
  TextOverlayItem,
} from '../../lib/pdfEngine';
import { Check, X, FileEdit, AlertCircle } from 'lucide-react';

interface EditTextOverlayProps {
  pdfBuffer: ArrayBuffer;
  pageNumber: number;
  pageCount?: number;
  canvasRef: React.RefObject<HTMLCanvasElement>;
  zoomLevel: number;
  rotation: number;
  onApplyEdit: (newPdfBuffer: ArrayBuffer, message: string) => void;
  isActive: boolean;
  onClose?: () => void;
}

export const EditTextOverlay: React.FC<EditTextOverlayProps> = ({
  pdfBuffer,
  pageNumber,
  canvasRef,
  zoomLevel,
  rotation,
  onApplyEdit,
  isActive,
  onClose,
}) => {
  const [textItems, setTextItems] = useState<TextOverlayItem[]>([]);
  const [canvasWidth, setCanvasWidth] = useState<number>(0);
  const [canvasHeight, setCanvasHeight] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(true);
  const [noTextDetected, setNoTextDetected] = useState<boolean>(false);
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [editInputValue, setEditInputValue] = useState<string>('');
  const [bgColor, setBgColor] = useState<string>('#FFFFFF');
  const [isApplying, setIsApplying] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Temporary toast visibility (disappears after 1.8 seconds)
  const [showModeToast, setShowModeToast] = useState<boolean>(true);

  const inputRef = useRef<HTMLInputElement>(null);

  // Helper to sample pixel color from canvas context at item location
  const detectBackgroundColor = (x: number, y: number): string => {
    try {
      if (!canvasRef.current) return '#FFFFFF';
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return '#FFFFFF';
      const sampleX = Math.max(0, Math.min(canvasRef.current.width - 1, Math.round(x - 2)));
      const sampleY = Math.max(0, Math.min(canvasRef.current.height - 1, Math.round(y - 2)));
      const pixel = ctx.getImageData(sampleX, sampleY, 1, 1).data;
      if (pixel[3] < 10) return '#FFFFFF';
      const r = pixel[0].toString(16).padStart(2, '0');
      const g = pixel[1].toString(16).padStart(2, '0');
      const b = pixel[2].toString(16).padStart(2, '0');
      return `#${r}${g}${b}`;
    } catch {
      return '#FFFFFF';
    }
  };

  // Trigger brief active toast on activation or page change, auto-fading after 1.8s
  useEffect(() => {
    if (!isActive) return;
    setShowModeToast(true);
    const timer = setTimeout(() => {
      setShowModeToast(false);
    }, 1800);
    return () => clearTimeout(timer);
  }, [isActive, pageNumber]);

  // Extract text items whenever pdfBuffer, pageNumber, zoomLevel, rotation changes
  useEffect(() => {
    let isCancelled = false;
    if (!pdfBuffer || !isActive) return;

    setLoading(true);
    setEditingItemId(null);
    setErrorMessage(null);

    const scale = (zoomLevel / 100) * 1.5;

    extractPageTextOverlayItems(pdfBuffer, pageNumber, scale, rotation)
      .then((res) => {
        if (isCancelled) return;
        setTextItems(res.items);
        setCanvasWidth(res.canvasWidth);
        setCanvasHeight(res.canvasHeight);
        setLoading(false);
        setNoTextDetected(!res.hasText || res.items.length === 0);
      })
      .catch((err) => {
        console.error('Error extracting text overlay items:', err);
        if (!isCancelled) {
          setNoTextDetected(true);
          setLoading(false);
        }
      });

    return () => {
      isCancelled = true;
    };
  }, [pdfBuffer, pageNumber, zoomLevel, rotation, isActive]);

  // Focus input when editing starts
  useEffect(() => {
    if (editingItemId && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [editingItemId]);

  const handleStartEdit = (item: TextOverlayItem, e: React.MouseEvent | React.TouchEvent) => {
    e.stopPropagation();
    setEditingItemId(item.id);
    setEditInputValue(item.str);
    const bg = detectBackgroundColor(item.canvasX, item.canvasY);
    setBgColor(bg);
  };

  const handleConfirmEdit = async (item: TextOverlayItem) => {
    if (isApplying) return;
    setIsApplying(true);
    try {
      const newBytes = await applyInPlaceTextEdit(pdfBuffer, {
        pageNumber,
        pdfX: item.pdfX,
        pdfY: item.pdfY,
        pdfWidth: item.pdfWidth,
        pdfHeight: item.pdfHeight,
        fontSize: item.fontSize,
        newText: editInputValue,
        backgroundColor: bgColor,
      });
      setEditingItemId(null);
      const cleanBuffer = newBytes.buffer.slice(newBytes.byteOffset, newBytes.byteOffset + newBytes.byteLength);
      onApplyEdit(cleanBuffer, `Updated text in document`);
    } catch (err: any) {
      console.error('Failed to apply in-place text edit:', err);
      setErrorMessage(`Error editing text: ${err.message || 'Unknown error'}`);
    } finally {
      setIsApplying(false);
    }
  };

  const handleCancelEdit = () => {
    setEditingItemId(null);
  };

  const handleDismissNonEditable = () => {
    if (onClose) {
      onClose();
    }
  };

  if (!isActive) return null;

  return (
    <div
      className="absolute inset-0 z-20 pointer-events-auto select-none"
      onClick={handleCancelEdit}
    >
      {/* 1. Standard PDF text layer scanning loader */}
      {loading && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 bg-[#1B2740]/90 backdrop-blur-md text-white text-xs font-ibm-sans px-3.5 py-1.5 rounded-full shadow-lg flex items-center gap-2 animate-fade-in pointer-events-none">
          <div className="w-3 h-3 border-2 border-[#C4432E] border-t-transparent rounded-full animate-spin" />
          <span>Scanning text...</span>
        </div>
      )}

      {/* 2. IMAGE-BASED / NON-EDITABLE PDF MESSAGE MODAL */}
      {!loading && noTextDetected && (
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-40 w-11/12 max-w-md bg-white border border-[#E8E8E6] rounded-2xl shadow-2xl p-6 font-ibm-sans animate-in fade-in zoom-in-95 duration-200"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-start space-x-3.5">
            <div className="w-10 h-10 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 flex items-center justify-center shrink-0">
              <AlertCircle size={22} className="text-[#1B2740]" />
            </div>
            <div className="space-y-2 flex-1">
              <h4 className="font-fraunces font-medium text-base text-[#1B2740]">
                Image-Based PDF
              </h4>
              <p className="text-xs text-[#1B2740]/80 leading-relaxed font-ibm-sans">
                This is an image-based PDF, not a real text document, so it isn't editable. Only PDFs with actual printed/typed text can be edited or searched.
              </p>
            </div>
          </div>

          <div className="flex items-center justify-end mt-5 pt-3 border-t border-[#E8E8E6]">
            <button
              type="button"
              onClick={handleDismissNonEditable}
              className="px-5 py-2 rounded-xl bg-[#1B2740] hover:bg-[#2A3B5C] text-white text-xs font-bold font-ibm-sans transition-all cursor-pointer shadow-md active:scale-95"
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {/* 3. ERROR MESSAGE BANNER */}
      {!loading && errorMessage && (
        <div
          className="absolute top-6 left-1/2 -translate-x-1/2 z-30 w-11/12 max-w-md bg-red-50 border border-red-200 rounded-2xl p-3.5 shadow-xl text-red-900 text-xs font-ibm-sans flex items-start space-x-2.5 animate-in fade-in"
          onClick={(e) => e.stopPropagation()}
        >
          <AlertCircle size={18} className="text-red-600 shrink-0 mt-0.5" />
          <div className="flex-1 space-y-1">
            <p className="font-semibold">{errorMessage}</p>
          </div>
          <button
            type="button"
            onClick={() => setErrorMessage(null)}
            className="text-red-700 hover:text-red-900 cursor-pointer p-0.5"
          >
            <X size={15} />
          </button>
        </div>
      )}

      {/* 4. BRIEF ENTRY TOAST: "Edit Text Mode Active" (Auto disappears after 1.8 seconds) */}
      {showModeToast && !loading && !noTextDetected && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-30 bg-[#1B2740]/90 backdrop-blur-md text-white px-4 py-1.5 rounded-full shadow-xl flex items-center gap-2 text-xs font-ibm-sans border border-white/20 animate-fade-in pointer-events-none transition-all duration-300">
          <FileEdit size={14} className="text-[#C4432E]" />
          <span className="font-semibold">Edit Text Mode Active</span>
          <span className="text-gray-300 text-[11px] hidden sm:inline">— Tap any text</span>
        </div>
      )}

      {/* 5. DEDICATED BOTTOM-CORNER "EXIT EDIT MODE" BUTTON (Only when text is present) */}
      {onClose && !noTextDetected && (
        <div className="fixed bottom-22 right-4 sm:right-6 z-40 pointer-events-auto">
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              onClose();
            }}
            className="flex items-center gap-2 bg-[#1B2740]/95 hover:bg-[#C4432E] text-white px-3.5 py-2 rounded-full shadow-2xl border border-white/20 text-xs font-semibold font-ibm-sans transition-all duration-200 hover:scale-105 cursor-pointer backdrop-blur-md group"
            title="Exit Edit Text Mode"
          >
            <FileEdit size={14} className="text-[#C4432E] group-hover:text-white transition-colors" />
            <span>Exit Edit Mode</span>
            <X size={14} className="opacity-70 group-hover:opacity-100 transition-opacity ml-0.5" />
          </button>
        </div>
      )}

      {/* 6. Text Item Overlay Regions (Clickable & Editable on native text PDFs) */}
      {!loading &&
        !noTextDetected &&
        canvasWidth > 0 &&
        canvasHeight > 0 &&
        textItems.map((item) => {
          const isEditing = item.id === editingItemId;
          const leftPct = (item.canvasX / canvasWidth) * 100;
          const topPct = (item.canvasY / canvasHeight) * 100;
          const widthPct = (item.canvasWidth / canvasWidth) * 100;
          const heightPct = (item.canvasHeight / canvasHeight) * 100;

          if (isEditing) {
            return (
              <div
                key={item.id}
                style={{
                  position: 'absolute',
                  left: `${leftPct}%`,
                  top: `${topPct}%`,
                  minWidth: `${Math.max(widthPct, 8)}%`,
                  height: `${heightPct}%`,
                  zIndex: 40,
                }}
                className="flex items-center"
                onClick={(e) => e.stopPropagation()}
                onPointerDown={(e) => e.stopPropagation()}
              >
                {/* Floating Confirm & Cancel Action Pills */}
                <div className="absolute -top-10 left-0 flex items-center gap-1.5 bg-[#1B2740] text-white px-2.5 py-1 rounded-lg shadow-2xl border border-white/20 z-50">
                  <button
                    type="button"
                    onClick={() => handleConfirmEdit(item)}
                    disabled={isApplying}
                    className="p-1 hover:bg-emerald-600 rounded text-emerald-400 hover:text-white transition-colors cursor-pointer flex items-center gap-1 text-[11px] font-semibold"
                    title="Apply Edit (Enter)"
                  >
                    {isApplying ? (
                      <div className="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <Check size={14} />
                    )}
                    <span>Apply</span>
                  </button>
                  <div className="w-px h-3 bg-white/20" />
                  <button
                    type="button"
                    onClick={handleCancelEdit}
                    disabled={isApplying}
                    className="p-1 hover:bg-red-600 rounded text-gray-300 hover:text-white transition-colors cursor-pointer flex items-center gap-1 text-[11px] font-semibold"
                    title="Cancel Edit (Esc)"
                  >
                    <X size={14} />
                    <span>Cancel</span>
                  </button>
                </div>

                {/* Inline Editable Input */}
                <input
                  ref={inputRef}
                  type="text"
                  value={editInputValue}
                  onChange={(e) => setEditInputValue(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleConfirmEdit(item);
                    } else if (e.key === 'Escape') {
                      e.preventDefault();
                      handleCancelEdit();
                    }
                  }}
                  className="bg-white text-[#1B2740] border-2 border-[#C4432E] rounded-md px-1.5 py-0.5 shadow-xl focus:outline-none w-full text-xs font-semibold"
                  style={{
                    minWidth: '60px',
                    lineHeight: '1.2',
                  }}
                  autoFocus
                />
              </div>
            );
          }

          return (
            <div
              key={item.id}
              onClick={(e) => handleStartEdit(item, e)}
              onPointerDown={(e) => e.stopPropagation()}
              onTouchEnd={(e) => handleStartEdit(item, e)}
              style={{
                position: 'absolute',
                left: `${leftPct}%`,
                top: `${topPct}%`,
                width: `${widthPct}%`,
                height: `${heightPct}%`,
                minWidth: '14px',
                minHeight: '14px',
                pointerEvents: 'auto',
                zIndex: 25,
              }}
              className="cursor-pointer transition-all border border-transparent hover:border-dashed hover:border-[#C4432E] hover:bg-[#C4432E]/10 rounded-xs group"
              title={`Click or tap to edit: "${item.str}"`}
            />
          );
        })}
    </div>
  );
};
