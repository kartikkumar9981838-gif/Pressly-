import React, { useState, useEffect, useRef } from 'react';
import { Lock, Unlock, Eye, EyeOff, X, AlertCircle, Sparkles, ShieldCheck } from 'lucide-react';

interface PasswordPromptModalProps {
  isOpen: boolean;
  fileName: string;
  onUnlock: (password: string) => Promise<void> | void;
  onCancel?: () => void;
  onClose?: () => void;
  isLoading?: boolean;
  isProcessing?: boolean;
  errorMessage?: string | null;
}

export const PasswordPromptModal: React.FC<PasswordPromptModalProps> = ({
  isOpen,
  fileName,
  onUnlock,
  onCancel,
  onClose,
  isLoading = false,
  isProcessing = false,
  errorMessage = null,
}) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const processing = isLoading || isProcessing;
  const handleClose = onCancel || onClose || (() => {});

  useEffect(() => {
    if (isOpen) {
      setPassword('');
      setShowPassword(false);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim() || processing) return;
    onUnlock(password);
  };

  return (
    <div
      id="password-prompt-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1B2740]/60 backdrop-blur-xs animate-in fade-in duration-200"
    >
      <div
        id="password-prompt-modal"
        className="bg-white rounded-2xl shadow-2xl border border-[#E8E8E6] w-full max-w-md overflow-hidden flex flex-col animate-in zoom-in-95 duration-150"
      >
        {/* Modal Header */}
        <div className="px-6 py-4.5 border-b border-[#E8E8E6] flex items-center justify-between bg-[#F6F6F4]">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-[#C4432E]/10 border border-[#C4432E]/20 text-[#C4432E] flex items-center justify-center">
              <Lock size={20} />
            </div>
            <div>
              <h3 className="font-fraunces text-lg font-medium text-[#1B2740]">
                Password Protected PDF
              </h3>
              <p className="text-xs text-[#6B7280] font-ibm-mono truncate max-w-[220px]">
                {fileName || 'document.pdf'}
              </p>
            </div>
          </div>
          <button
            id="password-prompt-close-btn"
            type="button"
            onClick={handleClose}
            disabled={processing}
            className="p-1.5 text-[#6B7280] hover:text-[#1B2740] hover:bg-[#E8E8E6]/60 rounded-lg cursor-pointer transition-colors disabled:opacity-50"
            title="Cancel"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="space-y-1.5">
            <p className="text-sm font-medium text-[#1B2740] font-ibm-sans">
              This PDF is password-protected. Enter the password to unlock it:
            </p>
            <p className="text-xs text-[#6B7280] leading-relaxed">
              Decryption is performed 100% locally and privately in your browser using standard WebAssembly decryption.
            </p>
          </div>

          {/* Inline Error Message */}
          {errorMessage && (
            <div
              id="password-error-alert"
              className="p-3.5 bg-red-50 border border-red-200 rounded-xl flex items-start space-x-2.5 text-xs text-red-700 animate-in fade-in duration-150"
            >
              <AlertCircle size={16} className="shrink-0 text-[#C4432E] mt-0.5" />
              <div className="flex-1">
                <span className="font-semibold block">{errorMessage}</span>
              </div>
            </div>
          )}

          {/* Password Input Field */}
          <div className="space-y-2">
            <label
              htmlFor="pdf-password-input"
              className="text-xs font-semibold uppercase tracking-wider text-[#6B7280] font-ibm-mono block"
            >
              Document Password
            </label>
            <div className="relative flex items-center">
              <input
                id="pdf-password-input"
                ref={inputRef}
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password..."
                disabled={processing}
                className="w-full bg-[#F6F6F4] border border-[#E8E8E6] focus:border-[#C4432E] focus:bg-white rounded-xl pl-4 pr-11 py-3 text-sm text-[#1B2740] font-medium outline-none transition-all placeholder:text-gray-400"
                autoComplete="current-password"
                required
              />
              <button
                id="password-toggle-visibility-btn"
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                disabled={processing}
                className="absolute right-3 p-1.5 text-[#6B7280] hover:text-[#1B2740] rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                title={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <div className="p-3 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6] flex items-center space-x-2.5 text-xs text-[#6B7280]">
            <ShieldCheck size={16} className="text-emerald-600 shrink-0" />
            <span className="leading-tight">
              Unlocking removes password protection and produces a decrypted document for editing and export.
            </span>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex items-center justify-end space-x-3">
            <button
              id="password-cancel-btn"
              type="button"
              onClick={handleClose}
              disabled={processing}
              className="px-5 py-2.5 rounded-xl border border-[#E8E8E6] bg-white hover:bg-[#F6F6F4] text-[#1B2740] text-xs font-semibold transition-colors cursor-pointer disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              id="password-unlock-btn"
              type="submit"
              disabled={!password.trim() || processing}
              className="px-6 py-2.5 rounded-xl bg-[#C4432E] hover:bg-[#a83623] text-white text-xs font-bold red-glow transition-all flex items-center space-x-2 cursor-pointer shadow-md disabled:opacity-50"
            >
              {processing ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Decrypting...</span>
                </>
              ) : (
                <>
                  <Unlock size={15} />
                  <span>Unlock PDF</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
