import React, { useState, useRef, useEffect } from 'react';
import { WatermarkDraft, WatermarkType } from '../../types';
import { ImageCropModal } from './ImageCropModal';
import { detectImageType } from '../../lib/pdfEngine';
import {
  Check,
  X,
  Type,
  Image as ImageIcon,
  RotateCw,
  Sun,
  Palette,
  Maximize2,
  Layers,
  Move,
  CheckCircle2,
  Upload,
  Crop,
  Sparkles,
} from 'lucide-react';

interface WatermarkOverlayProps {
  watermark: WatermarkDraft;
  onUpdateWatermark: (updated: WatermarkDraft) => void;
  onBake: () => void;
  onCancel: () => void;
  canvasRef: React.RefObject<HTMLCanvasElement | null>;
  pageCount: number;
  activePage: number;
  zoomLevel?: number;
}

const PRESET_COLORS = [
  '#C4432E', // Brand Red
  '#1B2740', // Deep Navy
  '#2563EB', // Royal Blue
  '#059669', // Emerald
  '#D97706', // Amber
  '#7C3AED', // Purple
  '#6B7280', // Gray
  '#000000', // Black
];

const PRESET_STAMPS = [
  { label: 'APPROVED', color: '#059669', sub: 'VERIFIED & SIGNED' },
  { label: 'CONFIDENTIAL', color: '#C4432E', sub: 'INTERNAL USE ONLY' },
  { label: 'PAID', color: '#2563EB', sub: 'RECEIPT CONFIRMED' },
  { label: 'SAMPLE', color: '#D97706', sub: 'DO NOT DUPLICATE' },
  { label: 'DRAFT', color: '#6B7280', sub: 'PRELIMINARY COPY' },
];

function generateStampPng(text: string, color: string, subtext: string): { dataUrl: string; buffer: ArrayBuffer; width: number; height: number; aspectRatio: number } {
  const canvas = document.createElement('canvas');
  canvas.width = 600;
  canvas.height = 240;
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    return { dataUrl: '', buffer: new ArrayBuffer(0), width: 600, height: 240, aspectRatio: 2.5 };
  }

  ctx.clearRect(0, 0, 600, 240);

  // Outer border with rounded corners
  ctx.strokeStyle = color;
  ctx.lineWidth = 10;
  ctx.strokeRect(20, 20, 560, 200);

  // Inner border
  ctx.lineWidth = 3;
  ctx.strokeRect(32, 32, 536, 176);

  // Main text
  ctx.fillStyle = color;
  ctx.font = 'bold 56px Helvetica, Arial, sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text.toUpperCase(), 300, 105);

  // Subtext
  ctx.font = 'bold 20px Helvetica, Arial, sans-serif';
  ctx.fillText(subtext.toUpperCase(), 300, 162);

  const dataUrl = canvas.toDataURL('image/png');
  const base64 = dataUrl.split(',')[1];
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }

  return {
    dataUrl,
    buffer: bytes.buffer,
    width: 600,
    height: 240,
    aspectRatio: 2.5,
  };
}

export const WatermarkOverlay: React.FC<WatermarkOverlayProps> = ({
  watermark,
  onUpdateWatermark,
  onBake,
  onCancel,
  canvasRef,
  pageCount,
  activePage,
  zoomLevel = 100,
}) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [scaleFactor, setScaleFactor] = useState<number>(1.0);
  const [isCropModalOpen, setIsCropModalOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const currentType: WatermarkType = watermark.type || (watermark.imageDataUrl ? 'image' : 'text');
  const isImageMode = currentType === 'image';

  // Compute scale factor between PDF points and screen CSS pixels
  useEffect(() => {
    const updateScale = () => {
      if (canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        const bufferWidth = canvasRef.current.width;
        if (bufferWidth > 0 && rect.width > 0) {
          const renderScale = (zoomLevel / 100) * 1.5;
          const factor = (rect.width / bufferWidth) * renderScale;
          if (factor > 0) {
            setScaleFactor(factor);
          }
        }
      }
    };

    updateScale();
    const timer = setTimeout(updateScale, 100);
    window.addEventListener('resize', updateScale);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', updateScale);
    };
  }, [canvasRef, zoomLevel]);

  const dragStartRef = useRef<{ mouseX: number; mouseY: number; initXRatio: number; initYRatio: number }>({
    mouseX: 0,
    mouseY: 0,
    initXRatio: 0.5,
    initYRatio: 0.5,
  });

  const resizeStartRef = useRef<{ mouseX: number; mouseY: number; initSize: number; initWidthRatio: number }>({
    mouseX: 0,
    mouseY: 0,
    initSize: 42,
    initWidthRatio: 0.45,
  });

  // DRAG MOVEMENT HANDLERS
  const handlePointerDownDrag = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
    dragStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      initXRatio: watermark.xRatio,
      initYRatio: watermark.yRatio,
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMoveDrag = (e: React.PointerEvent) => {
    if (!isDragging || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;

    const dx = e.clientX - dragStartRef.current.mouseX;
    const dy = e.clientY - dragStartRef.current.mouseY;

    const dxRatio = dx / rect.width;
    const dyRatio = dy / rect.height;

    let newXRatio = dragStartRef.current.initXRatio + dxRatio;
    let newYRatio = dragStartRef.current.initYRatio + dyRatio;

    // Constrain within bounds (5% to 95%)
    newXRatio = Math.max(0.05, Math.min(0.95, newXRatio));
    newYRatio = Math.max(0.05, Math.min(0.95, newYRatio));

    onUpdateWatermark({
      ...watermark,
      xRatio: newXRatio,
      yRatio: newYRatio,
    });
  };

  const handlePointerUpDrag = (e: React.PointerEvent) => {
    if (isDragging) {
      setIsDragging(false);
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {}
    }
  };

  // RESIZE HANDLERS (Corner drag)
  const handlePointerDownResize = (e: React.PointerEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsResizing(true);
    resizeStartRef.current = {
      mouseX: e.clientX,
      mouseY: e.clientY,
      initSize: watermark.fontSize || 42,
      initWidthRatio: watermark.imageWidthRatio || 0.45,
    };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMoveResize = (e: React.PointerEvent) => {
    if (!isResizing || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const dx = e.clientX - resizeStartRef.current.mouseX;
    const dy = e.clientY - resizeStartRef.current.mouseY;

    if (isImageMode) {
      // In image mode, resize adjusts imageWidthRatio
      const deltaRatio = (dx / (rect.width || 500)) * 2;
      const newWidthRatio = Math.max(0.1, Math.min(0.95, resizeStartRef.current.initWidthRatio + deltaRatio));
      onUpdateWatermark({
        ...watermark,
        imageWidthRatio: newWidthRatio,
      });
    } else {
      // In text mode, resize adjusts fontSize
      const delta = (dx + dy) / 2;
      const ptDelta = delta / (scaleFactor || 1);
      const newSize = Math.max(12, Math.min(180, Math.round(resizeStartRef.current.initSize + ptDelta * 0.4)));
      onUpdateWatermark({
        ...watermark,
        fontSize: newSize,
      });
    }
  };

  const handlePointerUpResize = (e: React.PointerEvent) => {
    if (isResizing) {
      setIsResizing(false);
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {}
    }
  };

  // Handle image file selection
  const handleSelectImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const buffer = e.target?.result as ArrayBuffer;
      if (!buffer) return;
      const format = detectImageType(buffer, file.type) || 'png';
      const dataUrlReader = new FileReader();
      dataUrlReader.onload = (ev) => {
        const dataUrl = ev.target?.result as string;
        const img = new Image();
        img.onload = () => {
          onUpdateWatermark({
            ...watermark,
            type: 'image',
            imageDataUrl: dataUrl,
            imageBytes: buffer,
            imageFormat: format,
            naturalWidth: img.naturalWidth || img.width,
            naturalHeight: img.naturalHeight || img.height,
            aspectRatio: (img.naturalWidth || img.width) / (img.naturalHeight || img.height || 1),
            imageFileName: file.name,
            imageWidthRatio: watermark.imageWidthRatio || 0.45,
          });
        };
        img.src = dataUrl;
      };
      dataUrlReader.readAsDataURL(file);
    };
    reader.readAsArrayBuffer(file);
  };

  const handleApplyPresetStamp = (stamp: { label: string; color: string; sub: string }) => {
    const stampData = generateStampPng(stamp.label, stamp.color, stamp.sub);
    onUpdateWatermark({
      ...watermark,
      type: 'image',
      imageDataUrl: stampData.dataUrl,
      imageBytes: stampData.buffer,
      imageFormat: 'png',
      naturalWidth: stampData.width,
      naturalHeight: stampData.height,
      aspectRatio: stampData.aspectRatio,
      imageFileName: `${stamp.label.toLowerCase()}_stamp.png`,
      imageWidthRatio: watermark.imageWidthRatio || 0.45,
    });
  };

  // Switch to image mode with default stamp if no image present
  const handleSwitchToImage = () => {
    if (!watermark.imageDataUrl) {
      handleApplyPresetStamp(PRESET_STAMPS[0]);
    } else {
      onUpdateWatermark({ ...watermark, type: 'image' });
    }
  };

  // Calculate percentage positions
  const posXPercent = watermark.xRatio * 100;
  const posYPercent = watermark.yRatio * 100;

  // Calculate screen width for image
  const canvasWidth = canvasRef.current ? canvasRef.current.getBoundingClientRect().width : 600;
  const imgWidthRatio = watermark.imageWidthRatio || 0.45;
  const imgDisplayWidth = Math.max(60, canvasWidth * imgWidthRatio);
  const imgAspectRatio = watermark.aspectRatio || (watermark.naturalWidth && watermark.naturalHeight ? watermark.naturalWidth / watermark.naturalHeight : 2);
  const imgDisplayHeight = imgDisplayWidth / (imgAspectRatio || 1);

  return (
    <div className="absolute inset-0 pointer-events-none z-30 overflow-visible">
      <input
        ref={fileInputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleSelectImageFile(file);
          e.target.value = '';
        }}
      />

      {/* 1. TOP COMPACT FLOATING BAR (NON-OBTRUSIVE AT TOP OF CANVAS) */}
      <div className="absolute top-3 left-1/2 -translate-x-1/2 z-40 bg-white/95 backdrop-blur-md rounded-2xl shadow-xl border border-[#E8E8E6] px-3.5 py-2 text-[#1B2740] pointer-events-auto max-w-[96%] flex flex-wrap items-center justify-between gap-2.5 text-xs animate-in fade-in slide-in-from-top-2 duration-200">
        {/* Mode Switcher: Text vs Image */}
        <div className="flex bg-[#F6F6F4] p-0.5 rounded-xl border border-[#E8E8E6] shrink-0">
          <button
            type="button"
            onClick={() => onUpdateWatermark({ ...watermark, type: 'text' })}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center space-x-1 transition-all cursor-pointer ${
              !isImageMode
                ? 'bg-white text-[#C4432E] shadow-2xs'
                : 'text-[#6B7280] hover:text-[#1B2740]'
            }`}
          >
            <Type size={13} />
            <span>Text</span>
          </button>
          <button
            type="button"
            onClick={handleSwitchToImage}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center space-x-1 transition-all cursor-pointer ${
              isImageMode
                ? 'bg-white text-[#C4432E] shadow-2xs'
                : 'text-[#6B7280] hover:text-[#1B2740]'
            }`}
          >
            <ImageIcon size={13} />
            <span>Image</span>
          </button>
        </div>

        {/* Text Mode Controls */}
        {!isImageMode ? (
          <>
            {/* Text Input */}
            <div className="flex items-center space-x-1.5">
              <input
                type="text"
                value={watermark.text}
                onChange={(e) => onUpdateWatermark({ ...watermark, text: e.target.value })}
                placeholder="Watermark Text"
                className="w-28 sm:w-36 px-2.5 py-1 rounded-lg border border-[#E8E8E6] text-xs font-semibold focus:outline-none focus:border-[#C4432E] bg-white"
              />
            </div>

            {/* Color Dots */}
            <div className="hidden sm:flex items-center space-x-1.5">
              {PRESET_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => onUpdateWatermark({ ...watermark, color: c })}
                  style={{ backgroundColor: c }}
                  className={`w-4 h-4 rounded-full border border-black/20 transition-transform cursor-pointer ${
                    watermark.color === c ? 'scale-125 ring-2 ring-[#C4432E] ring-offset-1' : 'hover:scale-110'
                  }`}
                />
              ))}
            </div>
          </>
        ) : (
          /* Image Mode Controls */
          <div className="flex items-center space-x-1.5">
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-2.5 py-1 rounded-lg bg-[#F6F6F4] hover:bg-[#E8E8E6] border border-[#E8E8E6] text-xs font-semibold text-[#1B2740] flex items-center space-x-1 cursor-pointer transition-colors"
            >
              <Upload size={12} className="text-[#C4432E]" />
              <span>{watermark.imageFileName ? 'Replace' : 'Upload Image'}</span>
            </button>

            {watermark.imageDataUrl && (
              <button
                type="button"
                onClick={() => setIsCropModalOpen(true)}
                className="px-2 py-1 rounded-lg bg-[#F6F6F4] hover:bg-[#E8E8E6] border border-[#E8E8E6] text-xs font-semibold text-[#1B2740] flex items-center space-x-1 cursor-pointer transition-colors"
                title="Crop watermark image"
              >
                <Crop size={12} className="text-[#C4432E]" />
                <span className="hidden sm:inline">Crop</span>
              </button>
            )}

            {/* Quick Stamp Selector Dropdown / Chips */}
            <div className="hidden md:flex items-center space-x-1">
              {PRESET_STAMPS.map((stamp) => (
                <button
                  key={stamp.label}
                  type="button"
                  onClick={() => handleApplyPresetStamp(stamp)}
                  className="px-1.5 py-0.5 rounded text-[10px] font-bold border border-[#E8E8E6] bg-[#F6F6F4] hover:border-[#C4432E] text-[#1B2740] cursor-pointer transition-colors"
                >
                  {stamp.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Size Slider */}
        <div className="hidden lg:flex items-center space-x-1.5">
          <Maximize2 size={13} className="text-[#C4432E] shrink-0" />
          {isImageMode ? (
            <input
              type="range"
              min={0.1}
              max={0.9}
              step={0.05}
              value={watermark.imageWidthRatio || 0.45}
              onChange={(e) => onUpdateWatermark({ ...watermark, imageWidthRatio: parseFloat(e.target.value) })}
              className="w-16 accent-[#C4432E] cursor-pointer"
              title="Image Width Ratio"
            />
          ) : (
            <input
              type="range"
              min={16}
              max={120}
              value={watermark.fontSize}
              onChange={(e) => onUpdateWatermark({ ...watermark, fontSize: parseInt(e.target.value, 10) })}
              className="w-16 accent-[#C4432E] cursor-pointer"
              title="Font Size"
            />
          )}
        </div>

        {/* Rotation Buttons */}
        <div className="flex items-center space-x-1">
          <RotateCw size={13} className="text-[#C4432E] shrink-0 mr-0.5 hidden md:block" />
          {[0, 45, -45, 90].map((deg) => (
            <button
              key={deg}
              type="button"
              onClick={() => onUpdateWatermark({ ...watermark, rotation: deg })}
              className={`px-1.5 py-0.5 rounded text-[10px] font-bold border transition-colors cursor-pointer ${
                watermark.rotation === deg
                  ? 'bg-[#C4432E] text-white border-[#C4432E]'
                  : 'bg-[#F6F6F4] text-[#1B2740] border-[#E8E8E6] hover:border-[#C4432E]'
              }`}
            >
              {deg}°
            </button>
          ))}
        </div>

        {/* Opacity Slider */}
        <div className="hidden md:flex items-center space-x-1.5">
          <Sun size={13} className="text-[#C4432E] shrink-0" />
          <input
            type="range"
            min={0.1}
            max={1.0}
            step={0.05}
            value={watermark.opacity}
            onChange={(e) => onUpdateWatermark({ ...watermark, opacity: parseFloat(e.target.value) })}
            className="w-14 accent-[#C4432E] cursor-pointer"
          />
          <span className="font-ibm-mono text-[10px] font-bold text-[#C4432E] w-6">
            {Math.round(watermark.opacity * 100)}%
          </span>
        </div>

        {/* Scope Button */}
        <button
          type="button"
          onClick={() =>
            onUpdateWatermark({
              ...watermark,
              scope: watermark.scope === 'all' ? 'current' : 'all',
            })
          }
          className="px-2 py-1 rounded-lg bg-[#F6F6F4] hover:bg-[#E8E8E6] border border-[#E8E8E6] text-[11px] font-medium text-[#1B2740] flex items-center space-x-1 cursor-pointer shrink-0"
          title="Toggle Scope"
        >
          <Layers size={12} className="text-[#C4432E]" />
          <span>{watermark.scope === 'all' ? `All (${pageCount})` : `P.${activePage}`}</span>
        </button>

        {/* Action Buttons */}
        <div className="flex items-center space-x-1.5 ml-auto">
          <button
            type="button"
            onClick={onCancel}
            className="p-1.5 rounded-lg border border-[#E8E8E6] text-[#6B7280] hover:text-[#1B2740] hover:bg-gray-100 transition-colors cursor-pointer"
            title="Cancel Watermark"
          >
            <X size={14} />
          </button>
          <button
            type="button"
            onClick={onBake}
            className="px-3 py-1 rounded-lg bg-[#C4432E] hover:bg-[#a83522] text-white text-xs font-bold shadow-md transition-all cursor-pointer flex items-center space-x-1 active:scale-95 shrink-0"
          >
            <CheckCircle2 size={13} />
            <span>Bake</span>
          </button>
        </div>
      </div>

      {/* 2. DRAGGABLE & RESIZABLE LIVE WATERMARK BOX ON CANVAS */}
      <div
        style={{
          left: `${posXPercent}%`,
          top: `${posYPercent}%`,
          transform: `translate(-50%, -50%) rotate(${watermark.rotation}deg)`,
        }}
        className="absolute pointer-events-auto group cursor-move select-none touch-none"
        onPointerDown={handlePointerDownDrag}
        onPointerMove={handlePointerMoveDrag}
        onPointerUp={handlePointerUpDrag}
      >
        <div
          className={`relative px-4 py-2.5 rounded-xl border-2 transition-all ${
            isDragging
              ? 'border-[#C4432E] shadow-2xl bg-[#C4432E]/15 scale-105'
              : 'border-dashed border-[#C4432E] bg-white/10 hover:bg-white/20 hover:border-[#C4432E] shadow-xl backdrop-blur-xs'
          }`}
        >
          {/* QUICK ACTION HEADER DIRECTLY ATTACHED ON TOP OF WATERMARK BOX */}
          <div
            className="absolute -top-11 left-1/2 -translate-x-1/2 flex items-center space-x-1.5 bg-[#1B2740] text-white px-2.5 py-1 rounded-lg shadow-2xl border border-white/20 opacity-90 group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 pointer-events-auto"
            onPointerDown={(e) => e.stopPropagation()}
          >
            <div className="flex items-center space-x-1 text-[10px] text-gray-300 font-medium mr-1">
              <Move size={11} className="text-[#C4432E]" />
              <span>{isImageMode ? 'Image Watermark' : 'Text Watermark'}</span>
            </div>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onBake();
              }}
              className="px-2.5 py-0.5 rounded bg-[#C4432E] hover:bg-[#a83522] text-white text-[11px] font-bold shadow transition-transform cursor-pointer flex items-center space-x-1 active:scale-95"
              title="Bake watermark into PDF at this exact position"
            >
              <Check size={12} />
              <span>Bake</span>
            </button>

            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onCancel();
              }}
              className="p-0.5 rounded hover:bg-white/20 text-gray-300 hover:text-white cursor-pointer"
              title="Cancel"
            >
              <X size={12} />
            </button>
          </div>

          {/* CONTENT: IMAGE WATERMARK OR TEXT WATERMARK */}
          {isImageMode && watermark.imageDataUrl ? (
            <div
              style={{
                width: `${imgDisplayWidth}px`,
                height: `${imgDisplayHeight}px`,
                opacity: watermark.opacity,
              }}
              className="flex items-center justify-center relative overflow-hidden"
            >
              <img
                src={watermark.imageDataUrl}
                alt="Watermark Stamp"
                className="w-full h-full object-contain pointer-events-none drop-shadow-sm"
              />
            </div>
          ) : (
            /* LIVE RENDERED WATERMARK TEXT */
            <span
              style={{
                fontSize: `${Math.max(10, Math.round(watermark.fontSize * scaleFactor))}px`,
                color: watermark.color,
                opacity: watermark.opacity,
                fontFamily: 'sans-serif',
                fontWeight: 'bold',
                whiteSpace: 'nowrap',
                lineHeight: 1.1,
                display: 'block',
                textShadow: watermark.color === '#FFFFFF' ? '0 2px 4px rgba(0,0,0,0.6)' : 'none',
              }}
            >
              {watermark.text || 'WATERMARK'}
            </span>
          )}

          {/* CORNER RESIZE HANDLE (BOTTOM-RIGHT) */}
          <div
            onPointerDown={handlePointerDownResize}
            onPointerMove={handlePointerMoveResize}
            onPointerUp={handlePointerUpResize}
            className="absolute -bottom-3 -right-3 w-7 h-7 bg-[#C4432E] text-white rounded-full flex items-center justify-center cursor-nwse-resize shadow-xl border-2 border-white hover:scale-125 transition-transform"
            title={isImageMode ? 'Drag to resize image width' : 'Drag to resize font size'}
          >
            <Maximize2 size={13} />
          </div>
        </div>
      </div>

      {/* CROP MODAL IF OPEN */}
      {isCropModalOpen && watermark.imageDataUrl && (
        <ImageCropModal
          isOpen={isCropModalOpen}
          onClose={() => setIsCropModalOpen(false)}
          sourceDataUrl={watermark.imageDataUrl}
          sourceWidth={watermark.naturalWidth || 600}
          sourceHeight={watermark.naturalHeight || 300}
          imageFormat={watermark.imageFormat || 'png'}
          fileName={watermark.imageFileName || 'watermark.png'}
          onApplyCrop={(cropped) => {
            onUpdateWatermark({
              ...watermark,
              imageDataUrl: cropped.dataUrl,
              imageBytes: cropped.buffer,
              naturalWidth: cropped.width,
              naturalHeight: cropped.height,
              aspectRatio: cropped.aspectRatio,
            });
            setIsCropModalOpen(false);
          }}
        />
      )}
    </div>
  );
};
