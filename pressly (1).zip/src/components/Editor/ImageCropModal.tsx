import React, { useState, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { cropImageToBuffer } from '../../lib/pdfEngine';
import {
  Crop,
  X,
  RotateCcw,
  Move,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

export interface CropRectRatio {
  x: number; // 0..1
  y: number; // 0..1
  width: number; // 0..1
  height: number; // 0..1
}

interface ImageCropModalProps {
  isOpen: boolean;
  onClose: () => void;
  sourceDataUrl: string;
  sourceWidth: number;
  sourceHeight: number;
  imageFormat: 'jpg' | 'png';
  fileName?: string;
  onApplyCrop: (cropped: {
    buffer: ArrayBuffer;
    dataUrl: string;
    width: number;
    height: number;
    aspectRatio: number;
  }) => void;
}

type AspectRatioPreset = 'free' | 'original' | '1:1' | '4:3' | '16:9' | '3:2' | '2:3';

export const ImageCropModal: React.FC<ImageCropModalProps> = ({
  isOpen,
  onClose,
  sourceDataUrl,
  sourceWidth,
  sourceHeight,
  imageFormat,
  fileName,
  onApplyCrop,
}) => {
  const [crop, setCrop] = useState<CropRectRatio>({
    x: 0,
    y: 0,
    width: 1,
    height: 1,
  });

  const [aspectPreset, setAspectPreset] = useState<AspectRatioPreset>('free');
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [activeHandle, setActiveHandle] = useState<string | null>(null);
  const [imageLoaded, setImageLoaded] = useState(false);

  const imgRef = useRef<HTMLImageElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Interaction Ref for continuous drag/resize tracking
  const dragRef = useRef<{
    mode: 'move' | 'nw' | 'ne' | 'sw' | 'se' | 'n' | 's' | 'w' | 'e' | null;
    startX: number;
    startY: number;
    startCrop: CropRectRatio;
    imgWidth: number;
    imgHeight: number;
  }>({
    mode: null,
    startX: 0,
    startY: 0,
    startCrop: { x: 0, y: 0, width: 1, height: 1 },
    imgWidth: 0,
    imgHeight: 0,
  });

  // Reset state whenever modal opens
  useEffect(() => {
    if (isOpen) {
      setCrop({ x: 0, y: 0, width: 1, height: 1 });
      setAspectPreset('free');
      setActiveHandle(null);
      setErrorMessage(null);
      setImageLoaded(false);
    }
  }, [isOpen, sourceDataUrl]);

  // Window-level listener for smooth dragging and side/corner adjustments
  useEffect(() => {
    if (!isOpen) return;

    const handleWindowPointerMove = (e: PointerEvent) => {
      const { mode, startX, startY, startCrop, imgWidth, imgHeight } = dragRef.current;
      if (!mode || imgWidth <= 0 || imgHeight <= 0) return;

      const dx = (e.clientX - startX) / imgWidth;
      const dy = (e.clientY - startY) / imgHeight;
      const minDim = 0.04; // 4% minimum box dimension

      let newX = startCrop.x;
      let newY = startCrop.y;
      let newWidth = startCrop.width;
      let newHeight = startCrop.height;

      if (mode === 'move') {
        newX = Math.max(0, Math.min(1 - startCrop.width, startCrop.x + dx));
        newY = Math.max(0, Math.min(1 - startCrop.height, startCrop.y + dy));
      } else {
        // Adjust West (Left Side)
        if (mode.includes('w')) {
          const rawX = startCrop.x + dx;
          const rawW = startCrop.width - dx;
          if (rawX < 0) {
            newX = 0;
            newWidth = startCrop.x + startCrop.width;
          } else if (rawW < minDim) {
            newX = startCrop.x + startCrop.width - minDim;
            newWidth = minDim;
          } else {
            newX = rawX;
            newWidth = rawW;
          }
        }

        // Adjust East (Right Side)
        if (mode.includes('e')) {
          const rawW = startCrop.width + dx;
          if (newX + rawW > 1) {
            newWidth = 1 - newX;
          } else if (rawW < minDim) {
            newWidth = minDim;
          } else {
            newWidth = rawW;
          }
        }

        // Adjust North (Top Side)
        if (mode.includes('n')) {
          const rawY = startCrop.y + dy;
          const rawH = startCrop.height - dy;
          if (rawY < 0) {
            newY = 0;
            newHeight = startCrop.y + startCrop.height;
          } else if (rawH < minDim) {
            newY = startCrop.y + startCrop.height - minDim;
            newHeight = minDim;
          } else {
            newY = rawY;
            newHeight = rawH;
          }
        }

        // Adjust South (Bottom Side)
        if (mode.includes('s')) {
          const rawH = startCrop.height + dy;
          if (newY + rawH > 1) {
            newHeight = 1 - newY;
          } else if (rawH < minDim) {
            newHeight = minDim;
          } else {
            newHeight = rawH;
          }
        }

        // Apply aspect ratio constraint if fixed preset is selected
        if (aspectPreset !== 'free') {
          let targetRatio = 1;
          if (aspectPreset === '1:1') targetRatio = 1;
          else if (aspectPreset === '4:3') targetRatio = 4 / 3;
          else if (aspectPreset === '16:9') targetRatio = 16 / 9;
          else if (aspectPreset === '3:2') targetRatio = 3 / 2;
          else if (aspectPreset === '2:3') targetRatio = 2 / 3;
          else if (aspectPreset === 'original') targetRatio = sourceWidth / sourceHeight;

          const imageNaturalRatio = sourceWidth / sourceHeight;
          const targetCropHeightToWidth = imageNaturalRatio / targetRatio;

          if (mode.includes('e') || mode.includes('w')) {
            newHeight = Math.min(1 - newY, newWidth * targetCropHeightToWidth);
          } else if (mode.includes('n') || mode.includes('s')) {
            newWidth = Math.min(1 - newX, newHeight / targetCropHeightToWidth);
          }
        }
      }

      setCrop({
        x: Math.max(0, Math.min(1 - minDim, newX)),
        y: Math.max(0, Math.min(1 - minDim, newY)),
        width: Math.max(minDim, Math.min(1 - newX, newWidth)),
        height: Math.max(minDim, Math.min(1 - newY, newHeight)),
      });
    };

    const handleWindowPointerUp = () => {
      if (dragRef.current.mode) {
        dragRef.current.mode = null;
        setActiveHandle(null);
      }
    };

    window.addEventListener('pointermove', handleWindowPointerMove);
    window.addEventListener('pointerup', handleWindowPointerUp);
    return () => {
      window.removeEventListener('pointermove', handleWindowPointerMove);
      window.removeEventListener('pointerup', handleWindowPointerUp);
    };
  }, [isOpen, aspectPreset, sourceWidth, sourceHeight]);

  if (!isOpen) return null;

  // Apply Aspect Ratio Constraint to current crop box
  const applyAspectRatioPreset = (preset: AspectRatioPreset) => {
    setAspectPreset(preset);
    if (preset === 'free') return;

    let targetRatio = 1;
    if (preset === '1:1') targetRatio = 1;
    else if (preset === '4:3') targetRatio = 4 / 3;
    else if (preset === '16:9') targetRatio = 16 / 9;
    else if (preset === '3:2') targetRatio = 3 / 2;
    else if (preset === '2:3') targetRatio = 2 / 3;
    else if (preset === 'original') targetRatio = sourceWidth / sourceHeight;

    const imageNaturalRatio = sourceWidth / sourceHeight;
    const targetCropHeightToWidth = imageNaturalRatio / targetRatio;

    let newWidth = 0.9;
    let newHeight = newWidth * targetCropHeightToWidth;

    if (newHeight > 0.9) {
      newHeight = 0.9;
      newWidth = newHeight / targetCropHeightToWidth;
    }

    const newX = (1 - newWidth) / 2;
    const newY = (1 - newHeight) / 2;

    setCrop({
      x: Math.max(0, newX),
      y: Math.max(0, newY),
      width: Math.min(1, newWidth),
      height: Math.min(1, newHeight),
    });
  };

  // Reset to full image
  const handleReset = () => {
    setCrop({ x: 0, y: 0, width: 1, height: 1 });
    setAspectPreset('free');
  };

  // Initiate Pointer Drag or Resize
  const handleStartInteraction = (
    e: React.PointerEvent,
    mode: 'move' | 'nw' | 'ne' | 'sw' | 'se' | 'n' | 's' | 'w' | 'e'
  ) => {
    e.preventDefault();
    e.stopPropagation();
    if (!imgRef.current) return;

    const rect = imgRef.current.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;

    dragRef.current = {
      mode,
      startX: e.clientX,
      startY: e.clientY,
      startCrop: { ...crop },
      imgWidth: rect.width,
      imgHeight: rect.height,
    };
    setActiveHandle(mode);
  };

  // Perform Final Crop
  const handleApply = async () => {
    setIsProcessing(true);
    setErrorMessage(null);
    try {
      const croppedResult = await cropImageToBuffer(sourceDataUrl, crop, imageFormat);
      onApplyCrop(croppedResult);
      onClose();
    } catch (err: any) {
      console.error('Failed to crop image:', err);
      setErrorMessage(err?.message || 'Failed to crop image. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Calculate live cropped pixel size
  const croppedPxW = Math.max(1, Math.round(crop.width * sourceWidth));
  const croppedPxH = Math.max(1, Math.round(crop.height * sourceHeight));

  const modalContent = (
    <div
      className="fixed inset-0 z-[9999] flex items-center justify-center p-3 sm:p-6 bg-[#1B2740]/80 backdrop-blur-md animate-in fade-in duration-150 select-none"
      onClick={onClose}
      style={{ touchAction: 'none' }}
    >
      <div
        className="relative w-full max-w-4xl max-h-[94vh] bg-white rounded-2xl shadow-2xl border border-[#E8E8E6] flex flex-col overflow-hidden text-[#1B2740]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* MODAL HEADER */}
        <div className="px-5 py-3.5 border-b border-[#E8E8E6] flex items-center justify-between bg-[#F6F6F4]">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#C4432E]/10 text-[#C4432E] flex items-center justify-center">
              <Crop size={18} />
            </div>
            <div>
              <h2 className="font-bold text-sm text-[#1B2740] flex items-center space-x-2">
                <span>Crop & Trim Image</span>
                {fileName && (
                  <span className="text-[11px] font-normal text-[#6B7280] font-ibm-mono truncate max-w-[200px]">
                    ({fileName})
                  </span>
                )}
              </h2>
              <div className="flex items-center space-x-2 text-[10px] text-[#6B7280] font-ibm-mono">
                <span>Original: {sourceWidth} × {sourceHeight} px</span>
                <span>•</span>
                <span className="text-[#C4432E] font-bold">
                  Cropped: {croppedPxW} × {croppedPxH} px
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-[#6B7280] hover:text-[#1B2740] hover:bg-gray-200 rounded-lg transition-colors cursor-pointer"
            title="Close crop window"
          >
            <X size={18} />
          </button>
        </div>

        {/* ASPECT RATIO PRESET TOOLBAR */}
        <div className="px-5 py-2.5 bg-white border-b border-[#E8E8E6] flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center space-x-1.5 flex-wrap gap-y-1">
            <span className="text-[11px] font-bold text-[#6B7280] mr-1">Aspect Ratio:</span>
            {[
              { key: 'free', label: 'Freeform' },
              { key: 'original', label: 'Original' },
              { key: '1:1', label: '1:1 Square' },
              { key: '4:3', label: '4:3' },
              { key: '16:9', label: '16:9' },
              { key: '3:2', label: '3:2' },
              { key: '2:3', label: '2:3' },
            ].map((p) => (
              <button
                key={p.key}
                type="button"
                onClick={() => applyAspectRatioPreset(p.key as AspectRatioPreset)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  aspectPreset === p.key
                    ? 'bg-[#C4432E] text-white shadow-xs'
                    : 'bg-[#F6F6F4] text-[#1B2740] border border-[#E8E8E6] hover:border-[#C4432E]'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleReset}
            className="px-2.5 py-1 rounded-lg border border-[#E8E8E6] text-[#6B7280] hover:text-[#1B2740] hover:bg-[#F6F6F4] text-xs font-medium flex items-center space-x-1 cursor-pointer transition-colors"
            title="Reset crop to full image"
          >
            <RotateCcw size={13} />
            <span>Reset Bounds</span>
          </button>
        </div>

        {/* CROP WORKSPACE */}
        <div
          ref={containerRef}
          className="flex-1 min-h-[300px] max-h-[58vh] bg-[#0F172A] p-4 sm:p-6 flex items-center justify-center overflow-hidden relative"
        >
          {/* TIGHT INLINE WRAPPER SIZED EXACTLY TO IMAGE */}
          <div className="relative inline-block select-none max-w-full max-h-full">
            {/* BACKGROUND SOURCE IMAGE */}
            <img
              ref={imgRef}
              src={sourceDataUrl}
              alt="Crop source"
              onLoad={() => setImageLoaded(true)}
              className="max-h-[calc(58vh-32px)] max-w-full object-contain pointer-events-none rounded-lg block shadow-2xl"
              draggable={false}
            />

            {/* INTERACTIVE CROP BOX OVERLAY */}
            <div className="absolute inset-0 pointer-events-none overflow-visible">
              {/* TOP MASK */}
              <div
                className="absolute top-0 left-0 right-0 bg-black/60 backdrop-blur-[1px]"
                style={{ height: `${crop.y * 100}%` }}
              />
              {/* BOTTOM MASK */}
              <div
                className="absolute left-0 right-0 bottom-0 bg-black/60 backdrop-blur-[1px]"
                style={{ height: `${(1 - (crop.y + crop.height)) * 100}%` }}
              />
              {/* LEFT MASK */}
              <div
                className="absolute bg-black/60 backdrop-blur-[1px]"
                style={{
                  top: `${crop.y * 100}%`,
                  bottom: `${(1 - (crop.y + crop.height)) * 100}%`,
                  left: 0,
                  width: `${crop.x * 100}%`,
                }}
              />
              {/* RIGHT MASK */}
              <div
                className="absolute bg-black/60 backdrop-blur-[1px]"
                style={{
                  top: `${crop.y * 100}%`,
                  bottom: `${(1 - (crop.y + crop.height)) * 100}%`,
                  right: 0,
                  width: `${(1 - (crop.x + crop.width)) * 100}%`,
                }}
              />

              {/* BOUNDING BOX FRAME */}
              <div
                style={{
                  top: `${crop.y * 100}%`,
                  left: `${crop.x * 100}%`,
                  width: `${crop.width * 100}%`,
                  height: `${crop.height * 100}%`,
                  touchAction: 'none',
                }}
                className={`absolute border-2 border-[#C4432E] shadow-2xl pointer-events-auto cursor-move select-none ${
                  activeHandle === 'move' ? 'ring-2 ring-[#C4432E]/60' : ''
                }`}
                onPointerDown={(e) => handleStartInteraction(e, 'move')}
              >
                {/* 3x3 RULE-OF-THIRDS GRID GUIDES */}
                <div className="absolute inset-0 pointer-events-none grid grid-cols-3 grid-rows-3">
                  <div className="border-r border-b border-white/30 border-dashed" />
                  <div className="border-r border-b border-white/30 border-dashed" />
                  <div className="border-b border-white/30 border-dashed" />
                  <div className="border-r border-b border-white/30 border-dashed" />
                  <div className="border-r border-b border-white/30 border-dashed" />
                  <div className="border-b border-white/30 border-dashed" />
                  <div className="border-r border-b border-white/30 border-dashed" />
                  <div className="border-r border-b border-white/30 border-dashed" />
                  <div />
                </div>

                {/* DIMENSION BADGE OVER CROP BOX */}
                <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-[#1B2740] text-white text-[10px] font-ibm-mono px-2 py-0.5 rounded shadow border border-white/20 pointer-events-none whitespace-nowrap z-30">
                  {croppedPxW} × {croppedPxH} px
                </div>

                {/* 4 CORNER RESIZE HANDLES */}
                {/* Top-Left (NW) */}
                <div
                  onPointerDown={(e) => handleStartInteraction(e, 'nw')}
                  className="absolute -top-3 -left-3 w-6 h-6 bg-[#C4432E] border-2 border-white rounded-full cursor-nwse-resize shadow-lg hover:scale-125 active:scale-130 transition-transform z-30"
                  style={{ touchAction: 'none' }}
                  title="Trim top-left corner"
                />

                {/* Top-Right (NE) */}
                <div
                  onPointerDown={(e) => handleStartInteraction(e, 'ne')}
                  className="absolute -top-3 -right-3 w-6 h-6 bg-[#C4432E] border-2 border-white rounded-full cursor-nesw-resize shadow-lg hover:scale-125 active:scale-130 transition-transform z-30"
                  style={{ touchAction: 'none' }}
                  title="Trim top-right corner"
                />

                {/* Bottom-Left (SW) */}
                <div
                  onPointerDown={(e) => handleStartInteraction(e, 'sw')}
                  className="absolute -bottom-3 -left-3 w-6 h-6 bg-[#C4432E] border-2 border-white rounded-full cursor-nesw-resize shadow-lg hover:scale-125 active:scale-130 transition-transform z-30"
                  style={{ touchAction: 'none' }}
                  title="Trim bottom-left corner"
                />

                {/* Bottom-Right (SE) */}
                <div
                  onPointerDown={(e) => handleStartInteraction(e, 'se')}
                  className="absolute -bottom-3 -right-3 w-6 h-6 bg-[#C4432E] border-2 border-white rounded-full cursor-nwse-resize shadow-lg hover:scale-125 active:scale-130 transition-transform z-30"
                  style={{ touchAction: 'none' }}
                  title="Trim bottom-right corner"
                />

                {/* 4 EDGE RESIZE / SIDE ADJUSTMENT HANDLES */}
                {/* Top Side (N) */}
                <div
                  onPointerDown={(e) => handleStartInteraction(e, 'n')}
                  className="absolute -top-2.5 left-1/2 -translate-x-1/2 w-12 h-4 bg-white border-2 border-[#C4432E] rounded-full cursor-ns-resize shadow-md hover:scale-115 active:scale-120 transition-transform z-30 flex items-center justify-center"
                  style={{ touchAction: 'none' }}
                  title="Adjust top edge"
                >
                  <div className="w-4 h-0.5 bg-[#C4432E] rounded-full" />
                </div>
                {/* Bottom Side (S) */}
                <div
                  onPointerDown={(e) => handleStartInteraction(e, 's')}
                  className="absolute -bottom-2.5 left-1/2 -translate-x-1/2 w-12 h-4 bg-white border-2 border-[#C4432E] rounded-full cursor-ns-resize shadow-md hover:scale-115 active:scale-120 transition-transform z-30 flex items-center justify-center"
                  style={{ touchAction: 'none' }}
                  title="Adjust bottom edge"
                >
                  <div className="w-4 h-0.5 bg-[#C4432E] rounded-full" />
                </div>
                {/* Left Side (W) */}
                <div
                  onPointerDown={(e) => handleStartInteraction(e, 'w')}
                  className="absolute -left-2.5 top-1/2 -translate-y-1/2 w-4 h-12 bg-white border-2 border-[#C4432E] rounded-full cursor-ew-resize shadow-md hover:scale-115 active:scale-120 transition-transform z-30 flex items-center justify-center"
                  style={{ touchAction: 'none' }}
                  title="Adjust left edge"
                >
                  <div className="h-4 w-0.5 bg-[#C4432E] rounded-full" />
                </div>
                {/* Right Side (E) */}
                <div
                  onPointerDown={(e) => handleStartInteraction(e, 'e')}
                  className="absolute -right-2.5 top-1/2 -translate-y-1/2 w-4 h-12 bg-white border-2 border-[#C4432E] rounded-full cursor-ew-resize shadow-md hover:scale-115 active:scale-120 transition-transform z-30 flex items-center justify-center"
                  style={{ touchAction: 'none' }}
                  title="Adjust right edge"
                >
                  <div className="h-4 w-0.5 bg-[#C4432E] rounded-full" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ERROR NOTIFICATION IF ANY */}
        {errorMessage && (
          <div className="px-5 py-2 bg-red-50 border-t border-red-200 text-red-700 text-xs flex items-center space-x-2">
            <AlertCircle size={14} className="shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* FOOTER ACTIONS */}
        <div className="px-5 py-3.5 bg-white border-t border-[#E8E8E6] flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs text-[#6B7280]">
            <Move size={14} className="text-[#C4432E]" />
            <span>Drag inside frame to pan • Drag side and corner handles to adjust boundaries</span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-lg border border-[#E8E8E6] text-xs font-semibold text-[#6B7280] hover:text-[#1B2740] hover:bg-[#F6F6F4] transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleApply}
              disabled={isProcessing}
              className="px-4 py-1.5 rounded-lg bg-[#C4432E] hover:bg-[#a83522] text-white text-xs font-bold shadow-md transition-all cursor-pointer flex items-center space-x-1.5 disabled:opacity-50 active:scale-95"
            >
              <CheckCircle2 size={14} />
              <span>{isProcessing ? 'Cropping...' : 'Apply Crop'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  return createPortal(modalContent, document.body);
};
