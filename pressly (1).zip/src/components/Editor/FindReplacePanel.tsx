import React, { useState, useEffect, useRef } from 'react';
import {
  FindMatchItem,
  FindSearchResult,
  PageTextIndex,
  buildFullDocumentTextIndex,
  searchInTextIndex,
  applySingleReplaceInPdf,
  applyReplaceAllInPdf,
  clearPdfTextIndexCache,
} from '../../lib/pdfEngine';
import {
  Search,
  Replace,
  ChevronUp,
  ChevronDown,
  X,
  RotateCcw,
  AlertTriangle,
  Loader2,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

interface FindReplacePanelProps {
  pdfBuffer: ArrayBuffer;
  activePage: number;
  pageCount: number;
  setActivePage: (p: number) => void;
  onUpdatePdfBuffer: (newBuffer: ArrayBuffer, message: string) => void;
  onClose: () => void;
  onMatchesUpdate: (
    matchesByPage: Record<number, FindMatchItem[]>,
    focusedMatchId: string | null
  ) => void;
}

export const FindReplacePanel: React.FC<FindReplacePanelProps> = ({
  pdfBuffer,
  activePage,
  pageCount,
  setActivePage,
  onUpdatePdfBuffer,
  onClose,
  onMatchesUpdate,
}) => {
  const [findQuery, setFindQuery] = useState<string>('');
  const [replaceQuery, setReplaceQuery] = useState<string>('');
  const [matchCase, setMatchCase] = useState<boolean>(false);
  const [wholeWord, setWholeWord] = useState<boolean>(false);

  const [documentIndexes, setDocumentIndexes] = useState<PageTextIndex[] | null>(null);
  const [isBuildingIndex, setIsBuildingIndex] = useState<boolean>(true);
  const [indexProgress, setIndexProgress] = useState<{ current: number; total: number }>({
    current: 0,
    total: pageCount,
  });

  const [searchResult, setSearchResult] = useState<FindSearchResult | null>(null);
  const [focusedIndex, setFocusedIndex] = useState<number>(0);
  const [isProcessingReplace, setIsProcessingReplace] = useState<boolean>(false);

  const [undoStack, setUndoStack] = useState<ArrayBuffer[]>([]);
  const [showReplaceAllConfirm, setShowReplaceAllConfirm] = useState<boolean>(false);
  const [notificationMsg, setNotificationMsg] = useState<string | null>(null);

  const searchInputRef = useRef<HTMLInputElement>(null);

  // Focus search input on mount
  useEffect(() => {
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, []);

  // 1. BUILD DOCUMENT TEXT INDEX ON MOUNT OR BUFFER UPDATE
  useEffect(() => {
    let isCancelled = false;

    const buildIndex = async () => {
      setIsBuildingIndex(true);
      try {
        const indexes = await buildFullDocumentTextIndex(pdfBuffer, (curr, tot) => {
          if (!isCancelled) {
            setIndexProgress({ current: curr, total: tot });
          }
        });
        if (!isCancelled) {
          setDocumentIndexes(indexes);
          setIsBuildingIndex(false);
        }
      } catch (err) {
        console.error('Error building document text index:', err);
        if (!isCancelled) {
          setIsBuildingIndex(false);
        }
      }
    };

    buildIndex();

    return () => {
      isCancelled = true;
    };
  }, [pdfBuffer]);

  // 2. SEARCH-AS-YOU-TYPE DEBOUNCE EFFECT
  useEffect(() => {
    if (!documentIndexes) return;

    const timer = setTimeout(() => {
      const res = searchInTextIndex(documentIndexes, {
        findQuery,
        matchCase,
        wholeWord,
      });

      setSearchResult(res);
      setFocusedIndex(0);

      const firstMatch = res.matches[0];
      if (firstMatch) {
        setActivePage(firstMatch.pageNumber);
        onMatchesUpdate(res.matchesByPage, firstMatch.id);
      } else {
        onMatchesUpdate({}, null);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [findQuery, matchCase, wholeWord, documentIndexes]);

  // Sync highlights when focused index changes
  useEffect(() => {
    if (!searchResult || searchResult.matches.length === 0) {
      onMatchesUpdate({}, null);
      return;
    }
    const currentMatch = searchResult.matches[focusedIndex] || searchResult.matches[0];
    if (currentMatch) {
      if (currentMatch.pageNumber !== activePage) {
        setActivePage(currentMatch.pageNumber);
      }
      onMatchesUpdate(searchResult.matchesByPage, currentMatch.id);
    }
  }, [focusedIndex]);

  // Toast message timer helper
  const showToast = (msg: string) => {
    setNotificationMsg(msg);
    setTimeout(() => setNotificationMsg(null), 4000);
  };

  // Check if entire document has no extractable text layer
  const totalTextLines =
    documentIndexes?.reduce((acc, idx) => acc + idx.lines.length, 0) ?? 0;
  const isDocumentWithoutText =
    !isBuildingIndex && documentIndexes !== null && totalTextLines === 0;

  // Navigate to Next Match
  const handleNextMatch = () => {
    if (!searchResult || searchResult.matches.length === 0) return;
    const nextIdx = (focusedIndex + 1) % searchResult.matches.length;
    setFocusedIndex(nextIdx);
  };

  // Navigate to Previous Match
  const handlePrevMatch = () => {
    if (!searchResult || searchResult.matches.length === 0) return;
    const prevIdx = (focusedIndex - 1 + searchResult.matches.length) % searchResult.matches.length;
    setFocusedIndex(prevIdx);
  };

  // Select a specific match item from list
  const handleSelectMatchItem = (match: FindMatchItem, idx: number) => {
    setFocusedIndex(idx);
    if (match.pageNumber !== activePage) {
      setActivePage(match.pageNumber);
    }
  };

  // Single Replace Handler
  const handleReplaceSingle = async (matchToReplace: FindMatchItem) => {
    if (isProcessingReplace || !matchToReplace) return;
    setIsProcessingReplace(true);

    try {
      // Save state for Undo
      setUndoStack((prev) => [...prev, pdfBuffer.slice(0)]);

      const newBytes = await applySingleReplaceInPdf(
        pdfBuffer,
        matchToReplace.pageNumber,
        matchToReplace,
        replaceQuery
      );

      clearPdfTextIndexCache();
      onUpdatePdfBuffer(newBytes.buffer, `Replaced "${matchToReplace.matchText}" with "${replaceQuery}"`);
      showToast('Replaced 1 occurrence!');
    } catch (err: any) {
      console.error('Error replacing text:', err);
      alert(`Replace failed: ${err.message || 'Unknown error'}`);
    } finally {
      setIsProcessingReplace(false);
    }
  };

  // Replace All Confirmed Handler
  const handleConfirmReplaceAll = async () => {
    if (isProcessingReplace || !searchResult || searchResult.totalMatches === 0) return;
    setShowReplaceAllConfirm(false);
    setIsProcessingReplace(true);

    try {
      // Save state for Undo
      setUndoStack((prev) => [...prev, pdfBuffer.slice(0)]);

      const newBytes = await applyReplaceAllInPdf(
        pdfBuffer,
        searchResult.matches,
        replaceQuery
      );

      const count = searchResult.totalMatches;
      clearPdfTextIndexCache();
      onUpdatePdfBuffer(newBytes.buffer, `Replaced all ${count} occurrence(s) in PDF`);
      showToast(`Successfully replaced all ${count} occurrence(s)!`);
    } catch (err: any) {
      console.error('Error replacing all occurrences:', err);
      alert(`Replace All failed: ${err.message || 'Unknown error'}`);
    } finally {
      setIsProcessingReplace(false);
    }
  };

  // Undo Last Replace Handler
  const handleUndoLastReplace = async () => {
    if (undoStack.length === 0 || isProcessingReplace) return;
    setIsProcessingReplace(true);

    try {
      const prevBuffer = undoStack[undoStack.length - 1];
      setUndoStack((prev) => prev.slice(0, prev.length - 1));

      clearPdfTextIndexCache();
      onUpdatePdfBuffer(prevBuffer, 'Reverted last replace operation');
      showToast('Undid last replacement!');
    } catch (err: any) {
      console.error('Error undoing replace:', err);
    } finally {
      setIsProcessingReplace(false);
    }
  };

  return (
    <div className="fixed top-20 right-4 sm:right-6 z-40 w-full max-w-sm sm:max-w-md bg-white rounded-2xl shadow-2xl border border-[#E8E8E6] overflow-hidden flex flex-col max-h-[calc(100vh-100px)] animate-in fade-in slide-in-from-top-2 duration-200 font-ibm-sans">
      {/* Panel Header */}
      <div className="px-4 py-3 bg-[#1B2740] text-white flex items-center justify-between border-b border-white/10 shrink-0">
        <div className="flex items-center space-x-2">
          <Search size={18} className="text-[#C4432E]" />
          <h3 className="font-fraunces font-medium text-base tracking-tight text-white">
            Find & Replace
          </h3>
        </div>

        <div className="flex items-center space-x-2">
          {undoStack.length > 0 && (
            <button
              type="button"
              onClick={handleUndoLastReplace}
              disabled={isProcessingReplace}
              className="text-xs text-amber-300 hover:text-amber-200 bg-white/10 hover:bg-white/20 px-2 py-1 rounded-md font-ibm-sans flex items-center space-x-1 transition-all cursor-pointer disabled:opacity-50"
              title="Undo last replacement in memory"
            >
              <RotateCcw size={12} />
              <span>Undo Replace</span>
            </button>
          )}

          <button
            type="button"
            onClick={onClose}
            className="p-1 text-gray-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
            title="Close Find & Replace Panel"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {/* Toast Notification Banner */}
      {notificationMsg && (
        <div className="px-4 py-2.5 bg-emerald-50 border-b border-emerald-200 text-emerald-800 text-xs font-bold flex items-center space-x-2 animate-fade-in shrink-0">
          <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
          <span>{notificationMsg}</span>
        </div>
      )}

      {/* Indexing Indicator */}
      {isBuildingIndex && (
        <div className="p-6 text-center bg-white space-y-2 shrink-0">
          <Loader2 size={20} className="animate-spin text-[#C4432E] mx-auto" />
          <p className="text-xs text-[#6B7280]">
            Indexing document text ({indexProgress.current} / {indexProgress.total} pages)...
          </p>
        </div>
      )}

      {/* Non-Editable / Scanned Document Message Card */}
      {isDocumentWithoutText && (
        <div className="p-6 text-center space-y-4 font-ibm-sans">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 text-amber-800 flex items-center justify-center mx-auto">
            <AlertCircle size={24} className="text-[#1B2740]" />
          </div>
          <div className="space-y-2">
            <h4 className="font-fraunces font-medium text-base text-[#1B2740]">
              Image-Based PDF
            </h4>
            <p className="text-xs text-[#1B2740]/80 leading-relaxed max-w-xs mx-auto">
              This is an image-based PDF, not a real text document, so it isn't editable. Only PDFs with actual printed/typed text can be edited or searched.
            </p>
          </div>
          <div className="pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2 bg-[#1B2740] hover:bg-[#2A3B5C] text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-md active:scale-95"
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {/* Real Text Search & Replace UI (Only shown when document has readable text) */}
      {!isBuildingIndex && !isDocumentWithoutText && (
        <>
          {/* Inputs & Options Area */}
          <div className="p-4 space-y-3 bg-[#F6F6F4] border-b border-[#E8E8E6] shrink-0">
            {/* Find Text Input */}
            <div>
              <label className="text-xs font-bold text-[#1B2740] block mb-1">
                Find:
              </label>
              <div className="relative">
                <Search size={15} className="absolute left-3 top-2.5 text-gray-400" />
                <input
                  ref={searchInputRef}
                  type="text"
                  placeholder="Text to find (e.g. Invoice, Total)..."
                  value={findQuery}
                  onChange={(e) => setFindQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-white border border-[#E8E8E6] rounded-xl text-xs focus:border-[#C4432E] focus:outline-hidden transition-all shadow-2xs"
                />
              </div>
            </div>

            {/* Replace With Text Input */}
            <div>
              <label className="text-xs font-bold text-[#1B2740] block mb-1">
                Replace with:
              </label>
              <div className="relative">
                <Replace size={15} className="absolute left-3 top-2.5 text-[#C4432E]" />
                <input
                  type="text"
                  placeholder="Replacement text (e.g. Receipt, Final)..."
                  value={replaceQuery}
                  onChange={(e) => setReplaceQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-white border border-[#E8E8E6] rounded-xl text-xs focus:border-[#C4432E] focus:outline-hidden transition-all font-medium shadow-2xs text-[#1B2740]"
                />
              </div>
            </div>

            {/* Toggles: Match case & Whole word only */}
            <div className="flex items-center gap-3 pt-0.5">
              <label className="flex items-center space-x-2 text-xs font-medium text-[#1B2740] cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={matchCase}
                  onChange={(e) => setMatchCase(e.target.checked)}
                  className="w-4 h-4 accent-[#C4432E] rounded cursor-pointer"
                />
                <span>Match case</span>
              </label>

              <label className="flex items-center space-x-2 text-xs font-medium text-[#1B2740] cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={wholeWord}
                  onChange={(e) => setWholeWord(e.target.checked)}
                  className="w-4 h-4 accent-[#C4432E] rounded cursor-pointer"
                />
                <span>Whole word only</span>
              </label>
            </div>
          </div>

          {/* Search Results Summary & Controls */}
          {searchResult && (
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {/* Summary & Nav Row */}
              <div className="flex items-center justify-between pb-2 border-b border-[#E8E8E6]">
                <div>
                  <p className="text-xs font-bold text-[#1B2740]">
                    {searchResult.totalMatches > 0
                      ? `${searchResult.totalMatches} match${
                          searchResult.totalMatches === 1 ? '' : 'es'
                        } found across ${searchResult.pageCountWithMatches} page${
                          searchResult.pageCountWithMatches === 1 ? '' : 's'
                        }`
                      : findQuery.trim()
                      ? 'No matches found'
                      : 'Type a word or phrase to start searching'}
                  </p>
                </div>

                {/* Prev / Next Match Controls */}
                {searchResult.totalMatches > 0 && (
                  <div className="flex items-center space-x-1 shrink-0 bg-[#F6F6F4] p-1 rounded-lg border border-[#E8E8E6]">
                    <span className="text-[11px] font-bold text-[#6B7280] px-1 font-ibm-mono">
                      {focusedIndex + 1}/{searchResult.totalMatches}
                    </span>

                    <button
                      type="button"
                      onClick={handlePrevMatch}
                      className="p-1 hover:bg-white text-[#1B2740] rounded transition-colors cursor-pointer"
                      title="Previous Match"
                    >
                      <ChevronUp size={16} />
                    </button>

                    <button
                      type="button"
                      onClick={handleNextMatch}
                      className="p-1 hover:bg-white text-[#1B2740] rounded transition-colors cursor-pointer"
                      title="Next Match"
                    >
                      <ChevronDown size={16} />
                    </button>
                  </div>
                )}
              </div>

              {/* Matches Scrollable List */}
              {searchResult.totalMatches > 0 && (
                <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                  {searchResult.matches.map((match, idx) => {
                    const isFocused = idx === focusedIndex;

                    return (
                      <div
                        key={match.id}
                        onClick={() => handleSelectMatchItem(match, idx)}
                        className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all flex items-center justify-between gap-2 ${
                          isFocused
                            ? 'bg-[#C4432E]/10 border-[#C4432E] ring-1 ring-[#C4432E] shadow-2xs'
                            : 'bg-white border-[#E8E8E6] hover:bg-[#F6F6F4]'
                        }`}
                      >
                        <div className="space-y-1 overflow-hidden flex-1">
                          <div className="flex items-center space-x-2">
                            <span className="font-bold text-[10px] bg-[#1B2740] text-white px-1.5 py-0.5 rounded font-ibm-mono">
                              Page {match.pageNumber}
                            </span>
                            {isFocused && (
                              <span className="text-[10px] font-bold text-[#C4432E] uppercase tracking-wider">
                                Focused
                              </span>
                            )}
                          </div>

                          <p className="text-[11px] text-[#1B2740] font-ibm-mono line-clamp-2 leading-tight">
                            {match.snippet.split(/(\[.*?\])/).map((part, pIdx) => {
                              if (part.startsWith('[') && part.endsWith(']')) {
                                return (
                                  <span
                                    key={pIdx}
                                    className="bg-amber-200 text-amber-900 font-bold px-0.5 rounded"
                                  >
                                    {part.slice(1, -1)}
                                  </span>
                                );
                              }
                              return <span key={pIdx}>{part}</span>;
                            })}
                          </p>
                        </div>

                        {/* Individual Replace Button */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleReplaceSingle(match);
                          }}
                          disabled={isProcessingReplace}
                          className="px-2.5 py-1 bg-white hover:bg-[#1B2740] text-[#1B2740] hover:text-white border border-[#E8E8E6] hover:border-[#1B2740] rounded-lg text-[11px] font-bold transition-all cursor-pointer shrink-0 shadow-2xs disabled:opacity-50"
                        >
                          Replace
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Footer Action Bar: Replace All Button */}
          {searchResult && searchResult.totalMatches > 0 && (
            <div className="p-3 bg-[#F6F6F4] border-t border-[#E8E8E6] shrink-0">
              <button
                type="button"
                onClick={() => setShowReplaceAllConfirm(true)}
                disabled={isProcessingReplace}
                className="w-full py-2.5 bg-[#C4432E] hover:bg-[#a83522] text-white text-xs font-bold rounded-xl transition-all cursor-pointer shadow-md disabled:opacity-50 flex items-center justify-center space-x-2"
              >
                {isProcessingReplace ? (
                  <Loader2 size={16} className="animate-spin" />
                ) : (
                  <Replace size={16} />
                )}
                <span>Replace All ({searchResult.totalMatches})</span>
              </button>
            </div>
          )}
        </>
      )}

      {/* Confirmation Modal for Replace All */}
      {showReplaceAllConfirm && searchResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1B2740]/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl shadow-2xl border border-[#E8E8E6] w-full max-w-sm p-6 space-y-4 text-center">
            <div className="w-12 h-12 rounded-full bg-red-100 text-[#C4432E] flex items-center justify-center mx-auto">
              <AlertTriangle size={24} />
            </div>

            <div>
              <h4 className="font-fraunces text-lg font-medium text-[#1B2740]">
                Replace All Matches?
              </h4>
              <p className="text-xs text-[#6B7280] font-ibm-sans mt-1 leading-relaxed">
                Replace all <strong className="text-[#1B2740]">{searchResult.totalMatches}</strong> match
                {searchResult.totalMatches === 1 ? '' : 'es'} across{' '}
                <strong className="text-[#1B2740]">{searchResult.pageCountWithMatches}</strong> page
                {searchResult.pageCountWithMatches === 1 ? '' : 's'}? This cannot be undone after export.
              </p>
            </div>

            <div className="flex items-center space-x-3 pt-2">
              <button
                type="button"
                onClick={() => setShowReplaceAllConfirm(false)}
                className="flex-1 py-2 bg-[#F6F6F4] hover:bg-[#E8E8E6] text-[#1B2740] text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={handleConfirmReplaceAll}
                className="flex-1 py-2 bg-[#C4432E] hover:bg-[#a83522] text-white text-xs font-bold rounded-xl transition-colors cursor-pointer shadow-md"
              >
                Confirm Replace All
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
