import React, { useState, useRef, useEffect } from 'react';
import { Edit3, Type, RotateCcw, Check, Sparkles } from 'lucide-react';

interface ESignModalContentProps {
  onAddSignature: (imageDataUrl: string) => void;
  onCancel: () => void;
}

const SIGNATURE_FONTS = [
  { name: 'Dancing Script', family: "'Dancing Script', cursive" },
  { name: 'Great Vibes', family: "'Great Vibes', cursive" },
  { name: 'Caveat', family: "'Caveat', cursive" },
  { name: 'Pacifico', family: "'Pacifico', cursive" },
  { name: 'Satisfy', family: "'Satisfy', cursive" },
];

const INK_COLORS = [
  '#000000', // Black Ink
  '#002B66', // Dark Navy Ink
  '#1E40AF', // Royal Blue
  '#C4432E', // Seal Red
  '#059669', // Emerald
];

export const ESignModalContent: React.FC<ESignModalContentProps> = ({ onAddSignature, onCancel }) => {
  const [activeTab, setActiveTab] = useState<'draw' | 'type'>('draw');

  // DRAWING CANVAS STATE
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [penColor, setPenColor] = useState('#000000');
  const [penWidth, setPenWidth] = useState(3);
  const [hasDrawn, setHasDrawn] = useState(false);

  // TYPED TEXT STATE
  const [typedText, setTypedText] = useState('John Doe');
  const [selectedFont, setSelectedFont] = useState(SIGNATURE_FONTS[0].family);
  const [typedColor, setTypedColor] = useState('#002B66');

  // INITIALIZE DRAWING CANVAS
  useEffect(() => {
    if (activeTab === 'draw' && canvasRef.current) {
      clearDrawingCanvas();
    }
  }, [activeTab]);

  const clearDrawingCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw light baseline
    ctx.beginPath();
    ctx.strokeStyle = '#E8E8E6';
    ctx.lineWidth = 1;
    ctx.setLineDash([6, 6]);
    ctx.moveTo(30, canvas.height - 35);
    ctx.lineTo(canvas.width - 30, canvas.height - 35);
    ctx.stroke();
    ctx.setLineDash([]);

    setHasDrawn(false);
  };

  const startDrawing = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (canvas.width / rect.width);
    const y = (e.clientY - rect.top) * (canvas.height / rect.height);

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.strokeStyle = penColor;
    ctx.lineWidth = penWidth;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    setIsDrawing(true);
    setHasDrawn(true);
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const draw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (canvas.width / rect.width);
    const y = (e.clientY - rect.top) * (canvas.height / rect.height);

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (isDrawing) {
      setIsDrawing(false);
      try {
        (e.target as HTMLElement).releasePointerCapture(e.pointerId);
      } catch {}
    }
  };

  // GENERATE PNG DATA URL AND SUBMIT SIGNATURE
  const handleConfirmSignature = () => {
    if (activeTab === 'draw') {
      const canvas = canvasRef.current;
      if (!canvas || !hasDrawn) return;

      // Crop transparent signature area or export directly
      const tempCanvas = document.createElement('canvas');
      tempCanvas.width = canvas.width;
      tempCanvas.height = canvas.height;
      const tCtx = tempCanvas.getContext('2d');
      if (tCtx) {
        tCtx.drawImage(canvas, 0, 0);
      }
      const dataUrl = tempCanvas.toDataURL('image/png');
      onAddSignature(dataUrl);
    } else {
      if (!typedText.trim()) return;

      // Create offscreen canvas for typed font signature
      const offscreen = document.createElement('canvas');
      offscreen.width = 600;
      offscreen.height = 180;
      const ctx = offscreen.getContext('2d');

      if (ctx) {
        ctx.clearRect(0, 0, offscreen.width, offscreen.height);
        ctx.fillStyle = typedColor;
        ctx.font = `70px ${selectedFont}`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(typedText.trim(), offscreen.width / 2, offscreen.height / 2);

        const dataUrl = offscreen.toDataURL('image/png');
        onAddSignature(dataUrl);
      }
    }
  };

  return (
    <div className="space-y-4 text-sm">
      {/* TABS: DRAW vs TYPE TEXT */}
      <div className="flex bg-[#F6F6F4] p-1 rounded-xl border border-[#E8E8E6] text-xs font-semibold">
        <button
          type="button"
          onClick={() => setActiveTab('draw')}
          className={`flex-1 py-2 rounded-lg flex items-center justify-center space-x-2 transition-all cursor-pointer ${
            activeTab === 'draw'
              ? 'bg-white text-[#C4432E] shadow-sm font-bold'
              : 'text-[#6B7280] hover:text-[#1B2740]'
          }`}
        >
          <Edit3 size={15} />
          <span>Draw Signature</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('type')}
          className={`flex-1 py-2 rounded-lg flex items-center justify-center space-x-2 transition-all cursor-pointer ${
            activeTab === 'type'
              ? 'bg-white text-[#C4432E] shadow-sm font-bold'
              : 'text-[#6B7280] hover:text-[#1B2740]'
          }`}
        >
          <Type size={15} />
          <span>Type Text</span>
        </button>
      </div>

      {/* DRAW TAB CONTENT */}
      {activeTab === 'draw' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            {/* Color options */}
            <div className="flex items-center space-x-2">
              <span className="text-xs font-medium text-[#6B7280]">Ink Color:</span>
              {INK_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setPenColor(c)}
                  style={{ backgroundColor: c }}
                  className={`w-5 h-5 rounded-full border border-black/20 transition-transform cursor-pointer ${
                    penColor === c ? 'scale-125 ring-2 ring-[#C4432E] ring-offset-1' : 'hover:scale-110'
                  }`}
                />
              ))}
            </div>

            {/* Clear Button */}
            <button
              type="button"
              onClick={clearDrawingCanvas}
              className="text-xs text-red-600 hover:text-red-800 font-medium flex items-center space-x-1 cursor-pointer bg-red-50 hover:bg-red-100 px-2.5 py-1 rounded-lg border border-red-200"
            >
              <RotateCcw size={12} />
              <span>Clear</span>
            </button>
          </div>

          {/* Interactive HTML5 Canvas */}
          <div className="relative border-2 border-dashed border-[#1B2740]/20 hover:border-[#C4432E] rounded-xl bg-white overflow-hidden shadow-inner">
            <canvas
              ref={canvasRef}
              width={520}
              height={180}
              onPointerDown={startDrawing}
              onPointerMove={draw}
              onPointerUp={stopDrawing}
              className="w-full h-44 touch-none cursor-crosshair block"
            />
            {!hasDrawn && (
              <div className="absolute inset-0 pointer-events-none flex items-center justify-center text-xs text-[#6B7280]/60 italic font-medium">
                Sign inside this box using your mouse or touch
              </div>
            )}
          </div>

          {/* Pen Stroke Width */}
          <div className="flex items-center space-x-3 text-xs text-[#6B7280]">
            <span className="font-medium">Stroke Thickness:</span>
            {[2, 3, 5].map((w) => (
              <button
                key={w}
                type="button"
                onClick={() => setPenWidth(w)}
                className={`px-3 py-1 rounded-md border text-xs font-semibold cursor-pointer transition-colors ${
                  penWidth === w
                    ? 'bg-[#1B2740] text-white border-[#1B2740]'
                    : 'bg-[#F6F6F4] text-[#1B2740] border-[#E8E8E6] hover:border-[#1B2740]'
                }`}
              >
                {w === 2 ? 'Fine' : w === 3 ? 'Medium' : 'Thick'}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* TYPE TAB CONTENT */}
      {activeTab === 'type' && (
        <div className="space-y-4">
          <div className="space-y-1">
            <label className="text-xs font-semibold text-[#1B2740] uppercase font-ibm-mono">
              Your Name or Title
            </label>
            <input
              type="text"
              value={typedText}
              onChange={(e) => setTypedText(e.target.value)}
              placeholder="Enter text to convert into signature"
              className="w-full px-3.5 py-2.5 rounded-lg border border-[#E8E8E6] text-sm font-medium focus:outline-none focus:border-[#C4432E] bg-white"
            />
          </div>

          {/* Font Selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-[#1B2740] uppercase font-ibm-mono">
              Signature Style
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto p-1">
              {SIGNATURE_FONTS.map((font) => (
                <button
                  key={font.name}
                  type="button"
                  onClick={() => setSelectedFont(font.family)}
                  style={{ fontFamily: font.family }}
                  className={`p-2.5 rounded-lg border text-lg text-center truncate transition-all cursor-pointer ${
                    selectedFont === font.family
                      ? 'border-[#C4432E] bg-[#C4432E]/10 text-[#1B2740] font-bold shadow-xs'
                      : 'border-[#E8E8E6] bg-white text-[#1B2740] hover:border-[#C4432E]'
                  }`}
                >
                  {typedText || 'Signature'}
                </button>
              ))}
            </div>
          </div>

          {/* Color theme */}
          <div className="flex items-center space-x-2">
            <span className="text-xs font-medium text-[#6B7280]">Ink Color:</span>
            {INK_COLORS.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setTypedColor(c)}
                style={{ backgroundColor: c }}
                className={`w-5 h-5 rounded-full border border-black/20 transition-transform cursor-pointer ${
                  typedColor === c ? 'scale-125 ring-2 ring-[#C4432E] ring-offset-1' : 'hover:scale-110'
                }`}
              />
            ))}
          </div>

          {/* Live Preview Box */}
          <div className="p-4 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6] flex flex-col items-center justify-center min-h-[90px]">
            <span
              style={{
                fontFamily: selectedFont,
                color: typedColor,
                fontSize: '36px',
                lineHeight: 1.2,
              }}
              className="select-none text-center drop-shadow-xs"
            >
              {typedText || 'Signature'}
            </span>
          </div>
        </div>
      )}

      {/* Action Footer */}
      <div className="pt-3 border-t border-[#E8E8E6] flex items-center justify-between">
        <div className="flex items-center space-x-1 text-xs text-[#6B7280]">
          <Sparkles size={14} className="text-[#C4432E]" />
          <span>Interactive overlay mode</span>
        </div>

        <div className="flex items-center space-x-2">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-xs font-medium text-[#6B7280] hover:text-[#1B2740] rounded-lg cursor-pointer"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleConfirmSignature}
            disabled={activeTab === 'draw' ? !hasDrawn : !typedText.trim()}
            className="px-5 py-2 bg-[#C4432E] hover:bg-[#a83522] text-white rounded-lg text-xs font-bold transition-all shadow-md disabled:opacity-40 cursor-pointer flex items-center space-x-1.5 active:scale-95"
          >
            <Check size={15} />
            <span>Add Signature</span>
          </button>
        </div>
      </div>
    </div>
  );
};
