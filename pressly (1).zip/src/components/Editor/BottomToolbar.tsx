import React, { useRef, useState, useEffect } from 'react';
import { ALL_TOOLS } from '../../data/toolsData';
import { PDFTool } from '../../types';
import {
  Combine,
  Split,
  FileMinus,
  Trash2,
  ArrowUpDown,
  Stamp,
  PenTool,
  FileEdit,
  FileText,
  Minimize2,
  Image as ImageIcon,
  ChevronLeft,
  ChevronRight,
  Hash,
  CopyX,
  FileX,
  Scaling,
  Search,
  Replace,
  Unlock,
} from 'lucide-react';

interface BottomToolbarProps {
  activeTool: PDFTool | null;
  onSelectTool: (tool: PDFTool) => void;
}

const ICON_MAP: Record<string, React.FC<{ size?: number; className?: string }>> = {
  Image: ImageIcon,
  Combine,
  Split,
  FileMinus,
  Trash2,
  ArrowUpDown,
  Stamp,
  PenTool,
  FileEdit,
  Minimize2,
  Hash,
  CopyX,
  FileX,
  Scaling,
  SearchAndReplace: Replace,
  Search,
  Unlock,
};

export const BottomToolbar: React.FC<BottomToolbarProps> = ({ activeTool, onSelectTool }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const checkScroll = () => {
    if (!scrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    setCanScrollLeft(scrollLeft > 4);
    setCanScrollRight(scrollLeft + clientWidth < scrollWidth - 4);
  };

  useEffect(() => {
    checkScroll();
    window.addEventListener('resize', checkScroll);
    return () => window.removeEventListener('resize', checkScroll);
  }, []);

  const handleScroll = (direction: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const scrollAmount = direction === 'left' ? -220 : 220;
    scrollRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-[#E8E8E6] z-30 shadow-xl py-2 px-2 sm:px-4">
      <div className="max-w-6xl mx-auto relative flex items-center">
        {/* Scroll Left Arrow Button */}
        {canScrollLeft && (
          <button
            type="button"
            onClick={() => handleScroll('left')}
            className="absolute left-0 z-10 w-8 h-8 rounded-full bg-white border border-[#E8E8E6] shadow-md text-[#1B2740] flex items-center justify-center hover:bg-[#F6F6F4] hover:text-[#C4432E] transition-all cursor-pointer -ml-2 sm:-ml-4"
            title="Scroll Left"
          >
            <ChevronLeft size={18} />
          </button>
        )}

        {/* Scrollable Tools Container */}
        <div
          ref={scrollRef}
          onScroll={checkScroll}
          className="flex items-center gap-2 sm:gap-3 px-2 py-1 overflow-x-auto no-scrollbar scroll-smooth w-full justify-start md:justify-center"
        >
          {ALL_TOOLS.filter((tool) => tool.category !== 'Convert' && tool.id !== 'image-to-pdf' && tool.id !== 'pdf-to-image').map((tool) => {
            const IconComponent = ICON_MAP[tool.iconName] || FileText;
            const isActive = activeTool?.id === tool.id;

            return (
              <button
                key={tool.id}
                type="button"
                onClick={() => onSelectTool(tool)}
                className={`flex flex-col items-center justify-center min-w-[85px] sm:min-w-[96px] h-15 px-2.5 py-1.5 rounded-xl border text-center transition-all cursor-pointer shrink-0 ${
                  isActive
                    ? 'bg-[#C4432E] border-[#C4432E] text-white red-glow font-semibold shadow-md scale-102'
                    : 'bg-white border-[#E8E8E6] text-[#1B2740] hover:border-[#C4432E] hover:bg-[#F6F6F4] hover:shadow-2xs'
                }`}
                title={tool.description}
              >
                <div className="flex items-center gap-1">
                  <IconComponent
                    size={18}
                    className={`transition-transform ${isActive ? 'text-white' : 'text-[#1B2740]'}`}
                  />
                  {tool.badge && (
                    <span className="text-[9px] px-1 py-0.2 rounded font-bold font-ibm-mono bg-[#C4432E] text-white">
                      {tool.badge}
                    </span>
                  )}
                </div>
                <span
                  className={`text-[11px] leading-tight font-ibm-sans line-clamp-1 whitespace-nowrap mt-1 ${
                    isActive ? 'text-white font-semibold' : 'text-[#1B2740] font-medium'
                  }`}
                >
                  {tool.name}
                </span>
              </button>
            );
          })}
        </div>

        {/* Scroll Right Arrow Button */}
        {canScrollRight && (
          <button
            type="button"
            onClick={() => handleScroll('right')}
            className="absolute right-0 z-10 w-8 h-8 rounded-full bg-white border border-[#E8E8E6] shadow-md text-[#1B2740] flex items-center justify-center hover:bg-[#F6F6F4] hover:text-[#C4432E] transition-all cursor-pointer -mr-2 sm:-mr-4"
            title="Scroll Right"
          >
            <ChevronRight size={18} />
          </button>
        )}
      </div>
    </div>
  );
};

