import React from 'react';
import {
  X,
  Download,
  Share,
  PlusSquare,
  Smartphone,
  Laptop,
  CheckCircle2,
  WifiOff,
  ShieldCheck,
  Zap,
  Sparkles,
} from 'lucide-react';
import { PresslyIcon } from './Logos';

interface PwaInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
  onInstall: () => void;
  hasPrompt: boolean;
  isIOS: boolean;
  isInstalled: boolean;
}

export const PwaInstallModal: React.FC<PwaInstallModalProps> = ({
  isOpen,
  onClose,
  onInstall,
  hasPrompt,
  isIOS,
  isInstalled,
}) => {
  if (!isOpen) return null;

  return (
    <div
      id="pwa-install-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-[#E8E8E6] overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="bg-[#1B2740] p-6 text-white text-center relative">
          <button
            id="close-pwa-modal-btn"
            onClick={onClose}
            className="absolute top-4 right-4 text-gray-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X size={18} />
          </button>

          <div className="w-16 h-16 bg-white/10 rounded-2xl p-2.5 mx-auto mb-3 flex items-center justify-center shadow-inner border border-white/10">
            <PresslyIcon size={44} className="text-white" />
          </div>

          <h3 className="text-xl font-bold font-fraunces tracking-tight text-white">Install Pressly</h3>
          <p className="text-xs text-gray-300 mt-1 max-w-xs mx-auto">
            Add Pressly to your Home Screen for instant offline PDF editing, zero latency & standalone app experience.
          </p>

          <div className="inline-flex items-center gap-1.5 mt-3 px-3 py-1 bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 rounded-full text-[11px] font-bold">
            <WifiOff size={13} />
            <span>100% Offline Client-Side Powered</span>
          </div>
        </div>

        {/* Modal Content */}
        <div className="p-6 overflow-y-auto space-y-5 flex-1">
          {isInstalled ? (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-center space-y-2">
              <CheckCircle2 size={32} className="text-emerald-600 mx-auto" />
              <h4 className="text-sm font-bold text-emerald-900">Pressly is Already Installed!</h4>
              <p className="text-xs text-emerald-700">
                You can launch Pressly anytime directly from your device home screen or applications menu.
              </p>
            </div>
          ) : isIOS ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold text-[#1B2740] uppercase tracking-wider font-ibm-mono">
                <Smartphone size={15} className="text-[#C4432E]" />
                <span>How to Install on iPhone / iPad (Safari)</span>
              </div>

              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6]">
                  <div className="w-7 h-7 rounded-lg bg-white border border-[#E8E8E6] flex items-center justify-center shrink-0 text-[#1B2740] font-bold text-xs shadow-2xs">
                    1
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-[#1B2740] block">Tap the Share Button</span>
                    <span className="text-[#6B7280]">
                      In the bottom toolbar of Safari, tap the{' '}
                      <span className="inline-flex items-center gap-1 font-semibold text-[#1B2740] bg-white px-1.5 py-0.5 rounded border border-[#E8E8E6]">
                        <Share size={12} className="text-blue-500" /> Share
                      </span>{' '}
                      icon.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6]">
                  <div className="w-7 h-7 rounded-lg bg-white border border-[#E8E8E6] flex items-center justify-center shrink-0 text-[#1B2740] font-bold text-xs shadow-2xs">
                    2
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-[#1B2740] block">Select "Add to Home Screen"</span>
                    <span className="text-[#6B7280]">
                      Scroll down through the share options and select{' '}
                      <span className="inline-flex items-center gap-1 font-semibold text-[#1B2740] bg-white px-1.5 py-0.5 rounded border border-[#E8E8E6]">
                        <PlusSquare size={12} className="text-[#1B2740]" /> Add to Home Screen
                      </span>.
                    </span>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6]">
                  <div className="w-7 h-7 rounded-lg bg-white border border-[#E8E8E6] flex items-center justify-center shrink-0 text-[#1B2740] font-bold text-xs shadow-2xs">
                    3
                  </div>
                  <div className="text-xs">
                    <span className="font-semibold text-[#1B2740] block">Tap "Add" in the Top Right</span>
                    <span className="text-[#6B7280]">
                      Confirm the name <span className="font-bold text-[#1B2740]">"Pressly"</span> and tap Add. The Pressly icon will appear on your Home Screen!
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-2 text-xs font-bold text-[#1B2740] uppercase tracking-wider font-ibm-mono">
                <Laptop size={15} className="text-[#C4432E]" />
                <span>Instant Browser Installation</span>
              </div>

              <p className="text-xs text-[#6B7280] leading-relaxed">
                Install Pressly as a dedicated desktop or mobile application. Enjoy full-screen viewing, fast offline launch, and keyboard shortcuts without browser address bars.
              </p>

              <button
                id="modal-install-action-btn"
                type="button"
                onClick={() => {
                  onInstall();
                  onClose();
                }}
                className="w-full py-3 bg-[#C4432E] hover:bg-[#a83623] text-white rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-md transition-all transform hover:-translate-y-0.5 cursor-pointer"
              >
                <Download size={16} />
                <span>Install Pressly App Now</span>
              </button>
            </div>
          )}

          {/* Benefits Grid */}
          <div className="pt-2 border-t border-[#E8E8E6] space-y-2">
            <span className="text-[11px] font-bold text-[#1B2740] uppercase tracking-wider font-ibm-mono block">
              Why Install Pressly?
            </span>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="flex items-start gap-2 p-2 rounded-lg bg-[#F6F6F4] text-[#1B2740]">
                <Zap size={15} className="text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block text-[11px]">Real-Time & Offline</span>
                  <span className="text-[10px] text-[#6B7280]">Works 100% without internet</span>
                </div>
              </div>
              <div className="flex items-start gap-2 p-2 rounded-lg bg-[#F6F6F4] text-[#1B2740]">
                <ShieldCheck size={15} className="text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block text-[11px]">100% Private</span>
                  <span className="text-[10px] text-[#6B7280]">Files never leave device</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-[#F6F6F4] border-t border-[#E8E8E6] flex justify-end">
          <button
            id="close-pwa-guide-btn"
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-[#6B7280] hover:text-[#1B2740] rounded-lg transition-colors cursor-pointer"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};
