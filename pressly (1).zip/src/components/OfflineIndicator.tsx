import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, Download, Check, Sparkles, X } from 'lucide-react';

interface OfflineIndicatorProps {
  isOnline: boolean;
  isInstallable: boolean;
  isInstalled: boolean;
  onInstallClick: () => void;
}

export const OfflineIndicator: React.FC<OfflineIndicatorProps> = ({
  isOnline,
  isInstallable,
  isInstalled,
  onInstallClick,
}) => {
  const [dismissedInstallBanner, setDismissedInstallBanner] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('pressly_install_banner_dismissed') === 'true';
    } catch {
      return false;
    }
  });

  const handleDismissBanner = () => {
    setDismissedInstallBanner(true);
    try {
      sessionStorage.setItem('pressly_install_banner_dismissed', 'true');
    } catch {}
  };

  return (
    <>
      {/* Offline Status Top Alert Strip (Only visible when offline) */}
      {!isOnline && (
        <div
          id="offline-status-banner"
          className="bg-[#1B2740] text-amber-300 text-xs px-4 py-2 border-b border-amber-400/30 flex items-center justify-between shadow-xs transition-all z-50 sticky top-0"
        >
          <div className="flex items-center gap-2 max-w-5xl mx-auto w-full justify-between">
            <div className="flex items-center gap-2">
              <span className="flex h-2.5 w-2.5 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
              </span>
              <WifiOff size={14} className="text-amber-400" />
              <span className="font-semibold text-white">
                You are currently offline.
              </span>
              <span className="text-amber-200/80 hidden sm:inline">
                All Pressly tools, editors, and compression algorithms operate 100% client-side with zero latency.
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="bg-white/10 px-2 py-0.5 rounded text-[10px] font-ibm-mono text-emerald-300 border border-emerald-400/20 font-bold">
                100% Offline Ready
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Floating PWA Install Promotion Pill (Desktop & Mobile when not installed) */}
      {isInstallable && !isInstalled && !dismissedInstallBanner && (
        <div
          id="pwa-floating-install-pill"
          className="fixed bottom-5 right-5 z-40 animate-in slide-in-from-bottom-5 duration-300"
        >
          <div className="bg-[#1B2740] text-white p-3.5 rounded-2xl shadow-xl border border-white/15 flex items-center gap-3.5 max-w-sm backdrop-blur-md">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#C4432E] to-[#8F2C1D] flex items-center justify-center shrink-0 shadow-md">
              <Download size={18} className="text-white" />
            </div>
            <div className="flex-1 min-w-0 pr-1">
              <div className="text-xs font-bold flex items-center gap-1.5 text-white">
                <span>Install Pressly App</span>
                <span className="bg-emerald-500/20 text-emerald-300 text-[9px] px-1.5 py-0.2 rounded font-mono font-semibold">
                  Offline
                </span>
              </div>
              <p className="text-[11px] text-gray-300 truncate mt-0.5">
                Fast desktop & mobile app experience
              </p>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                id="pwa-pill-install-btn"
                type="button"
                onClick={onInstallClick}
                className="bg-[#C4432E] hover:bg-[#a83623] text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-transform active:scale-95 shadow-sm cursor-pointer"
              >
                Install
              </button>
              <button
                id="pwa-pill-dismiss-btn"
                type="button"
                onClick={handleDismissBanner}
                className="text-gray-400 hover:text-white p-1 rounded-md transition-colors cursor-pointer"
                aria-label="Dismiss"
              >
                <X size={15} />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
