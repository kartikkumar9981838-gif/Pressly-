import React from 'react';

export const PresslyIcon: React.FC<{ className?: string; size?: number }> = ({ className = '', size = 40 }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 100 100"
    width={size}
    height={size}
    role="img"
    aria-label="Pressly"
    className={className}
  >
    <circle cx="50" cy="50" r="44" fill="none" stroke="#1B2740" strokeWidth="4" />
    <path d="M76,17 L78,23 L84,25 L78,27 L76,33 L74,27 L68,25 L74,23 Z" fill="#1B2740" />
    <rect x="26" y="30" width="48" height="11" rx="5.5" fill="#1B2740" />
    <polyline points="30,49 50,57 70,49" fill="none" stroke="#1B2740" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    <polyline points="30,57 50,65 70,57" fill="none" stroke="#1B2740" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M34,64 Q50,76 66,64" fill="none" stroke="#C4432E" strokeWidth="4" strokeLinecap="round" />
  </svg>
);

export const PresslyFullLockup: React.FC<{ className?: string; height?: number }> = ({ className = '', height = 36 }) => {
  // calculate aspect ratio 420/100
  const width = Math.round(height * 4.2);
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 420 100"
      width={width}
      height={height}
      role="img"
      aria-label="Pressly"
      className={className}
    >
      <g>
        <circle cx="50" cy="50" r="44" fill="none" stroke="#1B2740" strokeWidth="4" />
        <path d="M76,17 L78,23 L84,25 L78,27 L76,33 L74,27 L68,25 L74,23 Z" fill="#1B2740" />
        <rect x="26" y="30" width="48" height="11" rx="5.5" fill="#1B2740" />
        <polyline points="30,49 50,57 70,49" fill="none" stroke="#1B2740" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        <polyline points="30,57 50,65 70,57" fill="none" stroke="#1B2740" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M34,64 Q50,76 66,64" fill="none" stroke="#C4432E" strokeWidth="4" strokeLinecap="round" />
      </g>
      <text x="118" y="68" fontFamily="'Fraunces', Georgia, serif" fontSize="52" fontWeight="500" fill="#1B2740">
        pressly
      </text>
    </svg>
  );
};
