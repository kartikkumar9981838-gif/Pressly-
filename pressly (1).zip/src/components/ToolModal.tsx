import React, { useState, useEffect } from 'react';
import { PDFTool, WatermarkDraft, SignatureDraft, ImageDraft } from '../types';
import { ESignModalContent } from './Editor/ESignModalContent';
import { ImageCropModal } from './Editor/ImageCropModal';
import {
  mergePdfs,
  splitPdf,
  extractPages,
  extractPagesToSeparateFiles,
  parsePageRanges,
  formatPagesToRangeString,
  ParsedPageRangesResult,
  deletePages,
  reorderPages,
  computeReorderIndices,
  compressPdf,
  compressToTargetSize,
  CompressTargetResult,
  CompressIterationProgress,
  formatFileSize,
  convertImagesToPdf,
  addPageNumbersToPdf,
  detectDuplicatePages,
  DuplicateDetectionResult,
  DuplicateGroup,
  detectBlankPages,
  BlankDetectionResult,
  BlankPageInfo,
  normalizePageSizes,
  getDocumentPageSizes,
  STANDARD_PAGE_SIZES,
  DocumentPageSizeSummary,
  SplitResult,
  downloadPdfBytes,
  detectImageType,
  addImageToPdf,
  removePasswordFromPdf,
  isPdfEncrypted,
  unlockAndDecryptPdf,
} from '../lib/pdfEngine';
import {
  X,
  AlertCircle,
  Upload,
  Trash2,
  Combine,
  Split as SplitIcon,
  FileMinus,
  ArrowUpDown,
  Stamp,
  PenTool,
  FileText,
  Type,
  Sun,
  RotateCw,
  Palette,
  Maximize2,
  Layers,
  Sparkles,
  Minimize2,
  Sliders,
  Image as ImageIcon,
  ArrowUp,
  ArrowDown,
  FileCheck,
  Hash,
  CopyX,
  FileX,
  Scaling,
  CheckCircle2,
  Scan,
  ShieldCheck,
  RefreshCcw,
  CheckSquare,
  Square,
  AlertTriangle,
  Check,
  FileEdit,
  Replace,
  Crop,
  ListFilter,
  LayoutGrid,
  Download,
  CheckCheck,
  BookOpen,
  Target,
  Gauge,
  Loader2,
  Unlock,
  Lock,
  Eye,
  EyeOff,
} from 'lucide-react';

interface ToolModalProps {
  tool: PDFTool;
  isOpen: boolean;
  onClose: () => void;
  pdfBuffer: ArrayBuffer | null;
  pdfFileName: string;
  activePage: number;
  pageCount: number;
  pageSequence?: number[];
  thumbnails?: string[];
  setActivePage?: (p: number) => void;
  onUpdatePdfBuffer: (
    newBuffer: ArrayBuffer,
    message: string,
    newFileName?: string,
    newSequence?: number[]
  ) => void;
  onLaunchWatermarkDraft?: (draft: WatermarkDraft) => void;
  onLaunchSignatureDraft?: (draft: SignatureDraft) => void;
  onLaunchImageDraft?: (draft: ImageDraft) => void;
  onLaunchEditTextMode?: () => void;
  onLaunchFindReplaceMode?: () => void;
}

const PRESET_COLORS = [
  '#C4432E',
  '#1B2740',
  '#2563EB',
  '#059669',
  '#D97706',
  '#7C3AED',
  '#6B7280',
  '#000000',
];

export const ToolModal: React.FC<ToolModalProps> = ({
  tool,
  isOpen,
  onClose,
  pdfBuffer,
  pdfFileName,
  activePage,
  pageCount,
  pageSequence,
  thumbnails = [],
  setActivePage,
  onUpdatePdfBuffer,
  onLaunchWatermarkDraft,
  onLaunchSignatureDraft,
  onLaunchImageDraft,
  onLaunchEditTextMode,
  onLaunchFindReplaceMode,
}) => {
  const [processing, setProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // 1. MERGE STATE
  const [extraFiles, setExtraFiles] = useState<{ name: string; buffer: ArrayBuffer }[]>([]);

  // 2. SPLIT STATE
  const [splitMode, setSplitMode] = useState<'every_n' | 'range'>('every_n');
  const [splitParam, setSplitParam] = useState<string>('1');

  // 3. EXTRACT PAGES STATE
  const [extractMode, setExtractMode] = useState<'range' | 'visual'>('range');
  const [extractRangeInput, setExtractRangeInput] = useState<string>('1');
  const [extractSelectedPages, setExtractSelectedPages] = useState<number[]>([1]);
  const [extractOutputFormat, setExtractOutputFormat] = useState<'merged' | 'separate'>('merged');
  const [extractActionTarget, setExtractActionTarget] = useState<'editor' | 'download'>('editor');

  // DELETE PAGES STATE
  const [deletePagesInput, setDeletePagesInput] = useState<string>('1');
  const [deleteSelectedPages, setDeleteSelectedPages] = useState<number[]>([1]);
  const [pagesInput, setPagesInput] = useState<string>('');

  const handleExtractRangeChange = (text: string) => {
    setExtractRangeInput(text);
    const parsed = parsePageRanges(text, pageCount);
    setExtractSelectedPages(parsed.uniquePages);
  };

  const handleToggleExtractPage = (pageNum: number) => {
    let next: number[];
    if (extractSelectedPages.includes(pageNum)) {
      next = extractSelectedPages.filter((p) => p !== pageNum);
    } else {
      next = [...extractSelectedPages, pageNum].sort((a, b) => a - b);
    }
    setExtractSelectedPages(next);
    setExtractRangeInput(formatPagesToRangeString(next));
  };

  const handleApplyExtractPreset = (
    preset: 'all' | 'odd' | 'even' | 'first-half' | 'second-half' | 'current' | 'clear'
  ) => {
    let pages: number[] = [];
    const half = Math.ceil(pageCount / 2);
    if (preset === 'all') {
      pages = Array.from({ length: pageCount }, (_, i) => i + 1);
    } else if (preset === 'odd') {
      pages = Array.from({ length: pageCount }, (_, i) => i + 1).filter((p) => p % 2 !== 0);
    } else if (preset === 'even') {
      pages = Array.from({ length: pageCount }, (_, i) => i + 1).filter((p) => p % 2 === 0);
    } else if (preset === 'first-half') {
      pages = Array.from({ length: half }, (_, i) => i + 1);
    } else if (preset === 'second-half') {
      pages = Array.from({ length: Math.max(0, pageCount - half) }, (_, i) => half + 1 + i);
    } else if (preset === 'current') {
      pages = [activePage || 1];
    } else if (preset === 'clear') {
      pages = [];
    }
    setExtractSelectedPages(pages);
    setExtractRangeInput(formatPagesToRangeString(pages));
  };

  const handleDeleteRangeChange = (text: string) => {
    setDeletePagesInput(text);
    const parsed = parsePageRanges(text, pageCount);
    setDeleteSelectedPages(parsed.uniquePages);
  };

  const handleToggleDeletePage = (pageNum: number) => {
    let next: number[];
    if (deleteSelectedPages.includes(pageNum)) {
      next = deleteSelectedPages.filter((p) => p !== pageNum);
    } else {
      next = [...deleteSelectedPages, pageNum].sort((a, b) => a - b);
    }
    setDeleteSelectedPages(next);
    setDeletePagesInput(formatPagesToRangeString(next));
  };

  const handleApplyDeletePreset = (
    preset: 'all-except-first' | 'odd' | 'even' | 'current' | 'clear'
  ) => {
    let pages: number[] = [];
    if (preset === 'all-except-first') {
      pages = Array.from({ length: Math.max(0, pageCount - 1) }, (_, i) => i + 2);
    } else if (preset === 'odd') {
      pages = Array.from({ length: pageCount }, (_, i) => i + 1).filter((p) => p % 2 !== 0);
    } else if (preset === 'even') {
      pages = Array.from({ length: pageCount }, (_, i) => i + 1).filter((p) => p % 2 === 0);
    } else if (preset === 'current') {
      pages = [activePage || 1];
    } else if (preset === 'clear') {
      pages = [];
    }
    setDeleteSelectedPages(pages);
    setDeletePagesInput(formatPagesToRangeString(pages));
  };

  // 4. REORDER STATE
  const [reorderInput, setReorderInput] = useState<string>('');

  // 5. WATERMARK STATE
  const [wmMode, setWmMode] = useState<'text' | 'image'>('text');
  const [wmText, setWmText] = useState<string>('CONFIDENTIAL');
  const [wmFontSize, setWmFontSize] = useState<number>(42);
  const [wmColor, setWmColor] = useState<string>('#C4432E');
  const [wmOpacity, setWmOpacity] = useState<number>(0.3);
  const [wmRotation, setWmRotation] = useState<number>(45);
  const [wmScope, setWmScope] = useState<'all' | 'current'>('all');
  const [wmImageData, setWmImageData] = useState<{
    file?: File;
    dataUrl: string;
    buffer: ArrayBuffer;
    format: 'jpg' | 'png';
    width: number;
    height: number;
    aspectRatio: number;
    name: string;
  } | null>(null);
  const [wmImageWidthRatio, setWmImageWidthRatio] = useState<number>(0.45);
  const [isWmImageCropOpen, setIsWmImageCropOpen] = useState<boolean>(false);

  const handleSelectWmImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (JPG, PNG, or WebP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const buffer = e.target?.result as ArrayBuffer;
      if (!buffer) return;
      const detected = detectImageType(buffer, file.type) || 'png';
      const dataUrlReader = new FileReader();
      dataUrlReader.onload = (ev) => {
        const dataUrl = ev.target?.result as string;
        const img = new Image();
        img.onload = () => {
          setWmImageData({
            file,
            dataUrl,
            buffer,
            format: detected,
            width: img.naturalWidth || img.width,
            height: img.naturalHeight || img.height,
            aspectRatio: (img.naturalWidth || img.width) / (img.naturalHeight || img.height || 1),
            name: file.name,
          });
        };
        img.src = dataUrl;
      };
      dataUrlReader.readAsDataURL(file);
    };
    reader.readAsArrayBuffer(file);
  };

  const handleSelectPresetStamp = (stamp: { label: string; color: string; sub: string }) => {
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 240;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, 600, 240);
    ctx.strokeStyle = stamp.color;
    ctx.lineWidth = 10;
    ctx.strokeRect(20, 20, 560, 200);
    ctx.lineWidth = 3;
    ctx.strokeRect(32, 32, 536, 176);
    ctx.fillStyle = stamp.color;
    ctx.font = 'bold 56px Helvetica, Arial, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(stamp.label.toUpperCase(), 300, 105);
    ctx.font = 'bold 20px Helvetica, Arial, sans-serif';
    ctx.fillText(stamp.sub.toUpperCase(), 300, 162);
    const dataUrl = canvas.toDataURL('image/png');
    const base64 = dataUrl.split(',')[1];
    const binaryString = window.atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    setWmImageData({
      dataUrl,
      buffer: bytes.buffer,
      format: 'png',
      width: 600,
      height: 240,
      aspectRatio: 2.5,
      name: `${stamp.label.toLowerCase()}_stamp.png`,
    });
  };

  // 6. COMPRESS STATE
  const [compressMode, setCompressMode] = useState<'target' | 'normal'>('target');
  const [compressRatio, setCompressRatio] = useState<number>(50);
  const [compressTargetValue, setCompressTargetValue] = useState<string>('5');
  const [compressTargetUnit, setCompressTargetUnit] = useState<'MB' | 'KB'>('MB');
  const [compressProgress, setCompressProgress] = useState<CompressIterationProgress | null>(null);
  const [compressTargetResult, setCompressTargetResult] = useState<CompressTargetResult | null>(null);
  const [compressResult, setCompressResult] = useState<{
    originalSize: number;
    compressedSize: number;
    reductionPercentage: number;
  } | null>(null);
  const compressCancelRef = React.useRef<boolean>(false);

  // 7. IMAGE TO PDF STATE
  const [imgFiles, setImgFiles] = useState<{ id: string; name: string; dataUrl: string; sizeStr: string }[]>([]);
  const [imgPageSize, setImgPageSize] = useState<'a4' | 'letter' | 'fit'>('a4');
  const [imgOrientation, setImgOrientation] = useState<'auto' | 'portrait' | 'landscape'>('auto');
  const [imgMargin, setImgMargin] = useState<'none' | 'small' | 'medium' | 'large'>('small');

  // 8. PAGE NUMBERS STATE
  const [pnPosition, setPnPosition] = useState<'bottom-center' | 'bottom-right' | 'bottom-left' | 'top-center' | 'top-right' | 'top-left'>('bottom-center');
  const [pnFormat, setPnFormat] = useState<'page_x_of_n' | 'x_slash_n' | 'just_x' | 'dash_x_dash'>('page_x_of_n');
  const [pnFontSize, setPnFontSize] = useState<number>(10);
  const [pnColor, setPnColor] = useState<string>('#1B2740');
  const [pnStartPage, setPnStartPage] = useState<number>(1);
  const [pnSkipFirstPage, setPnSkipFirstPage] = useState<boolean>(false);
  const [pnMargin, setPnMargin] = useState<number>(25);

  // 9. DUPLICATE DETECTOR STATE
  const [dupScanning, setDupScanning] = useState<boolean>(false);
  const [dupScanProgress, setDupScanProgress] = useState<{ current: number; total: number } | null>(null);
  const [dupResult, setDupResult] = useState<DuplicateDetectionResult | null>(null);
  const [dupSelectedToRemove, setDupSelectedToRemove] = useState<Set<number>>(new Set());

  const startDuplicateScan = async () => {
    if (!pdfBuffer) return;
    setDupScanning(true);
    setDupResult(null);
    setDupScanProgress({ current: 0, total: pageCount });
    try {
      const res = await detectDuplicatePages(pdfBuffer, (curr, tot) => {
        setDupScanProgress({ current: curr, total: tot });
      });
      setDupResult(res);
      setDupSelectedToRemove(new Set(res.duplicatePageNumbers));
    } catch (err: any) {
      console.error('Duplicate scan error:', err);
      setErrorMsg('Failed to scan document for duplicate pages.');
    } finally {
      setDupScanning(false);
    }
  };

  // 10. BLANK PAGES DETECTOR STATE
  const [blankScanning, setBlankScanning] = useState<boolean>(false);
  const [blankScanProgress, setBlankScanProgress] = useState<{ current: number; total: number } | null>(null);
  const [blankResult, setBlankResult] = useState<BlankDetectionResult | null>(null);
  const [blankSensitivity, setBlankSensitivity] = useState<'strict' | 'standard' | 'aggressive'>('standard');
  const [blankSelectedToRemove, setBlankSelectedToRemove] = useState<Set<number>>(new Set());

  const startBlankScan = async (sens = blankSensitivity) => {
    if (!pdfBuffer) return;
    setBlankScanning(true);
    setBlankResult(null);
    setBlankScanProgress({ current: 0, total: pageCount });
    try {
      const res = await detectBlankPages(pdfBuffer, { sensitivity: sens }, (curr, tot) => {
        setBlankScanProgress({ current: curr, total: tot });
      });
      setBlankResult(res);
      setBlankSelectedToRemove(new Set(res.blankPageNumbers));
    } catch (err: any) {
      console.error('Blank page scan error:', err);
      setErrorMsg('Failed to scan document for blank pages.');
    } finally {
      setBlankScanning(false);
    }
  };

  // 11. PAGE SIZE NORMALIZER STATE
  const [psPreset, setPsPreset] = useState<'A4' | 'LETTER' | 'LEGAL' | 'A3' | 'A5' | 'TABLOID' | 'EXECUTIVE' | 'MATCH_PAGE_1' | 'CUSTOM'>('A4');
  const [psCustomWidthPt, setPsCustomWidthPt] = useState<number>(595.28);
  const [psCustomHeightPt, setPsCustomHeightPt] = useState<number>(841.89);
  const [psOrientation, setPsOrientation] = useState<'portrait' | 'landscape' | 'auto'>('auto');
  const [psScaleMode, setPsScaleMode] = useState<'fit' | 'fill' | 'stretch'>('fit');
  const [psSummary, setPsSummary] = useState<DocumentPageSizeSummary | null>(null);

  // 12. ADD IMAGE TOOL STATE
  const [addImageData, setAddImageData] = useState<{
    file: File;
    dataUrl: string;
    buffer: ArrayBuffer;
    format: 'jpg' | 'png';
    width: number;
    height: number;
    aspectRatio: number;
  } | null>(null);
  const [addImagePage, setAddImagePage] = useState<number>(activePage || 1);
  const [addImageOpacity, setAddImageOpacity] = useState<number>(1.0);
  const [addImageRotation, setAddImageRotation] = useState<number>(0);
  const [addImageWidthRatio, setAddImageWidthRatio] = useState<number>(0.35);
  const [isAddImageCropOpen, setIsAddImageCropOpen] = useState<boolean>(false);

  const handleSelectAddImageFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (JPG or PNG).');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const buffer = e.target?.result as ArrayBuffer;
      if (!buffer) return;

      const detected = detectImageType(buffer, file.type) || 'png';
      const dataUrlReader = new FileReader();
      dataUrlReader.onload = (ev) => {
        const dataUrl = ev.target?.result as string;
        const img = new Image();
        img.onload = () => {
          setAddImageData({
            file,
            dataUrl,
            buffer,
            format: detected,
            width: img.naturalWidth || 400,
            height: img.naturalHeight || 300,
            aspectRatio: (img.naturalWidth || 400) / (img.naturalHeight || 300),
          });
        };
        img.src = dataUrl;
      };
      dataUrlReader.readAsDataURL(file);
    };
    reader.readAsArrayBuffer(file);
  };

  // REMOVE PASSWORD STATE
  const [removePwPassword, setRemovePwPassword] = useState<string>('');
  const [showRemovePwPassword, setShowRemovePwPassword] = useState<boolean>(false);
  const [isDocEncryptedState, setIsDocEncryptedState] = useState<boolean | null>(null);
  const [removePwChecking, setRemovePwChecking] = useState<boolean>(false);

  const loadPageSizeSummary = async () => {
    if (!pdfBuffer) return;
    try {
      const summary = await getDocumentPageSizes(pdfBuffer);
      setPsSummary(summary);
    } catch (err) {
      console.error('Page size summary error:', err);
    }
  };

  // RESET FORM STATE ON OPEN
  useEffect(() => {
    if (isOpen) {
      setErrorMsg(null);
      setProcessing(false);
      setExtraFiles([]);
      setSplitMode('every_n');
      setSplitParam('1');
      setCompressResult(null);
      setPnPosition('bottom-center');
      setPnFormat('page_x_of_n');
      setPnFontSize(10);
      setPnColor('#1B2740');
      setPnStartPage(1);
      setPnSkipFirstPage(false);
      setPnMargin(25);
      setDupResult(null);
      setDupSelectedToRemove(new Set());
      setBlankResult(null);
      setBlankSelectedToRemove(new Set());
      setPsPreset('A4');
      setPsCustomWidthPt(595.28);
      setPsCustomHeightPt(841.89);
      setPsOrientation('auto');
      setPsScaleMode('fit');
      setPsSummary(null);
      setAddImageData(null);
      setAddImagePage(activePage || 1);
      setAddImageOpacity(1.0);
      setAddImageRotation(0);
      setAddImageWidthRatio(0.35);
      setRemovePwPassword('');
      setShowRemovePwPassword(false);
      setIsDocEncryptedState(null);
      if (tool.id === 'remove-password' && pdfBuffer) {
        setRemovePwChecking(true);
        isPdfEncrypted(pdfBuffer)
          .then((enc) => {
            setIsDocEncryptedState(enc);
            setRemovePwChecking(false);
          })
          .catch(() => {
            setIsDocEncryptedState(false);
            setRemovePwChecking(false);
          });
      }
      if (tool.id === 'duplicate-detector') {
        startDuplicateScan();
      }
      if (tool.id === 'blank-detector') {
        startBlankScan('standard');
      }
      if (tool.id === 'page-size-normalizer') {
        loadPageSizeSummary();
      }
      if (tool.id === 'extract-pages') {
        const initPage = activePage || 1;
        setExtractRangeInput(`${initPage}`);
        setExtractSelectedPages([initPage]);
        setExtractMode('range');
        setExtractOutputFormat('merged');
        setExtractActionTarget('editor');
      } else if (tool.id === 'delete-pages') {
        const initPage = activePage || 1;
        setDeletePagesInput(`${initPage}`);
        setDeleteSelectedPages([initPage]);
      } else if (tool.id === 'reorder') {
        const defaultSeq =
          pageSequence && pageSequence.length === pageCount
            ? pageSequence
            : Array.from({ length: pageCount }, (_, i) => i + 1);
        setReorderInput(defaultSeq.join(', '));
      } else {
        setPagesInput('');
      }
    }
  }, [isOpen, tool, activePage, pageCount, pageSequence]);

  if (!isOpen) return null;

  const handleImageFilesUpload = (files: FileList | File[]) => {
    const arr = Array.from(files);
    arr.forEach((file) => {
      if (!file.type.startsWith('image/')) return;
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        if (dataUrl) {
          const sz = file.size >= 1024 * 1024 ? `${(file.size / (1024 * 1024)).toFixed(1)} MB` : `${Math.round(file.size / 1024)} KB`;
          setImgFiles((prev) => [
            ...prev,
            { id: `img-${Date.now()}-${Math.random()}`, name: file.name, dataUrl, sizeStr: sz },
          ]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  // MAIN APPLY HANDLER
  const handleApplyAction = async () => {
    if (!pdfBuffer && tool.id !== 'image-to-pdf') {
      setErrorMsg('No PDF file currently loaded.');
      return;
    }

    if (tool.id === 'watermark') {
      if (wmMode === 'image') {
        if (!wmImageData) {
          setErrorMsg('Please upload an image or choose a preset stamp watermark first.');
          return;
        }
        if (onLaunchWatermarkDraft) {
          onLaunchWatermarkDraft({
            type: 'image',
            text: '',
            fontSize: wmFontSize,
            color: wmColor,
            opacity: wmOpacity,
            rotation: wmRotation,
            xRatio: 0.5,
            yRatio: 0.5,
            scope: wmScope,
            imageDataUrl: wmImageData.dataUrl,
            imageBytes: wmImageData.buffer,
            imageFormat: wmImageData.format,
            naturalWidth: wmImageData.width,
            naturalHeight: wmImageData.height,
            aspectRatio: wmImageData.aspectRatio,
            imageFileName: wmImageData.name,
            imageWidthRatio: wmImageWidthRatio,
          });
        }
      } else {
        if (onLaunchWatermarkDraft) {
          onLaunchWatermarkDraft({
            type: 'text',
            text: wmText.trim() || 'WATERMARK',
            fontSize: wmFontSize,
            color: wmColor,
            opacity: wmOpacity,
            rotation: wmRotation,
            xRatio: 0.5,
            yRatio: 0.5,
            scope: wmScope,
          });
        }
      }
      onClose();
      return;
    }

    if (tool.id === 'add-image') {
      if (!addImageData) {
        setErrorMsg('Please select an image file (JPG or PNG) to insert.');
        return;
      }
      if (onLaunchImageDraft) {
        onLaunchImageDraft({
          imageBytes: addImageData.buffer,
          imageFormat: addImageData.format,
          imageDataUrl: addImageData.dataUrl,
          fileName: addImageData.file.name,
          naturalWidth: addImageData.width,
          naturalHeight: addImageData.height,
          aspectRatio: addImageData.aspectRatio,
          originalImageBytes: addImageData.buffer,
          originalImageDataUrl: addImageData.dataUrl,
          originalWidth: addImageData.width,
          originalHeight: addImageData.height,
          isCropped: false,
          pageNumber: addImagePage,
          xRatio: 0.5,
          yRatio: 0.5,
          widthRatio: addImageWidthRatio,
          rotation: addImageRotation,
          opacity: addImageOpacity,
        });
      }
      onClose();
      return;
    }

    setProcessing(true);
    setErrorMsg(null);

    try {
      let newBytes: Uint8Array | null = null;
      let successMsg = `Applied ${tool.name} successfully.`;
      let updatedSequence: number[] | undefined = undefined;

      switch (tool.id) {
        case 'image-to-pdf': {
          if (imgFiles.length === 0) {
            throw new Error('Please select or upload at least one image file (JPG, PNG, WebP) to convert to PDF.');
          }
          const urls = imgFiles.map((f) => f.dataUrl);
          newBytes = await convertImagesToPdf(urls, {
            pageSize: imgPageSize,
            orientation: imgOrientation,
            margin: imgMargin,
          });
          successMsg = `Successfully converted ${imgFiles.length} image(s) into a clean, professional PDF!`;
          break;
        }
        case 'merge': {
          if (extraFiles.length === 0) {
            throw new Error('Please upload at least one additional PDF file to merge.');
          }
          const allBuffers = [pdfBuffer, ...extraFiles.map((f) => f.buffer)];
          newBytes = await mergePdfs(allBuffers);
          successMsg = `Merged ${allBuffers.length} PDF files into a single document!`;
          break;
        }

        case 'split': {
          const splitResults = await splitPdf(pdfBuffer, splitMode, splitParam);
          if (splitResults.length === 0) {
            throw new Error('Split operation produced no output files.');
          }
          splitResults.forEach((res: SplitResult) => {
            downloadPdfBytes(res.bytes, res.filename);
          });
          successMsg = `Split document into ${splitResults.length} separate PDF files (download triggered)!`;
          newBytes = splitResults[0].bytes;
          break;
        }

        case 'extract-pages': {
          const parsed = parsePageRanges(extractRangeInput, pageCount);
          if (!parsed.isValid || parsed.uniquePages.length === 0) {
            throw new Error(
              parsed.errorMessage || 'Please specify valid page numbers or ranges to extract (e.g. 1-5, 8, 12-17, 25).'
            );
          }
          const pagesToExtract = parsed.uniquePages;
          const cleanBaseName = (pdfFileName || 'document').replace(/\.pdf$/i, '');
          const rangeSummary = formatPagesToRangeString(pagesToExtract);

          if (extractOutputFormat === 'separate') {
            const separateFiles = await extractPagesToSeparateFiles(
              pdfBuffer,
              pagesToExtract,
              pdfFileName || 'document.pdf'
            );
            if (separateFiles.length === 0) {
              throw new Error('Extraction failed to produce files.');
            }
            separateFiles.forEach((f) => {
              downloadPdfBytes(f.bytes, f.filename);
            });
            successMsg = `Extracted ${separateFiles.length} pages as separate PDF files (download triggered)!`;
            newBytes = separateFiles[0].bytes;
            if (extractActionTarget === 'download') {
              onClose();
              return;
            }
          } else {
            newBytes = await extractPages(pdfBuffer, pagesToExtract);
            const outFileName = `${cleanBaseName}_extracted_pages_${rangeSummary.replace(/[^a-zA-Z0-9_-]/g, '_')}.pdf`;

            if (extractActionTarget === 'download') {
              downloadPdfBytes(newBytes, outFileName);
              successMsg = `Downloaded extracted pages (${rangeSummary}) as a new PDF file!`;
              onClose();
              return;
            } else {
              successMsg = `Extracted ${pagesToExtract.length} pages (${rangeSummary}) into editor workspace!`;
              const curSeq =
                pageSequence && pageSequence.length === pageCount
                  ? pageSequence
                  : Array.from({ length: pageCount }, (_, i) => i + 1);
              updatedSequence = pagesToExtract.map((p) => curSeq[p - 1]).filter((n) => n !== undefined);
            }
          }
          break;
        }

        case 'delete-pages': {
          if (pageCount <= 1) {
            throw new Error('Cannot delete pages from a 1-page document. At least one page must remain.');
          }
          const parsed = parsePageRanges(deletePagesInput, pageCount);
          if (!parsed.isValid || parsed.uniquePages.length === 0) {
            throw new Error(
              parsed.errorMessage || 'Please specify valid page numbers or ranges to delete (e.g. 1-3, 5, 8).'
            );
          }
          const pagesToDelete = parsed.uniquePages;
          if (pagesToDelete.length >= pageCount) {
            throw new Error('Cannot delete all pages from document. At least one page must remain in the PDF.');
          }
          newBytes = await deletePages(pdfBuffer, pagesToDelete);
          const rangeSummary = formatPagesToRangeString(pagesToDelete);
          successMsg = `Deleted page(s) (${rangeSummary}) from document!`;
          const curSeq =
            pageSequence && pageSequence.length === pageCount
              ? pageSequence
              : Array.from({ length: pageCount }, (_, i) => i + 1);
          const deleteSet = new Set(pagesToDelete);
          updatedSequence = curSeq.filter((_, idx) => !deleteSet.has(idx + 1));
          break;
        }

        case 'reorder': {
          const nums = reorderInput
            .split(',')
            .map((s) => parseInt(s.trim(), 10))
            .filter((n) => !isNaN(n));
          if (nums.length === 0) throw new Error('Please enter new page order numbers (e.g. 2, 1, 3).');
          const { indices, newSequence } = computeReorderIndices(nums, pageSequence || [], pageCount);
          newBytes = await reorderPages(pdfBuffer, indices);
          updatedSequence = newSequence;
          successMsg = `Reordered document pages!`;
          break;
        }

        case 'compress': {
          compressCancelRef.current = false;
          if (compressMode === 'target') {
            const numericVal = parseFloat(compressTargetValue);
            if (isNaN(numericVal) || numericVal <= 0) {
              throw new Error('Please enter a valid target file size greater than 0.');
            }
            const targetBytes = numericVal * (compressTargetUnit === 'MB' ? 1024 * 1024 : 1024);

            setCompressProgress({
              iteration: 1,
              totalIterations: 5,
              percent: 5,
              stage: 'Starting intelligent target size analysis...',
              targetSize: targetBytes,
            });

            try {
              const res = await compressToTargetSize(pdfBuffer, targetBytes, {
                onProgress: (p) => setCompressProgress(p),
                isCancelled: () => compressCancelRef.current,
              });

              newBytes = res.bytes;
              setCompressTargetResult(res);
              const origStr = formatFileSize(res.originalSize);
              const finalStr = formatFileSize(res.finalSize);
              const targetStr = formatFileSize(res.targetSize);

              if (res.targetAchieved) {
                successMsg = `Target size achieved! Compressed from ${origStr} to ${finalStr} (≤ ${targetStr}) with ${res.reductionPercentage}% size reduction.`;
              } else {
                successMsg = `Compressed to ${finalStr} (${res.reductionPercentage}% reduction). ${res.statusMessage}`;
              }
            } catch (err: any) {
              if (err.message === 'COMPRESSION_CANCELLED' || compressCancelRef.current) {
                successMsg = 'Compression cancelled.';
                setProcessing(false);
                setCompressProgress(null);
                return;
              }
              throw err;
            } finally {
              setCompressProgress(null);
            }
          } else {
            const res = await compressPdf(pdfBuffer, compressRatio);
            newBytes = res.bytes;
            setCompressResult({
              originalSize: res.originalSize,
              compressedSize: res.compressedSize,
              reductionPercentage: res.reductionPercentage,
            });
            const origStr = formatFileSize(res.originalSize);
            const compStr = formatFileSize(res.compressedSize);
            successMsg = `Successfully compressed PDF from ${origStr} to ${compStr} (${res.reductionPercentage}% size reduction) and updated live preview!`;
          }
          break;
        }

        case 'page-numbers': {
          newBytes = await addPageNumbersToPdf(pdfBuffer, {
            position: pnPosition,
            format: pnFormat,
            fontSize: pnFontSize,
            color: pnColor,
            startPage: pnStartPage,
            skipFirstPage: pnSkipFirstPage,
            marginPt: pnMargin,
          });
          successMsg = `Successfully inserted page numbers across all ${pageCount} page(s) of document!`;
          break;
        }

        case 'duplicate-detector': {
          if (dupSelectedToRemove.size === 0) {
            throw new Error('No duplicate pages selected for deletion.');
          }
          const pagesToDelete: number[] = Array.from(dupSelectedToRemove);
          newBytes = await deletePages(pdfBuffer, pagesToDelete);
          successMsg = `Successfully removed ${dupSelectedToRemove.size} duplicate page(s) from document!`;
          const delSet = new Set(pagesToDelete);
          const curSeq = pageSequence && pageSequence.length === pageCount
            ? pageSequence
            : Array.from({ length: pageCount }, (_, i) => i + 1);
          updatedSequence = curSeq.filter((_, idx) => !delSet.has(idx + 1));
          break;
        }

        case 'blank-detector': {
          if (blankSelectedToRemove.size === 0) {
            throw new Error('No blank pages selected for deletion.');
          }
          const pagesToDelete: number[] = Array.from(blankSelectedToRemove);
          newBytes = await deletePages(pdfBuffer, pagesToDelete);
          successMsg = `Successfully removed ${blankSelectedToRemove.size} blank page(s) from document!`;
          const delSet = new Set(pagesToDelete);
          const curSeq = pageSequence && pageSequence.length === pageCount
            ? pageSequence
            : Array.from({ length: pageCount }, (_, i) => i + 1);
          updatedSequence = curSeq.filter((_, idx) => !delSet.has(idx + 1));
          break;
        }

        case 'page-size-normalizer': {
          newBytes = await normalizePageSizes(pdfBuffer, {
            preset: psPreset,
            customWidthPt: psCustomWidthPt,
            customHeightPt: psCustomHeightPt,
            orientation: psOrientation,
            scaleMode: psScaleMode,
          });
          const targetName =
            psPreset === 'MATCH_PAGE_1'
              ? 'Page 1 dimensions'
              : psPreset === 'CUSTOM'
              ? `${psCustomWidthPt}x${psCustomHeightPt} pt`
              : STANDARD_PAGE_SIZES[psPreset]?.name || psPreset;
          successMsg = `Successfully normalized all ${pageCount} page(s) to ${targetName}!`;
          break;
        }

        case 'remove-password': {
          if (isDocEncryptedState) {
            if (!removePwPassword) {
              throw new Error('Please enter the password to unlock this protected PDF document.');
            }
            const unlockRes = await unlockAndDecryptPdf(pdfBuffer, removePwPassword);
            newBytes = new Uint8Array(unlockRes.decryptedBuffer);
            successMsg = 'Password protection successfully removed and PDF decrypted!';
          } else {
            // Already unencrypted: load and save clean copy via removePasswordFromPdf
            newBytes = await removePasswordFromPdf(pdfBuffer);
            successMsg = 'PDF document verified and saved without password protection!';
          }
          break;
        }

        default:
          throw new Error('Unsupported tool action.');
      }

      if (newBytes) {
        onUpdatePdfBuffer(newBytes.buffer, successMsg, undefined, updatedSequence);
        onClose();
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'An error occurred while processing the PDF.');
    } finally {
      setProcessing(false);
    }
  };

  const getToolIcon = () => {
    switch (tool.id) {
      case 'image-to-pdf':
        return <ImageIcon size={18} />;
      case 'merge':
        return <Combine size={18} />;
      case 'split':
        return <SplitIcon size={18} />;
      case 'extract-pages':
        return <FileMinus size={18} />;
      case 'delete-pages':
        return <Trash2 size={18} />;
      case 'reorder':
        return <ArrowUpDown size={18} />;
      case 'watermark':
        return <Stamp size={18} />;
      case 'esign':
        return <PenTool size={18} />;
      case 'compress':
        return <Minimize2 size={18} />;
      case 'page-numbers':
        return <Hash size={18} />;
      case 'duplicate-detector':
        return <CopyX size={18} />;
      case 'blank-detector':
        return <FileX size={18} />;
      case 'page-size-normalizer':
        return <Scaling size={18} />;
      case 'find-replace':
        return <Replace size={18} />;
      case 'remove-password':
        return <Unlock size={18} />;
      default:
        return <FileText size={18} />;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1B2740]/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-xl shadow-2xl border border-[#E8E8E6] w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#E8E8E6] flex items-center justify-between bg-[#F6F6F4] shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-lg bg-[#1B2740] text-white flex items-center justify-center">
              {getToolIcon()}
            </div>
            <div>
              <h3 className="font-fraunces text-lg font-medium text-[#1B2740]">{tool.name}</h3>
              <p className="text-xs text-[#6B7280]">{tool.category} Tool</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6B7280] hover:text-[#1B2740] hover:bg-white rounded-lg transition-colors cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="mx-6 mt-4 p-3 rounded-lg bg-red-50 border border-red-200 flex items-start space-x-2 text-xs text-red-700">
            <AlertCircle size={16} className="shrink-0 mt-0.5 text-red-600" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Content Body */}
        <div className="p-6 space-y-5 overflow-y-auto flex-1 text-sm">
          <p className="text-xs text-[#6B7280] leading-relaxed">{tool.description}</p>

          {/* 0. IMAGE TO PDF CONVERTER */}
          {tool.id === 'image-to-pdf' && (
            <div className="space-y-5 text-sm">
              <div className="p-4 bg-gradient-to-r from-[#1B2740] to-[#2C3E60] text-white rounded-xl shadow-md space-y-1">
                <div className="flex items-center space-x-2 text-[#C4432E] font-bold text-xs uppercase tracking-wider font-ibm-mono">
                  <ImageIcon size={16} />
                  <span>Real-Time Image to PDF Engine</span>
                </div>
                <h4 className="text-base font-bold">Convert Images to High-Quality PDF</h4>
                <p className="text-xs text-gray-300 leading-relaxed">
                  Upload single or multiple images (JPG, PNG, WebP, GIF) to generate a clean, properly formatted PDF document.
                </p>
              </div>

              {/* Upload Dropzone */}
              <label className="block w-full p-5 border-2 border-dashed border-[#1B2740]/25 hover:border-[#C4432E] rounded-xl bg-[#F6F6F4] hover:bg-[#C4432E]/5 transition-all text-center cursor-pointer">
                <input
                  type="file"
                  accept="image/*,.jpg,.jpeg,.png,.webp,.gif,.bmp"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files) {
                      handleImageFilesUpload(e.target.files);
                    }
                  }}
                />
                <div className="flex flex-col items-center justify-center space-y-2">
                  <div className="w-10 h-10 rounded-full bg-[#C4432E]/10 text-[#C4432E] flex items-center justify-center">
                    <Upload size={20} />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-[#1B2740]">Click or drag image files here</span>
                    <p className="text-[11px] text-[#6B7280]">JPG, PNG, WebP, GIF, BMP (Multiple allowed)</p>
                  </div>
                </div>
              </label>

              {/* Uploaded Image Items List */}
              {imgFiles.length > 0 && (
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-xs font-semibold text-[#1B2740] font-ibm-mono uppercase">
                    <span>Uploaded Images ({imgFiles.length})</span>
                    <button
                      onClick={() => setImgFiles([])}
                      className="text-[#C4432E] hover:underline text-[11px] normal-case cursor-pointer"
                    >
                      Clear all
                    </button>
                  </div>

                  <div className="space-y-2 max-h-48 overflow-y-auto pr-1 no-scrollbar">
                    {imgFiles.map((item, idx) => (
                      <div
                        key={item.id}
                        className="p-2.5 bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl flex items-center justify-between gap-3 text-xs"
                      >
                        <div className="flex items-center gap-3 overflow-hidden">
                          <span className="w-5 h-5 rounded-full bg-[#1B2740] text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                            {idx + 1}
                          </span>
                          <img
                            src={item.dataUrl}
                            alt={item.name}
                            className="w-10 h-10 object-cover rounded-lg border border-[#E8E8E6] bg-white shrink-0"
                          />
                          <div className="truncate">
                            <span className="font-semibold text-[#1B2740] truncate block">{item.name}</span>
                            <span className="text-[10px] text-[#6B7280] font-ibm-mono">{item.sizeStr}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            disabled={idx === 0}
                            onClick={() => {
                              const copy = [...imgFiles];
                              const temp = copy[idx];
                              copy[idx] = copy[idx - 1];
                              copy[idx - 1] = temp;
                              setImgFiles(copy);
                            }}
                            className="p-1 text-[#1B2740] hover:bg-white rounded cursor-pointer disabled:opacity-20"
                            title="Move Up"
                          >
                            <ArrowUp size={14} />
                          </button>
                          <button
                            type="button"
                            disabled={idx === imgFiles.length - 1}
                            onClick={() => {
                              const copy = [...imgFiles];
                              const temp = copy[idx];
                              copy[idx] = copy[idx + 1];
                              copy[idx + 1] = temp;
                              setImgFiles(copy);
                            }}
                            className="p-1 text-[#1B2740] hover:bg-white rounded cursor-pointer disabled:opacity-20"
                            title="Move Down"
                          >
                            <ArrowDown size={14} />
                          </button>
                          <button
                            type="button"
                            onClick={() => setImgFiles((prev) => prev.filter((i) => i.id !== item.id))}
                            className="p-1 text-[#6B7280] hover:text-[#C4432E] hover:bg-white rounded cursor-pointer"
                            title="Remove"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Page Layout Settings */}
              <div className="space-y-3 bg-[#F6F6F4] p-3.5 rounded-xl border border-[#E8E8E6]">
                <div className="grid grid-cols-3 gap-2">
                  {/* Page Size */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-[#1B2740] uppercase font-ibm-mono block">
                      Page Size
                    </label>
                    <select
                      value={imgPageSize}
                      onChange={(e) => setImgPageSize(e.target.value as any)}
                      className="w-full bg-white border border-[#E8E8E6] text-xs text-[#1B2740] rounded-lg p-1.5 focus:outline-none"
                    >
                      <option value="a4">A4 (Standard)</option>
                      <option value="letter">US Letter</option>
                      <option value="fit">Fit to Image</option>
                    </select>
                  </div>

                  {/* Orientation */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-[#1B2740] uppercase font-ibm-mono block">
                      Orientation
                    </label>
                    <select
                      value={imgOrientation}
                      onChange={(e) => setImgOrientation(e.target.value as any)}
                      className="w-full bg-white border border-[#E8E8E6] text-xs text-[#1B2740] rounded-lg p-1.5 focus:outline-none"
                    >
                      <option value="auto">Auto Detect</option>
                      <option value="portrait">Portrait</option>
                      <option value="landscape">Landscape</option>
                    </select>
                  </div>

                  {/* Margin */}
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-[#1B2740] uppercase font-ibm-mono block">
                      Page Margin
                    </label>
                    <select
                      value={imgMargin}
                      onChange={(e) => setImgMargin(e.target.value as any)}
                      className="w-full bg-white border border-[#E8E8E6] text-xs text-[#1B2740] rounded-lg p-1.5 focus:outline-none"
                    >
                      <option value="none">No Margin</option>
                      <option value="small">Small (0.25")</option>
                      <option value="medium">Medium (0.5")</option>
                      <option value="large">Large (0.75")</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* 1. MERGE */}
          {tool.id === 'merge' && (
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#1B2740] uppercase font-ibm-mono">
                  Select Additional PDFs to Merge
                </label>
                <p className="text-xs text-[#6B7280]">
                  Upload one or more PDF files to combine with <span className="font-semibold text-[#1B2740]">{pdfFileName || 'Current Document'}</span>.
                </p>
              </div>

              <label className="block w-full p-4 border-2 border-dashed border-[#1B2740]/20 hover:border-[#C4432E] rounded-xl bg-[#F6F6F4] hover:bg-[#C4432E]/5 transition-all text-center cursor-pointer">
                <input
                  type="file"
                  accept=".pdf"
                  multiple
                  onChange={async (e) => {
                    if (e.target.files) {
                      const list: { name: string; buffer: ArrayBuffer }[] = [];
                      for (let i = 0; i < e.target.files.length; i++) {
                        const file = e.target.files[i];
                        const buf = await file.arrayBuffer();
                        list.push({ name: file.name, buffer: buf });
                      }
                      setExtraFiles((prev) => [...prev, ...list]);
                    }
                  }}
                  className="hidden"
                />
                <div className="flex flex-col items-center justify-center space-y-1.5">
                  <Upload size={24} className="text-[#C4432E]" />
                  <span className="text-xs font-medium text-[#1B2740]">
                    Click to browse or drop PDF files here
                  </span>
                  <span className="text-[10px] text-[#6B7280]">
                    Select multiple files at once
                  </span>
                </div>
              </label>

              <div className="space-y-2">
                <p className="text-xs font-semibold text-[#1B2740] flex justify-between items-center">
                  <span>Merge Sequence Order ({1 + extraFiles.length} Documents):</span>
                  {extraFiles.length > 0 && (
                    <button
                      type="button"
                      onClick={() => setExtraFiles([])}
                      className="text-[11px] text-red-600 hover:underline font-normal cursor-pointer"
                    >
                      Clear additional
                    </button>
                  )}
                </p>

                <div className="space-y-1.5 max-h-40 overflow-y-auto border border-[#E8E8E6] p-2 rounded-lg bg-[#F6F6F4]">
                  <div className="p-2 bg-white rounded border border-[#E8E8E6] text-xs font-ibm-mono text-[#1B2740] flex justify-between items-center shadow-2xs">
                    <span className="truncate max-w-[280px]">
                      1. {pdfFileName || 'Primary_Document.pdf'}
                    </span>
                    <span className="text-[10px] font-bold text-[#C4432E] bg-[#C4432E]/10 px-2 py-0.5 rounded">
                      Active Doc
                    </span>
                  </div>

                  {extraFiles.map((file, idx) => (
                    <div
                      key={idx}
                      className="p-2 bg-white rounded border border-[#E8E8E6] text-xs font-ibm-mono text-[#1B2740] flex justify-between items-center"
                    >
                      <span className="truncate max-w-[260px]">
                        {idx + 2}. {file.name}
                      </span>
                      <button
                        type="button"
                        onClick={() => setExtraFiles(extraFiles.filter((_, i) => i !== idx))}
                        className="text-red-600 hover:text-red-800 p-1 cursor-pointer"
                        title="Remove from merge list"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                </div>

                {extraFiles.length === 0 && (
                  <p className="text-[11px] text-amber-700 bg-amber-50 p-2.5 rounded-lg border border-amber-200">
                    ℹ️ Please select at least one additional PDF file above before clicking Apply Merge.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* 2. SPLIT */}
          {tool.id === 'split' && (
            <div className="space-y-3">
              <label className="text-xs font-semibold text-[#1B2740] uppercase font-ibm-mono">
                Split Strategy
              </label>
              <div className="flex gap-4 text-xs font-medium">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="splitMode"
                    value="every_n"
                    checked={splitMode === 'every_n'}
                    onChange={() => setSplitMode('every_n')}
                    className="accent-[#C4432E]"
                  />
                  <span>Split Every N Pages</span>
                </label>
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="radio"
                    name="splitMode"
                    value="range"
                    checked={splitMode === 'range'}
                    onChange={() => setSplitMode('range')}
                    className="accent-[#C4432E]"
                  />
                  <span>Page Ranges (e.g. 1-2, 3-5)</span>
                </label>
              </div>

              <input
                type="text"
                value={splitParam}
                onChange={(e) => setSplitParam(e.target.value)}
                placeholder={splitMode === 'every_n' ? 'Number of pages per split (e.g. 1)' : 'Ranges e.g. 1-2, 3-5'}
                className="w-full px-3.5 py-2.5 rounded-lg border border-[#E8E8E6] text-sm focus:outline-none focus:border-[#C4432E]"
              />
            </div>
          )}

          {/* 3. EXTRACT PAGES TOOL */}
          {tool.id === 'extract-pages' && (
            <div className="space-y-4 text-sm">
              {/* Header Info Box */}
              <div className="p-3.5 bg-linear-to-r from-[#1B2740] to-[#243456] text-white rounded-xl shadow-xs flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="flex items-center space-x-2">
                    <FileMinus size={16} className="text-[#C4432E]" />
                    <span className="font-bold text-xs uppercase font-ibm-mono tracking-wider">
                      Extract Pages from PDF
                    </span>
                  </div>
                  <p className="text-xs text-gray-300">
                    Extract pages by page range or multiple ranges (e.g. <span className="font-ibm-mono text-white font-semibold">1-5, 8, 12-17, 25</span>) into a new document.
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[10px] text-gray-400 block uppercase font-ibm-mono">Doc Size</span>
                  <span className="text-xs font-bold font-ibm-mono text-white bg-white/10 px-2 py-0.5 rounded border border-white/10">
                    {pageCount} {pageCount === 1 ? 'Page' : 'Pages'}
                  </span>
                </div>
              </div>

              {/* Sub Mode Navigation Tabs */}
              <div className="flex items-center gap-2 border-b border-[#E8E8E6] pb-2">
                <button
                  type="button"
                  onClick={() => setExtractMode('range')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                    extractMode === 'range'
                      ? 'bg-[#1B2740] text-white shadow-2xs'
                      : 'text-[#6B7280] hover:text-[#1B2740] hover:bg-gray-100'
                  }`}
                >
                  <ListFilter size={14} />
                  <span>Page Ranges (e.g. 1-5, 8, 12-17, 25)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setExtractMode('visual')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-all cursor-pointer ${
                    extractMode === 'visual'
                      ? 'bg-[#1B2740] text-white shadow-2xs'
                      : 'text-[#6B7280] hover:text-[#1B2740] hover:bg-gray-100'
                  }`}
                >
                  <LayoutGrid size={14} />
                  <span>Visual Page Grid</span>
                </button>
              </div>

              {/* MODE 1: RANGE INPUT */}
              {extractMode === 'range' && (
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-[#1B2740]">
                        Extract Pages by Page Range / Multiple Ranges:
                      </label>
                      <span className="text-[11px] text-[#6B7280]">
                        Supports comma-separated numbers & hyphen ranges
                      </span>
                    </div>

                    <div className="relative">
                      <input
                        type="text"
                        value={extractRangeInput}
                        onChange={(e) => handleExtractRangeChange(e.target.value)}
                        placeholder="e.g. 1-5, 8, 12-17, 25"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E8E6] text-sm font-ibm-mono focus:outline-none focus:border-[#C4432E] focus:ring-1 focus:ring-[#C4432E] shadow-2xs pr-16 bg-white"
                      />
                      {extractRangeInput && (
                        <button
                          type="button"
                          onClick={() => handleExtractRangeChange('')}
                          className="absolute right-2 top-1/2 -translate-y-1/2 px-2 py-1 text-[11px] text-gray-400 hover:text-gray-700 bg-gray-100 hover:bg-gray-200 rounded cursor-pointer transition-colors"
                        >
                          Clear
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Fast Preset Range Pills */}
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-semibold text-gray-500 block uppercase font-ibm-mono">
                      Quick Selection Presets:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleApplyExtractPreset('all')}
                        className="px-2.5 py-1 text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors cursor-pointer"
                      >
                        All Pages (1-{pageCount})
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApplyExtractPreset('odd')}
                        className="px-2.5 py-1 text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors cursor-pointer"
                      >
                        Odd Pages (1, 3, 5...)
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApplyExtractPreset('even')}
                        className="px-2.5 py-1 text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors cursor-pointer"
                      >
                        Even Pages (2, 4, 6...)
                      </button>
                      {pageCount > 2 && (
                        <>
                          <button
                            type="button"
                            onClick={() => handleApplyExtractPreset('first-half')}
                            className="px-2.5 py-1 text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors cursor-pointer"
                          >
                            First Half (1-{Math.ceil(pageCount / 2)})
                          </button>
                          <button
                            type="button"
                            onClick={() => handleApplyExtractPreset('second-half')}
                            className="px-2.5 py-1 text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors cursor-pointer"
                          >
                            Second Half ({Math.ceil(pageCount / 2) + 1}-{pageCount})
                          </button>
                        </>
                      )}
                      <button
                        type="button"
                        onClick={() => handleApplyExtractPreset('current')}
                        className="px-2.5 py-1 text-xs bg-[#C4432E]/10 hover:bg-[#C4432E]/20 text-[#C4432E] font-semibold rounded-lg transition-colors cursor-pointer"
                      >
                        Current Page ({activePage || 1})
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApplyExtractPreset('clear')}
                        className="px-2.5 py-1 text-xs text-gray-400 hover:text-red-600 rounded-lg transition-colors cursor-pointer hover:bg-red-50"
                      >
                        Clear
                      </button>
                    </div>
                  </div>

                  {/* Real-time Parsed Validation & Breakdown */}
                  {(() => {
                    const parsed = parsePageRanges(extractRangeInput, pageCount);
                    return (
                      <div className="space-y-2 pt-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-[#1B2740] flex items-center gap-1.5">
                            <Sparkles size={13} className="text-[#C4432E]" />
                            Resolved Pages for Extraction ({parsed.uniquePages.length} of {pageCount}):
                          </span>
                          <span className="text-[11px] font-ibm-mono text-[#6B7280]">
                            {parsed.uniquePages.length === 0
                              ? 'None selected'
                              : `${parsed.uniquePages.length} page(s) ready`}
                          </span>
                        </div>

                        {/* Resolved Page Pills */}
                        {parsed.uniquePages.length > 0 ? (
                          <div className="flex flex-wrap gap-1.5 max-h-36 overflow-y-auto p-2 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6]">
                            {parsed.uniquePages.map((pageNum) => (
                              <button
                                key={pageNum}
                                type="button"
                                onClick={() => handleToggleExtractPage(pageNum)}
                                title={`Click to remove page ${pageNum}`}
                                className="group inline-flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-red-50 border border-gray-200 hover:border-red-300 rounded-lg text-xs font-ibm-mono text-[#1B2740] hover:text-red-700 transition-all cursor-pointer shadow-2xs"
                              >
                                <span>Page {pageNum}</span>
                                <X size={12} className="text-gray-400 group-hover:text-red-600" />
                              </button>
                            ))}
                          </div>
                        ) : (
                          <div className="p-3 bg-gray-50 border border-dashed border-gray-200 rounded-xl text-center text-xs text-gray-500">
                            No pages selected yet. Enter a range like{' '}
                            <span className="font-ibm-mono font-bold text-gray-700">1-5, 8, 12-17, 25</span> or choose presets above.
                          </div>
                        )}

                        {/* Parsing Warnings / Errors */}
                        {parsed.invalidTokens.length > 0 && (
                          <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-2">
                            <AlertCircle size={15} className="shrink-0 mt-0.5" />
                            <span>
                              Unrecognized token(s): <strong className="font-ibm-mono">{parsed.invalidTokens.join(', ')}</strong>. Please use numbers and ranges (e.g. 1-5, 8, 12-17, 25).
                            </span>
                          </div>
                        )}
                        {parsed.outOfRangePages.length > 0 && (
                          <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-800 flex items-start gap-2">
                            <AlertTriangle size={15} className="shrink-0 mt-0.5" />
                            <span>
                              Page(s) <strong className="font-ibm-mono">{parsed.outOfRangePages.join(', ')}</strong> exceed total document page count ({pageCount}) and will be skipped.
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
              )}

              {/* MODE 2: VISUAL PAGE GRID SELECTION */}
              {extractMode === 'visual' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#1B2740]">
                      Click pages to toggle selection ({extractSelectedPages.length} of {pageCount} selected):
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleApplyExtractPreset('all')}
                        className="text-[11px] px-2 py-0.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded cursor-pointer"
                      >
                        All
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApplyExtractPreset('clear')}
                        className="text-[11px] px-2 py-0.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded cursor-pointer"
                      >
                        None
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApplyExtractPreset('odd')}
                        className="text-[11px] px-2 py-0.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded cursor-pointer"
                      >
                        Odd
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApplyExtractPreset('even')}
                        className="text-[11px] px-2 py-0.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded cursor-pointer"
                      >
                        Even
                      </button>
                    </div>
                  </div>

                  {/* Grid of Pages */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-2.5 max-h-56 overflow-y-auto p-2 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6]">
                    {Array.from({ length: pageCount }, (_, i) => i + 1).map((pageNum) => {
                      const isSelected = extractSelectedPages.includes(pageNum);
                      const thumb = thumbnails && thumbnails[pageNum - 1];

                      return (
                        <div
                          key={pageNum}
                          onClick={() => handleToggleExtractPage(pageNum)}
                          className={`relative p-2 rounded-xl border transition-all cursor-pointer flex flex-col items-center gap-1.5 select-none ${
                            isSelected
                              ? 'bg-[#C4432E]/10 border-[#C4432E] shadow-2xs font-semibold'
                              : 'bg-white border-gray-200 hover:border-gray-400'
                          }`}
                        >
                          <div className="flex items-center justify-between w-full">
                            <span
                              className={`text-[10px] font-bold px-1.5 py-0.5 rounded font-ibm-mono ${
                                isSelected ? 'bg-[#C4432E] text-white' : 'bg-gray-100 text-gray-700'
                              }`}
                            >
                              Page {pageNum}
                            </span>
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => {}}
                              className="w-3.5 h-3.5 accent-[#C4432E] rounded cursor-pointer pointer-events-none"
                            />
                          </div>

                          {/* Thumbnail / Page Mockup */}
                          {thumb ? (
                            <img
                              src={thumb}
                              alt={`Page ${pageNum}`}
                              className="w-16 h-22 object-contain rounded border border-gray-200 bg-white shadow-2xs"
                            />
                          ) : (
                            <div className="w-16 h-22 bg-white rounded border border-gray-200 shadow-2xs flex flex-col items-center justify-center p-1 text-center">
                              <BookOpen size={16} className="text-gray-400 mb-1" />
                              <span className="text-[9px] text-gray-500 font-ibm-mono font-bold">P. {pageNum}</span>
                            </div>
                          )}

                          <span
                            className={`text-[10px] font-semibold ${
                              isSelected ? 'text-[#C4432E]' : 'text-gray-400'
                            }`}
                          >
                            {isSelected ? 'Selected' : 'Omit'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Extraction Output & Delivery Settings */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                {/* Output Structure */}
                <div className="p-3 bg-white rounded-xl border border-[#E8E8E6] space-y-2">
                  <label className="text-xs font-bold text-[#1B2740] block">Extraction Output Format:</label>
                  <div className="space-y-1.5 text-xs text-gray-700">
                    <label className="flex items-start space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="extractOutputFormat"
                        value="merged"
                        checked={extractOutputFormat === 'merged'}
                        onChange={() => setExtractOutputFormat('merged')}
                        className="accent-[#C4432E] mt-0.5"
                      />
                      <div>
                        <span className="font-semibold text-[#1B2740] block">Combine into Single PDF</span>
                        <span className="text-[11px] text-[#6B7280]">
                          Produces 1 PDF containing all extracted pages
                        </span>
                      </div>
                    </label>
                    <label className="flex items-start space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="extractOutputFormat"
                        value="separate"
                        checked={extractOutputFormat === 'separate'}
                        onChange={() => setExtractOutputFormat('separate')}
                        className="accent-[#C4432E] mt-0.5"
                      />
                      <div>
                        <span className="font-semibold text-[#1B2740] block">Separate Individual PDFs</span>
                        <span className="text-[11px] text-[#6B7280]">
                          Produces individual PDF files per page
                        </span>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Delivery Destination */}
                <div className="p-3 bg-white rounded-xl border border-[#E8E8E6] space-y-2">
                  <label className="text-xs font-bold text-[#1B2740] block">Delivery Action:</label>
                  <div className="space-y-1.5 text-xs text-gray-700">
                    <label className="flex items-start space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="extractActionTarget"
                        value="editor"
                        checked={extractActionTarget === 'editor'}
                        onChange={() => setExtractActionTarget('editor')}
                        className="accent-[#C4432E] mt-0.5"
                      />
                      <div>
                        <span className="font-semibold text-[#1B2740] block">Open in Editor Workspace</span>
                        <span className="text-[11px] text-[#6B7280]">
                          Replace active document to continue editing
                        </span>
                      </div>
                    </label>
                    <label className="flex items-start space-x-2 cursor-pointer">
                      <input
                        type="radio"
                        name="extractActionTarget"
                        value="download"
                        checked={extractActionTarget === 'download'}
                        onChange={() => setExtractActionTarget('download')}
                        className="accent-[#C4432E] mt-0.5"
                      />
                      <div>
                        <span className="font-semibold text-[#1B2740] block">Direct File Download</span>
                        <span className="text-[11px] text-[#6B7280]">
                          Keep current document in editor intact
                        </span>
                      </div>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* DELETE PAGES TOOL */}
          {tool.id === 'delete-pages' && (
            <div className="space-y-4 text-sm">
              <div className="p-3.5 bg-linear-to-r from-red-900/90 to-red-950 text-white rounded-xl shadow-xs flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="flex items-center space-x-2">
                    <Trash2 size={16} className="text-red-400" />
                    <span className="font-bold text-xs uppercase font-ibm-mono tracking-wider">
                      Delete Pages from Document
                    </span>
                  </div>
                  <p className="text-xs text-red-200">
                    Specify page numbers or ranges (e.g. <span className="font-ibm-mono text-white font-semibold">1-3, 5, 8</span>) to remove permanently.
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[10px] text-red-300 block uppercase font-ibm-mono">Current Total</span>
                  <span className="text-xs font-bold font-ibm-mono text-white bg-white/10 px-2 py-0.5 rounded border border-white/10">
                    {pageCount} {pageCount === 1 ? 'Page' : 'Pages'}
                  </span>
                </div>
              </div>

              {pageCount <= 1 ? (
                <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 space-y-1.5">
                  <p className="font-bold flex items-center gap-1.5 text-amber-900">
                    <AlertTriangle size={15} />
                    Single-Page Document Protection
                  </p>
                  <p>
                    This document only contains 1 page. A PDF file requires at least one page to remain valid, so page deletion is disabled.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-[#1B2740] block">
                      Pages & Ranges to Delete:
                    </label>
                    <input
                      type="text"
                      value={deletePagesInput}
                      onChange={(e) => handleDeleteRangeChange(e.target.value)}
                      placeholder="e.g. 1-3, 5, 8"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-[#E8E8E6] text-sm font-ibm-mono focus:outline-none focus:border-[#C4432E] focus:ring-1 focus:ring-[#C4432E] shadow-2xs bg-white"
                    />
                  </div>

                  {/* Fast Presets for Delete */}
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-semibold text-gray-500 block uppercase font-ibm-mono">
                      Quick Selection:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleApplyDeletePreset('current')}
                        className="px-2.5 py-1 text-xs bg-[#C4432E]/10 hover:bg-[#C4432E]/20 text-[#C4432E] font-semibold rounded-lg transition-colors cursor-pointer"
                      >
                        Current Page ({activePage || 1})
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApplyDeletePreset('odd')}
                        className="px-2.5 py-1 text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors cursor-pointer"
                      >
                        All Odd Pages
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApplyDeletePreset('even')}
                        className="px-2.5 py-1 text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors cursor-pointer"
                      >
                        All Even Pages
                      </button>
                      <button
                        type="button"
                        onClick={() => handleApplyDeletePreset('clear')}
                        className="px-2.5 py-1 text-xs text-gray-400 hover:text-gray-700 rounded-lg transition-colors cursor-pointer hover:bg-gray-100"
                      >
                        Clear Selection
                      </button>
                    </div>
                  </div>

                  {/* Resolved breakdown */}
                  {(() => {
                    const parsed = parsePageRanges(deletePagesInput, pageCount);
                    const pagesToDeleteCount = parsed.uniquePages.length;
                    const remainingCount = pageCount - pagesToDeleteCount;

                    return (
                      <div className="space-y-2 pt-1">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-red-700">
                            Pages marked for deletion ({pagesToDeleteCount}):
                          </span>
                          <span className={`text-[11px] font-ibm-mono font-semibold ${
                            remainingCount <= 0 ? 'text-red-600' : 'text-emerald-700'
                          }`}>
                            {remainingCount <= 0
                              ? '⚠️ Cannot delete all pages'
                              : `${remainingCount} page(s) will remain`}
                          </span>
                        </div>

                        {parsed.uniquePages.length > 0 && (
                          <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-2 bg-red-50/50 rounded-xl border border-red-200">
                            {parsed.uniquePages.map((pageNum) => (
                              <button
                                key={pageNum}
                                type="button"
                                onClick={() => handleToggleDeletePage(pageNum)}
                                title={`Click to keep page ${pageNum}`}
                                className="group inline-flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-emerald-50 border border-red-200 hover:border-emerald-300 rounded-lg text-xs font-ibm-mono text-red-700 hover:text-emerald-700 transition-all cursor-pointer shadow-2xs"
                              >
                                <span>Delete Page {pageNum}</span>
                                <X size={12} className="text-red-400 group-hover:text-emerald-600" />
                              </button>
                            ))}
                          </div>
                        )}

                        {parsed.invalidTokens.length > 0 && (
                          <div className="p-2.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700 flex items-start gap-2">
                            <AlertCircle size={15} className="shrink-0 mt-0.5" />
                            <span>
                              Unrecognized token(s): <strong className="font-ibm-mono">{parsed.invalidTokens.join(', ')}</strong>.
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
          )}

          {/* 4. REORDER */}
          {tool.id === 'reorder' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-[#1B2740] uppercase font-ibm-mono">
                  Page Sequence Order
                </label>
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={() => {
                      const parsed = reorderInput
                        .split(',')
                        .map((s) => parseInt(s.trim(), 10))
                        .filter((n) => !isNaN(n));
                      setReorderInput(parsed.reverse().join(', '));
                    }}
                    className="text-[11px] font-medium text-[#1B2740] hover:text-[#C4432E] hover:underline cursor-pointer"
                  >
                    Reverse
                  </button>
                  <span className="text-gray-300">|</span>
                  <button
                    type="button"
                    onClick={() => {
                      setReorderInput(Array.from({ length: pageCount }, (_, i) => i + 1).join(', '));
                    }}
                    className="text-[11px] font-medium text-[#1B2740] hover:text-[#C4432E] hover:underline cursor-pointer"
                  >
                    Reset (1..{pageCount})
                  </button>
                </div>
              </div>

              {/* Text Input Box */}
              <input
                type="text"
                value={reorderInput}
                onChange={(e) => setReorderInput(e.target.value)}
                placeholder="e.g. 5, 3, 2, 6, 1, 4, 8, 7"
                className="w-full px-3.5 py-2.5 rounded-lg border border-[#E8E8E6] text-sm font-ibm-mono focus:outline-none focus:border-[#C4432E]"
              />

              {/* Visual Page Order Cards */}
              {(() => {
                const parsed = reorderInput
                  .split(',')
                  .map((s) => parseInt(s.trim(), 10))
                  .filter((n) => !isNaN(n));

                if (parsed.length === 0) return null;

                return (
                  <div className="space-y-2">
                    <p className="text-[11px] font-semibold text-[#6B7280] uppercase tracking-wider font-ibm-mono">
                      Visual Reorder List ({parsed.length} pages)
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto p-1 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6]">
                      {parsed.map((pNum, idx) => (
                        <div
                          key={`${pNum}-${idx}`}
                          className="p-2.5 bg-white border border-[#E8E8E6] rounded-lg flex items-center justify-between shadow-2xs text-xs"
                        >
                          <div className="flex items-center space-x-2.5 truncate">
                            <span className="w-5 h-5 rounded-full bg-[#1B2740] text-white text-[10px] font-bold flex items-center justify-center shrink-0 font-ibm-mono">
                              {idx + 1}
                            </span>
                            <span className="font-bold text-[#1B2740] truncate">
                              Page {pNum}
                            </span>
                          </div>
                          <div className="flex items-center space-x-1 shrink-0">
                            <button
                              type="button"
                              disabled={idx === 0}
                              onClick={() => {
                                const copy = [...parsed];
                                const temp = copy[idx];
                                copy[idx] = copy[idx - 1];
                                copy[idx - 1] = temp;
                                setReorderInput(copy.join(', '));
                              }}
                              className="p-1 text-[#1B2740] hover:bg-[#F6F6F4] rounded disabled:opacity-20 cursor-pointer"
                              title="Move Up"
                            >
                              <ArrowUp size={14} />
                            </button>
                            <button
                              type="button"
                              disabled={idx === parsed.length - 1}
                              onClick={() => {
                                const copy = [...parsed];
                                const temp = copy[idx];
                                copy[idx] = copy[idx + 1];
                                copy[idx + 1] = temp;
                                setReorderInput(copy.join(', '));
                              }}
                              className="p-1 text-[#1B2740] hover:bg-[#F6F6F4] rounded disabled:opacity-20 cursor-pointer"
                              title="Move Down"
                            >
                              <ArrowDown size={14} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })()}

              <p className="text-[11px] text-[#6B7280]">
                Use the Move Up / Down controls or edit the numbers above. Sequence persists throughout editing session.
              </p>
            </div>
          )}

          {/* 5. WATERMARK CONFIGURATION (TEXT & IMAGE WATERMARK) */}
          {tool.id === 'watermark' && (
            <div className="space-y-4">
              {/* Type Switcher: Text Watermark vs Image Watermark */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-[#1B2740] block">Watermark Type</label>
                <div className="grid grid-cols-2 gap-2 bg-[#F6F6F4] p-1 rounded-xl border border-[#E8E8E6]">
                  <button
                    type="button"
                    onClick={() => setWmMode('text')}
                    className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                      wmMode === 'text'
                        ? 'bg-white text-[#C4432E] shadow-xs'
                        : 'text-[#6B7280] hover:text-[#1B2740]'
                    }`}
                  >
                    <Type size={14} className={wmMode === 'text' ? 'text-[#C4432E]' : ''} />
                    <span>Text Watermark</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setWmMode('image');
                      if (!wmImageData) {
                        handleSelectPresetStamp({ label: 'APPROVED', color: '#059669', sub: 'VERIFIED & SIGNED' });
                      }
                    }}
                    className={`py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                      wmMode === 'image'
                        ? 'bg-white text-[#C4432E] shadow-xs'
                        : 'text-[#6B7280] hover:text-[#1B2740]'
                    }`}
                  >
                    <ImageIcon size={14} className={wmMode === 'image' ? 'text-[#C4432E]' : ''} />
                    <span>Image Watermark</span>
                  </button>
                </div>
              </div>

              {/* Mode 1: TEXT WATERMARK SETTINGS */}
              {wmMode === 'text' && (
                <div className="space-y-3.5 animate-in fade-in duration-200">
                  {/* Text Input */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs font-semibold text-[#1B2740]">
                      <label className="flex items-center space-x-1.5">
                        <Type size={14} className="text-[#C4432E]" />
                        <span>Watermark Text</span>
                      </label>
                      {/* Preset Text Quick Chips */}
                      <div className="flex items-center space-x-1">
                        {['CONFIDENTIAL', 'DRAFT', 'SAMPLE', 'COPY'].map((preset) => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setWmText(preset)}
                            className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-[#F6F6F4] hover:bg-[#E8E8E6] text-[#1B2740] cursor-pointer"
                          >
                            {preset}
                          </button>
                        ))}
                      </div>
                    </div>
                    <input
                      type="text"
                      value={wmText}
                      onChange={(e) => setWmText(e.target.value)}
                      placeholder="e.g. CONFIDENTIAL or DRAFT"
                      className="w-full px-3 py-2 border border-[#E8E8E6] rounded-lg text-sm font-medium focus:outline-none focus:border-[#C4432E] bg-white"
                    />
                  </div>

                  {/* Font Size & Color Row */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <div className="flex justify-between items-center text-xs font-semibold text-[#1B2740]">
                        <span className="flex items-center space-x-1">
                          <Maximize2 size={13} className="text-[#C4432E]" />
                          <span>Font Size</span>
                        </span>
                        <span className="font-ibm-mono text-[#C4432E] font-bold">{wmFontSize}px</span>
                      </div>
                      <input
                        type="range"
                        min={16}
                        max={120}
                        value={wmFontSize}
                        onChange={(e) => setWmFontSize(parseInt(e.target.value, 10))}
                        className="w-full accent-[#C4432E] cursor-pointer"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-xs font-semibold text-[#1B2740] flex items-center space-x-1.5">
                        <Palette size={14} className="text-[#C4432E]" />
                        <span>Color Theme</span>
                      </label>
                      <div className="flex items-center space-x-1.5 pt-0.5">
                        {PRESET_COLORS.map((color) => (
                          <button
                            key={color}
                            type="button"
                            onClick={() => setWmColor(color)}
                            style={{ backgroundColor: color }}
                            className={`w-5 h-5 rounded-full border border-black/20 transition-transform cursor-pointer ${
                              wmColor === color ? 'scale-125 ring-2 ring-[#C4432E] ring-offset-1' : 'hover:scale-110'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Mode 2: IMAGE WATERMARK SETTINGS */}
              {wmMode === 'image' && (
                <div className="space-y-3.5 animate-in fade-in duration-200">
                  {/* Preset Stamps Quick Selector */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-[#1B2740] flex items-center justify-between">
                      <span>Quick Stamp Templates</span>
                      <span className="text-[10px] text-[#6B7280] font-normal">Or upload custom logo below</span>
                    </label>
                    <div className="grid grid-cols-5 gap-1.5">
                      {[
                        { label: 'APPROVED', color: '#059669', sub: 'VERIFIED & SIGNED' },
                        { label: 'CONFIDENTIAL', color: '#C4432E', sub: 'INTERNAL ONLY' },
                        { label: 'PAID', color: '#2563EB', sub: 'RECEIPT CONFIRMED' },
                        { label: 'SAMPLE', color: '#D97706', sub: 'DO NOT DUPLICATE' },
                        { label: 'DRAFT', color: '#6B7280', sub: 'PRELIMINARY' },
                      ].map((stamp) => (
                        <button
                          key={stamp.label}
                          type="button"
                          onClick={() => handleSelectPresetStamp(stamp)}
                          className="px-2 py-1.5 rounded-lg border border-[#E8E8E6] bg-white hover:border-[#C4432E] hover:bg-gray-50 text-center transition-all cursor-pointer"
                        >
                          <span className="text-[10px] font-bold block truncate" style={{ color: stamp.color }}>
                            {stamp.label}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Upload / Image Preview Card */}
                  {!wmImageData ? (
                    <label className="flex flex-col items-center justify-center p-5 border-2 border-dashed border-[#E8E8E6] hover:border-[#C4432E] rounded-xl bg-[#F6F6F4] hover:bg-white transition-all cursor-pointer group">
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/webp"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handleSelectWmImageFile(file);
                        }}
                      />
                      <Upload size={24} className="text-[#6B7280] group-hover:text-[#C4432E] mb-1.5 transition-colors" />
                      <span className="text-xs font-bold text-[#1B2740]">Click to upload watermark image or logo</span>
                      <span className="text-[10px] text-[#6B7280]">Supports PNG (with transparency), JPG, WebP</span>
                    </label>
                  ) : (
                    <div className="p-3 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6] flex items-center justify-between gap-3">
                      <div className="flex items-center space-x-3 truncate">
                        <div className="w-16 h-12 bg-white rounded-lg border border-[#E8E8E6] p-1 flex items-center justify-center shrink-0 shadow-2xs overflow-hidden">
                          <img
                            src={wmImageData.dataUrl}
                            alt="Watermark Preview"
                            className="max-w-full max-h-full object-contain"
                          />
                        </div>
                        <div className="truncate">
                          <p className="text-xs font-bold text-[#1B2740] truncate">{wmImageData.name}</p>
                          <p className="text-[10px] text-[#6B7280] font-ibm-mono">
                            {wmImageData.width} × {wmImageData.height} px • {wmImageData.format.toUpperCase()}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => setIsWmImageCropOpen(true)}
                          className="px-2.5 py-1.5 bg-white hover:bg-gray-100 border border-[#E8E8E6] rounded-lg text-xs font-semibold text-[#1B2740] flex items-center space-x-1 cursor-pointer"
                          title="Crop Image"
                        >
                          <Crop size={13} className="text-[#C4432E]" />
                          <span>Crop</span>
                        </button>
                        <label className="px-2.5 py-1.5 bg-white hover:bg-gray-100 border border-[#E8E8E6] rounded-lg text-xs font-semibold text-[#1B2740] flex items-center space-x-1 cursor-pointer">
                          <input
                            type="file"
                            accept="image/png,image/jpeg,image/webp"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) handleSelectWmImageFile(file);
                            }}
                          />
                          <Upload size={13} className="text-[#C4432E]" />
                          <span>Replace</span>
                        </label>
                      </div>
                    </div>
                  )}

                  {/* Image Scale Slider */}
                  <div className="space-y-1">
                    <div className="flex justify-between items-center text-xs font-semibold text-[#1B2740]">
                      <span className="flex items-center space-x-1">
                        <Maximize2 size={13} className="text-[#C4432E]" />
                        <span>Watermark Size (% of page width)</span>
                      </span>
                      <span className="font-ibm-mono text-[#C4432E] font-bold">
                        {Math.round(wmImageWidthRatio * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0.1}
                      max={0.9}
                      step={0.05}
                      value={wmImageWidthRatio}
                      onChange={(e) => setWmImageWidthRatio(parseFloat(e.target.value))}
                      className="w-full accent-[#C4432E] cursor-pointer"
                    />
                  </div>
                </div>
              )}

              {/* Common Controls: Opacity, Rotation, Scope */}
              <div className="grid grid-cols-2 gap-4 pt-1 border-t border-[#E8E8E6]">
                {/* Opacity Slider */}
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-xs font-semibold text-[#1B2740]">
                    <span className="flex items-center space-x-1">
                      <Sun size={13} className="text-[#C4432E]" />
                      <span>Opacity</span>
                    </span>
                    <span className="font-ibm-mono text-[#C4432E] font-bold">
                      {Math.round(wmOpacity * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.1}
                    max={1.0}
                    step={0.05}
                    value={wmOpacity}
                    onChange={(e) => setWmOpacity(parseFloat(e.target.value))}
                    className="w-full accent-[#C4432E] cursor-pointer"
                  />
                </div>

                {/* Rotation Angle */}
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-[#1B2740] flex items-center space-x-1.5">
                    <RotateCw size={14} className="text-[#C4432E]" />
                    <span>Rotation Angle</span>
                  </label>
                  <div className="flex space-x-1">
                    {[0, 45, -45, 90].map((deg) => (
                      <button
                        key={deg}
                        type="button"
                        onClick={() => setWmRotation(deg)}
                        className={`flex-1 py-1 rounded text-xs font-bold border transition-colors cursor-pointer ${
                          wmRotation === deg
                            ? 'bg-[#C4432E] text-white border-[#C4432E]'
                            : 'bg-[#F6F6F4] text-[#1B2740] border-[#E8E8E6] hover:border-[#C4432E]'
                        }`}
                      >
                        {deg}°
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Page Scope */}
              <div className="space-y-1">
                <label className="text-xs font-semibold text-[#1B2740] flex items-center space-x-1.5">
                  <Layers size={14} className="text-[#C4432E]" />
                  <span>Page Scope</span>
                </label>
                <div className="flex bg-[#F6F6F4] p-0.5 rounded-lg border border-[#E8E8E6] text-xs font-medium">
                  <button
                    type="button"
                    onClick={() => setWmScope('all')}
                    className={`flex-1 py-1.5 rounded-md transition-colors cursor-pointer ${
                      wmScope === 'all'
                        ? 'bg-white text-[#C4432E] font-bold shadow-2xs'
                        : 'text-[#6B7280] hover:text-[#1B2740]'
                    }`}
                  >
                    All {pageCount} Pages
                  </button>
                  <button
                    type="button"
                    onClick={() => setWmScope('current')}
                    className={`flex-1 py-1.5 rounded-md transition-colors cursor-pointer ${
                      wmScope === 'current'
                        ? 'bg-white text-[#C4432E] font-bold shadow-2xs'
                        : 'text-[#6B7280] hover:text-[#1B2740]'
                    }`}
                  >
                    Page {activePage} Only
                  </button>
                </div>
              </div>

              <div className="p-3 bg-[#F6F6F4] rounded-lg border border-[#E8E8E6] text-xs text-[#6B7280] space-y-1">
                <p className="font-semibold text-[#1B2740] flex items-center space-x-1">
                  <span>✨ Live Interactive Canvas Placement</span>
                </p>
                <p>
                  Clicking <strong className="text-[#1B2740]">Apply Watermark</strong> launches interactive live mode directly on your document preview where you can drag and resize freely before baking!
                </p>
              </div>
            </div>
          )}

          {/* 6. E-SIGN CONFIGURATION */}
          {tool.id === 'esign' && (
            <ESignModalContent
              onAddSignature={(imageDataUrl) => {
                if (onLaunchSignatureDraft) {
                  onLaunchSignatureDraft({
                    imageDataUrl,
                    xRatio: 0.5,
                    yRatio: 0.5,
                    widthRatio: 0.3,
                    pageNumber: activePage,
                  });
                }
                onClose();
              }}
              onCancel={onClose}
            />
          )}

          {/* 7. ADD IMAGE CONFIGURATION */}
          {tool.id === 'add-image' && (
            <div className="space-y-4 text-sm">
              {/* Header description */}
              <div className="p-3.5 bg-gradient-to-r from-[#1B2740] to-[#2C3E60] text-white rounded-xl shadow-xs space-y-1">
                <div className="flex items-center space-x-2 text-[#C4432E] font-bold text-xs uppercase tracking-wider font-ibm-mono">
                  <ImageIcon size={16} />
                  <span>Insert Image on PDF</span>
                </div>
                <p className="text-xs text-gray-300">
                  Select a JPG or PNG picture from your device to place and resize directly on your document.
                </p>
              </div>

              {/* Upload Dropzone / Image Preview */}
              {!addImageData ? (
                <label className="flex flex-col items-center justify-center p-6 border-2 border-dashed border-[#E8E8E6] hover:border-[#C4432E] rounded-xl bg-[#F6F6F4] hover:bg-[#F6F6F4]/80 transition-all cursor-pointer group">
                  <div className="w-12 h-12 rounded-xl bg-white shadow-xs flex items-center justify-center text-[#6B7280] group-hover:text-[#C4432E] group-hover:scale-110 transition-transform mb-3">
                    <Upload size={22} />
                  </div>
                  <span className="text-xs font-bold text-[#1B2740] group-hover:text-[#C4432E]">
                    Click to select or drag & drop an image
                  </span>
                  <span className="text-[10px] text-[#6B7280] mt-1 font-ibm-mono">
                    Supports JPG, JPEG, and PNG images
                  </span>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/jpg"
                    onChange={(e) => {
                      if (e.target.files?.[0]) {
                        handleSelectAddImageFile(e.target.files[0]);
                      }
                    }}
                    className="hidden"
                  />
                </label>
              ) : (
                <div className="p-4 bg-white border border-[#E8E8E6] rounded-xl shadow-xs space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3 truncate">
                      <div className="w-14 h-14 rounded-lg overflow-hidden border border-[#E8E8E6] bg-gray-50 flex items-center justify-center shrink-0">
                        <img
                          src={addImageData.dataUrl}
                          alt="Selected preview"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="truncate">
                        <span className="text-xs font-bold text-[#1B2740] block truncate">
                          {addImageData.file.name}
                        </span>
                        <div className="flex items-center space-x-2 mt-0.5 text-[10px] text-[#6B7280] font-ibm-mono">
                          <span className="px-1.5 py-0.2 rounded bg-[#C4432E]/10 text-[#C4432E] font-bold uppercase">
                            {addImageData.format}
                          </span>
                          <span>
                            {addImageData.width} × {addImageData.height} px
                          </span>
                          <span>
                            {addImageData.file.size >= 1024 * 1024
                              ? `${(addImageData.file.size / (1024 * 1024)).toFixed(1)} MB`
                              : `${Math.round(addImageData.file.size / 1024)} KB`}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1.5">
                      <button
                        type="button"
                        onClick={() => setIsAddImageCropOpen(true)}
                        className="px-2.5 py-1 rounded-lg bg-[#F6F6F4] hover:bg-[#C4432E]/10 text-[#1B2740] hover:text-[#C4432E] border border-[#E8E8E6] hover:border-[#C4432E] text-xs font-semibold flex items-center space-x-1 transition-colors cursor-pointer"
                        title="Crop and trim image boundaries"
                      >
                        <Crop size={13} className="text-[#C4432E]" />
                        <span>Crop</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setAddImageData(null)}
                        className="p-1.5 text-[#6B7280] hover:text-[#C4432E] hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                        title="Remove and choose different image"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </div>

                  {/* Settings Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-[#E8E8E6]">
                    {/* Target Page Selector */}
                    <div>
                      <label className="text-[11px] font-bold text-[#1B2740] block mb-1">
                        Target Page:
                      </label>
                      <select
                        value={addImagePage}
                        onChange={(e) => setAddImagePage(Number(e.target.value))}
                        className="w-full bg-[#F6F6F4] border border-[#E8E8E6] rounded-lg text-xs px-2.5 py-1.5 font-medium focus:border-[#C4432E] focus:outline-none"
                      >
                        {Array.from({ length: pageCount }, (_, i) => i + 1).map((p) => (
                          <option key={p} value={p}>
                            Page {p} {p === activePage ? '(Current)' : ''}
                          </option>
                        ))}
                      </select>
                    </div>

                    {/* Initial Size Ratio */}
                    <div>
                      <label className="text-[11px] font-bold text-[#1B2740] block mb-1">
                        Default Size: {Math.round(addImageWidthRatio * 100)}%
                      </label>
                      <input
                        type="range"
                        min={0.1}
                        max={0.9}
                        step={0.05}
                        value={addImageWidthRatio}
                        onChange={(e) => setAddImageWidthRatio(parseFloat(e.target.value))}
                        className="w-full accent-[#C4432E] cursor-pointer mt-1"
                      />
                    </div>

                    {/* Opacity */}
                    <div>
                      <label className="text-[11px] font-bold text-[#1B2740] block mb-1">
                        Opacity: {Math.round(addImageOpacity * 100)}%
                      </label>
                      <input
                        type="range"
                        min={0.1}
                        max={1.0}
                        step={0.05}
                        value={addImageOpacity}
                        onChange={(e) => setAddImageOpacity(parseFloat(e.target.value))}
                        className="w-full accent-[#C4432E] cursor-pointer mt-1"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* Informative Hint Banner */}
              <div className="p-3 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6] text-xs text-[#6B7280] space-y-1">
                <p className="font-semibold text-[#1B2740] flex items-center space-x-1.5">
                  <Sparkles size={14} className="text-[#C4432E]" />
                  <span>Live Interactive Drag & Resize</span>
                </p>
                <p>
                  Clicking <strong className="text-[#1B2740]">Place Image on PDF</strong> will open the live draft overlay on your active preview canvas. You can drag anywhere, rotate, and pull corner handles to scale proportionally before baking.
                </p>
              </div>
            </div>
          )}

          {/* 8. COMPRESS PDF CONFIGURATION */}
          {tool.id === 'compress' && (
            <div className="space-y-4 text-sm">
              {/* Top Mode Switcher */}
              <div className="flex bg-[#F6F6F4] p-1 rounded-xl border border-[#E8E8E6] text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => setCompressMode('target')}
                  className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                    compressMode === 'target'
                      ? 'bg-white text-[#C4432E] font-bold shadow-xs border border-[#E8E8E6]'
                      : 'text-[#6B7280] hover:text-[#1B2740]'
                  }`}
                >
                  <Target size={15} className={compressMode === 'target' ? 'text-[#C4432E]' : 'text-[#6B7280]'} />
                  <span>Compress to Target Size</span>
                </button>
                <button
                  type="button"
                  onClick={() => setCompressMode('normal')}
                  className={`flex-1 py-2 px-3 rounded-lg flex items-center justify-center space-x-2 transition-all cursor-pointer ${
                    compressMode === 'normal'
                      ? 'bg-white text-[#C4432E] font-bold shadow-xs border border-[#E8E8E6]'
                      : 'text-[#6B7280] hover:text-[#1B2740]'
                  }`}
                >
                  <Sliders size={15} className={compressMode === 'normal' ? 'text-[#C4432E]' : 'text-[#6B7280]'} />
                  <span>Normal Compression</span>
                </button>
              </div>

              {/* Header Banner */}
              <div className="p-4 bg-gradient-to-br from-[#1B2740] to-[#2A3B5C] text-white rounded-xl shadow-md space-y-2">
                <div className="flex items-center space-x-2 text-emerald-400 font-bold text-xs uppercase tracking-wider font-ibm-mono">
                  <Minimize2 size={16} className="animate-pulse" />
                  <span>
                    {compressMode === 'target' ? 'Iterative Target-Size Optimization' : 'Real-Time PDF Compression'}
                  </span>
                </div>
                <h4 className="text-base font-bold">
                  {compressMode === 'target' ? 'Compress PDF to Target Maximum Size' : 'Adjust Compression Level Ratio'}
                </h4>
                <p className="text-xs text-gray-300 leading-relaxed">
                  {compressMode === 'target'
                    ? 'Specify a target file size (e.g. 1 MB, 2 MB, 5 MB, 10 MB or custom). The engine will automatically binary-search quality and resolution settings to meet or beat your target while preserving optimal visual clarity.'
                    : 'Select a compression ratio or preset to optimize file size. Applying compression updates your live PDF preview canvas immediately!'}
                </p>
              </div>

              {/* TARGET SIZE MODE */}
              {compressMode === 'target' && (
                <div className="space-y-4">
                  {/* Preset Targets */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-[#1B2740] uppercase font-ibm-mono block">
                      Target Size Presets
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      {[
                        { label: '1 MB', val: '1', unit: 'MB' as const },
                        { label: '2 MB', val: '2', unit: 'MB' as const },
                        { label: '5 MB', val: '5', unit: 'MB' as const },
                        { label: '10 MB', val: '10', unit: 'MB' as const },
                      ].map((preset) => {
                        const isSelected = compressTargetValue === preset.val && compressTargetUnit === preset.unit;
                        return (
                          <button
                            key={preset.label}
                            type="button"
                            onClick={() => {
                              setCompressTargetValue(preset.val);
                              setCompressTargetUnit(preset.unit);
                            }}
                            className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                              isSelected
                                ? 'bg-[#C4432E] border-[#C4432E] text-white font-bold shadow-md scale-102'
                                : 'bg-[#F6F6F4] border-[#E8E8E6] text-[#1B2740] hover:border-[#C4432E]'
                            }`}
                          >
                            <div className="text-xs font-bold">{preset.label}</div>
                            <div className={`text-[10px] mt-0.5 ${isSelected ? 'text-white/80' : 'text-[#6B7280]'}`}>
                              ≤ {preset.label}
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Custom Target Size Input */}
                  <div className="p-3.5 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6] space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-semibold text-[#1B2740] flex items-center space-x-1.5">
                        <Target size={14} className="text-[#C4432E]" />
                        <span>Custom Target Size (Maximum Threshold)</span>
                      </span>
                      <span className="text-[10px] text-[#6B7280] font-ibm-mono">
                        Output will be ≤ target
                      </span>
                    </div>

                    <div className="flex items-center space-x-2">
                      <div className="relative flex-1">
                        <input
                          type="number"
                          min="0.1"
                          step={compressTargetUnit === 'MB' ? '0.1' : '10'}
                          value={compressTargetValue}
                          onChange={(e) => setCompressTargetValue(e.target.value)}
                          placeholder="e.g. 5"
                          className="w-full bg-white border border-[#E8E8E6] rounded-lg px-3 py-2 text-xs font-bold text-[#1B2740] focus:border-[#C4432E] focus:outline-none"
                        />
                      </div>
                      <div className="flex bg-white rounded-lg border border-[#E8E8E6] p-0.5 text-xs font-bold">
                        <button
                          type="button"
                          onClick={() => setCompressTargetUnit('MB')}
                          className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                            compressTargetUnit === 'MB'
                              ? 'bg-[#1B2740] text-white'
                              : 'text-[#6B7280] hover:text-[#1B2740]'
                          }`}
                        >
                          MB
                        </button>
                        <button
                          type="button"
                          onClick={() => setCompressTargetUnit('KB')}
                          className={`px-3 py-1.5 rounded-md transition-colors cursor-pointer ${
                            compressTargetUnit === 'KB'
                              ? 'bg-[#1B2740] text-white'
                              : 'text-[#6B7280] hover:text-[#1B2740]'
                          }`}
                        >
                          KB
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Size Overview Card */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    <div className="bg-[#F6F6F4] p-2.5 rounded-xl border border-[#E8E8E6]">
                      <span className="text-[10px] text-[#6B7280] uppercase block font-ibm-mono">Original Size</span>
                      <span className="font-bold text-[#1B2740] text-sm font-ibm-mono">
                        {pdfBuffer ? formatFileSize(pdfBuffer.byteLength) : '0 KB'}
                      </span>
                    </div>
                    <div className="bg-[#F6F6F4] p-2.5 rounded-xl border border-[#E8E8E6]">
                      <span className="text-[10px] text-[#6B7280] uppercase block font-ibm-mono">Target Size</span>
                      <span className="font-bold text-[#C4432E] text-sm font-ibm-mono">
                        ≤ {compressTargetValue || '0'} {compressTargetUnit}
                      </span>
                    </div>
                    <div className="bg-[#F6F6F4] p-2.5 rounded-xl border border-[#E8E8E6] col-span-2 sm:col-span-1">
                      <span className="text-[10px] text-[#6B7280] uppercase block font-ibm-mono">Req. Reduction</span>
                      <span className="font-bold text-emerald-700 text-sm font-ibm-mono">
                        {pdfBuffer && parseFloat(compressTargetValue) > 0
                          ? (() => {
                              const tBytes =
                                parseFloat(compressTargetValue) *
                                (compressTargetUnit === 'MB' ? 1024 * 1024 : 1024);
                              if (pdfBuffer.byteLength <= tBytes) return '0% (Met)';
                              const pct = Math.round(
                                ((pdfBuffer.byteLength - tBytes) / pdfBuffer.byteLength) * 100
                              );
                              return `~${pct}%`;
                            })()
                          : '0%'}
                      </span>
                    </div>
                  </div>

                  {/* Active Processing / Iteration Card */}
                  {processing && compressProgress && (
                    <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-xl space-y-2.5 animate-pulse">
                      <div className="flex justify-between items-center text-xs font-bold text-blue-900">
                        <span className="flex items-center space-x-1.5">
                          <Loader2 size={14} className="animate-spin text-blue-600" />
                          <span>Optimizing Iteration {compressProgress.iteration} of {compressProgress.totalIterations}</span>
                        </span>
                        <span className="bg-blue-600 text-white px-2 py-0.5 rounded text-[10px] font-mono font-bold">
                          {compressProgress.percent}%
                        </span>
                      </div>

                      {/* Progress Bar */}
                      <div className="w-full h-2 bg-blue-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600 transition-all duration-200 rounded-full"
                          style={{ width: `${Math.max(5, Math.min(100, compressProgress.percent))}%` }}
                        />
                      </div>

                      <div className="flex justify-between items-center text-[11px] text-blue-800">
                        <span className="truncate max-w-[70%] font-medium">{compressProgress.stage}</span>
                        <button
                          type="button"
                          onClick={() => {
                            compressCancelRef.current = true;
                            setProcessing(false);
                            setCompressProgress(null);
                          }}
                          className="px-2 py-0.5 bg-white hover:bg-red-50 border border-red-200 text-red-600 hover:text-red-700 rounded text-[10px] font-bold cursor-pointer transition-colors shadow-2xs"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Result Card (when available) */}
                  {compressTargetResult && (
                    <div className={`p-4 rounded-xl border space-y-3 ${
                      compressTargetResult.targetAchieved
                        ? 'bg-emerald-50/70 border-emerald-200'
                        : 'bg-amber-50/70 border-amber-200'
                    }`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {compressTargetResult.targetAchieved ? (
                            <CheckCircle2 size={18} className="text-emerald-600 shrink-0" />
                          ) : (
                            <AlertTriangle size={18} className="text-amber-600 shrink-0" />
                          )}
                          <span className={`text-xs font-bold ${
                            compressTargetResult.targetAchieved ? 'text-emerald-900' : 'text-amber-900'
                          }`}>
                            {compressTargetResult.targetAchieved
                              ? 'Target Maximum Size Achieved'
                              : `Best Achievable Size: ${formatFileSize(compressTargetResult.bestAchievableSize)}`}
                          </span>
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded font-ibm-mono ${
                          compressTargetResult.targetAchieved
                            ? 'bg-emerald-600 text-white'
                            : 'bg-amber-600 text-white'
                        }`}>
                          {compressTargetResult.reductionPercentage}% Reduction
                        </span>
                      </div>

                      {/* Metrics 4-Box Grid */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-ibm-mono">
                        <div className="bg-white p-2 rounded-lg border border-[#E8E8E6]">
                          <span className="text-[9px] text-[#6B7280] uppercase block">Original Size</span>
                          <span className="font-bold text-[#1B2740]">
                            {formatFileSize(compressTargetResult.originalSize)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded-lg border border-[#E8E8E6]">
                          <span className="text-[9px] text-[#6B7280] uppercase block">Target Size</span>
                          <span className="font-bold text-[#C4432E]">
                            ≤ {formatFileSize(compressTargetResult.targetSize)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded-lg border border-[#E8E8E6]">
                          <span className="text-[9px] text-[#6B7280] uppercase block">Final Size</span>
                          <span className={`font-bold ${compressTargetResult.targetAchieved ? 'text-emerald-700' : 'text-amber-700'}`}>
                            {formatFileSize(compressTargetResult.finalSize)}
                          </span>
                        </div>
                        <div className="bg-white p-2 rounded-lg border border-[#E8E8E6]">
                          <span className="text-[9px] text-[#6B7280] uppercase block">Iterations</span>
                          <span className="font-bold text-[#1B2740]">
                            {compressTargetResult.iterationsCount} tested
                          </span>
                        </div>
                      </div>

                      {/* Quality & Status Description */}
                      <div className="text-xs space-y-1">
                        <p className={`font-semibold ${compressTargetResult.targetAchieved ? 'text-emerald-800' : 'text-amber-800'}`}>
                          Quality Status: {compressTargetResult.qualityDescription}
                        </p>
                        <p className="text-[11px] text-[#6B7280] leading-relaxed">
                          {compressTargetResult.statusMessage}
                        </p>
                      </div>

                      {/* Quick Download / Export Action */}
                      <div className="pt-1 flex items-center justify-end space-x-2">
                        <button
                          type="button"
                          onClick={() => {
                            const base = (pdfFileName || 'document').replace(/\.pdf$/i, '');
                            downloadPdfBytes(compressTargetResult.bytes, `${base}_target_${compressTargetValue}${compressTargetUnit}.pdf`);
                          }}
                          className="px-3 py-1.5 bg-white hover:bg-gray-50 border border-[#E8E8E6] text-[#1B2740] rounded-lg text-xs font-bold transition-colors shadow-2xs flex items-center space-x-1.5 cursor-pointer"
                        >
                          <Download size={13} className="text-[#C4432E]" />
                          <span>Download PDF File</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* NORMAL COMPRESSION MODE (Original Presets & Slider) */}
              {compressMode === 'normal' && (
                <div className="space-y-4">
                  {/* Compression Presets */}
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-[#1B2740] uppercase font-ibm-mono block">
                      Presets
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {[
                        { label: 'Low', ratio: 20, desc: 'High Quality (~20% off)' },
                        { label: 'Balanced', ratio: 50, desc: 'Recommended (~50% off)' },
                        { label: 'Extreme', ratio: 75, desc: 'Smallest Size (~75% off)' },
                      ].map((preset) => (
                        <button
                          key={preset.ratio}
                          type="button"
                          onClick={() => setCompressRatio(preset.ratio)}
                          className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                            compressRatio === preset.ratio
                              ? 'bg-[#C4432E] border-[#C4432E] text-white font-bold shadow-md scale-102'
                              : 'bg-[#F6F6F4] border-[#E8E8E6] text-[#1B2740] hover:border-[#C4432E]'
                          }`}
                        >
                          <div className="text-xs font-bold">{preset.label}</div>
                          <div
                            className={`text-[10px] mt-0.5 ${
                              compressRatio === preset.ratio ? 'text-white/80' : 'text-[#6B7280]'
                            }`}
                          >
                            {preset.desc}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Custom Slider */}
                  <div className="space-y-2 bg-[#F6F6F4] p-3.5 rounded-xl border border-[#E8E8E6]">
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-semibold text-[#1B2740] flex items-center space-x-1.5">
                        <Sliders size={14} className="text-[#C4432E]" />
                        <span>Compression Ratio</span>
                      </span>
                      <span className="text-xs font-bold font-ibm-mono text-[#C4432E] bg-white px-2 py-0.5 rounded border border-[#E8E8E6]">
                        {compressRatio}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min={10}
                      max={80}
                      step={5}
                      value={compressRatio}
                      onChange={(e) => setCompressRatio(parseInt(e.target.value, 10))}
                      className="w-full accent-[#C4432E] cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-[#6B7280] font-ibm-mono">
                      <span>10% (Light)</span>
                      <span>50% (Standard)</span>
                      <span>80% (Maximum)</span>
                    </div>
                  </div>

                  {/* Live Size Preview Box */}
                  <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2">
                    <div className="flex justify-between items-center text-xs font-bold text-emerald-900">
                      <span className="flex items-center space-x-1">
                        <Sparkles size={14} className="text-emerald-600" />
                        <span>Live Size Estimate</span>
                      </span>
                      <span className="bg-emerald-600 text-white px-2 py-0.5 rounded-md font-mono text-[10px] font-bold">
                        ~{compressRatio}% Target Reduction
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs font-ibm-mono">
                      <div className="bg-white p-2.5 rounded-lg border border-emerald-100 shadow-2xs">
                        <span className="text-[10px] text-gray-500 uppercase block">Current PDF Size</span>
                        <span className="font-bold text-[#1B2740] text-sm">
                          {pdfBuffer
                            ? pdfBuffer.byteLength >= 1024 * 1024
                              ? `${(pdfBuffer.byteLength / (1024 * 1024)).toFixed(2)} MB`
                              : `${(pdfBuffer.byteLength / 1024).toFixed(1)} KB`
                            : '0 KB'}
                        </span>
                      </div>
                      <div className="bg-white p-2.5 rounded-lg border border-emerald-100 shadow-2xs">
                        <span className="text-[10px] text-gray-500 uppercase block">Est. Compressed</span>
                        <span className="font-bold text-emerald-700 text-sm">
                          {pdfBuffer
                            ? (() => {
                                const estBytes = pdfBuffer.byteLength * (1 - compressRatio / 100);
                                return estBytes >= 1024 * 1024
                                  ? `${(estBytes / (1024 * 1024)).toFixed(2)} MB`
                                  : `${(estBytes / 1024).toFixed(1)} KB`;
                              })()
                            : '0 KB'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 8. PAGE NUMBERS TOOL */}
          {tool.id === 'page-numbers' && (
            <div className="space-y-5 text-sm">
              {/* Auto Detected Banner */}
              <div className="p-3.5 bg-gradient-to-r from-[#1B2740] to-[#2C3E60] text-white rounded-xl shadow-xs space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 text-[#C4432E] font-bold text-xs uppercase tracking-wider font-ibm-mono">
                    <Hash size={16} />
                    <span>Auto Page Detection Active</span>
                  </div>
                  <span className="bg-[#C4432E] text-white text-[10px] font-bold font-ibm-mono px-2 py-0.5 rounded">
                    {pageCount} Pages Total
                  </span>
                </div>
                <p className="text-xs text-gray-300">
                  Document: <span className="text-white font-medium">{pdfFileName}</span> (Active view: Page {activePage} of {pageCount})
                </p>
              </div>

              {/* Position Grid */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-[#1B2740] font-ibm-mono uppercase">
                  Page Number Position
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'top-left', label: 'Top Left' },
                    { id: 'top-center', label: 'Top Center' },
                    { id: 'top-right', label: 'Top Right' },
                    { id: 'bottom-left', label: 'Bottom Left' },
                    { id: 'bottom-center', label: 'Bottom Center' },
                    { id: 'bottom-right', label: 'Bottom Right' },
                  ].map((pos) => (
                    <button
                      key={pos.id}
                      type="button"
                      onClick={() => setPnPosition(pos.id as any)}
                      className={`p-2.5 rounded-lg border text-xs font-medium transition-all cursor-pointer flex flex-col items-center justify-center space-y-1 ${
                        pnPosition === pos.id
                          ? 'bg-[#1B2740] border-[#1B2740] text-white font-bold shadow-xs'
                          : 'bg-[#F6F6F4] border-[#E8E8E6] text-[#1B2740] hover:bg-white hover:border-[#C4432E]'
                      }`}
                    >
                      <span>{pos.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Numbering Format */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-[#1B2740] font-ibm-mono uppercase">
                  Page Number Format
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { id: 'page_x_of_n', label: `Page 1 of ${pageCount}`, desc: 'Standard Formal' },
                    { id: 'x_slash_n', label: `1 / ${pageCount}`, desc: 'Compact Ratio' },
                    { id: 'just_x', label: `1`, desc: 'Minimalist Number' },
                    { id: 'dash_x_dash', label: `- 1 -`, desc: 'Decorated Hyphen' },
                  ].map((fmt) => (
                    <button
                      key={fmt.id}
                      type="button"
                      onClick={() => setPnFormat(fmt.id as any)}
                      className={`p-2.5 rounded-lg border text-left transition-all cursor-pointer ${
                        pnFormat === fmt.id
                          ? 'bg-[#C4432E]/10 border-[#C4432E] text-[#1B2740] font-bold shadow-2xs'
                          : 'bg-[#F6F6F4] border-[#E8E8E6] text-[#1B2740] hover:bg-white'
                      }`}
                    >
                      <span className="block text-xs font-bold text-[#C4432E]">{fmt.label}</span>
                      <span className="block text-[10px] text-[#6B7280]">{fmt.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Style Controls (Font Size & Color) */}
              <div className="grid grid-cols-2 gap-4 pt-1">
                {/* Font Size */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-[#1B2740] font-ibm-mono uppercase">
                    Font Size ({pnFontSize}pt)
                  </label>
                  <select
                    value={pnFontSize}
                    onChange={(e) => setPnFontSize(Number(e.target.value))}
                    className="w-full bg-[#F6F6F4] border border-[#E8E8E6] rounded-lg text-xs px-3 py-2 font-medium focus:outline-none focus:border-[#C4432E]"
                  >
                    <option value={8}>8 pt (Small)</option>
                    <option value={10}>10 pt (Standard)</option>
                    <option value={12}>12 pt (Medium)</option>
                    <option value={14}>14 pt (Large)</option>
                    <option value={16}>16 pt (Extra Large)</option>
                  </select>
                </div>

                {/* Color Selector */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-bold text-[#1B2740] font-ibm-mono uppercase">
                    Text Color
                  </label>
                  <div className="flex items-center space-x-1.5 pt-1">
                    {['#1B2740', '#C4432E', '#2563EB', '#059669', '#000000', '#6B7280'].map((c) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setPnColor(c)}
                        className={`w-6 h-6 rounded-full border border-black/10 transition-transform cursor-pointer ${
                          pnColor === c ? 'scale-125 ring-2 ring-offset-1 ring-[#C4432E]' : 'hover:scale-110'
                        }`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Advanced Controls (Start Page & Cover Page Option) */}
              <div className="p-3 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6] space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="block text-xs font-bold text-[#1B2740]">Skip Cover Page</span>
                    <span className="block text-[10px] text-[#6B7280]">Do not insert page number on Page 1</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={pnSkipFirstPage}
                    onChange={(e) => setPnSkipFirstPage(e.target.checked)}
                    className="w-4 h-4 accent-[#C4432E] rounded cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#E8E8E6]">
                  <div>
                    <span className="block text-xs font-bold text-[#1B2740]">Starting Number</span>
                    <span className="block text-[10px] text-[#6B7280]">First page display index</span>
                  </div>
                  <input
                    type="number"
                    min={1}
                    max={999}
                    value={pnStartPage}
                    onChange={(e) => setPnStartPage(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="w-16 bg-white border border-[#E8E8E6] rounded-md text-xs px-2 py-1 text-center font-bold"
                  />
                </div>
              </div>

              {/* Live Sample Preview Badge */}
              <div className="p-3 bg-white border border-[#E8E8E6] rounded-xl flex items-center justify-between">
                <span className="text-xs text-[#6B7280] font-ibm-mono">Live Preview Sample:</span>
                <span
                  className="font-bold px-3 py-1 rounded bg-[#F6F6F4] border border-[#E8E8E6]"
                  style={{ color: pnColor, fontSize: `${Math.max(10, pnFontSize)}px` }}
                >
                  {pnFormat === 'page_x_of_n'
                    ? `Page ${pnStartPage} of ${pageCount}`
                    : pnFormat === 'x_slash_n'
                    ? `${pnStartPage} / ${pageCount}`
                    : pnFormat === 'just_x'
                    ? `${pnStartPage}`
                    : `- ${pnStartPage} -`}
                </span>
              </div>
            </div>
          )}

          {/* 9. DUPLICATE PAGE DETECTOR TOOL */}
          {tool.id === 'duplicate-detector' && (
            <div className="space-y-4 text-sm">
              {/* Scanning State */}
              {dupScanning && (
                <div className="p-8 text-center bg-[#F6F6F4] rounded-2xl border border-[#E8E8E6] space-y-4">
                  <div className="w-12 h-12 border-4 border-[#C4432E] border-t-transparent rounded-full animate-spin mx-auto" />
                  <div>
                    <h4 className="font-bold text-[#1B2740] text-base">Scanning Document Pages...</h4>
                    <p className="text-xs text-[#6B7280] mt-1 font-ibm-mono">
                      Analyzing page {dupScanProgress?.current || 0} of {dupScanProgress?.total || pageCount} for duplicates
                    </p>
                  </div>
                  <div className="w-full bg-[#E8E8E6] h-2 rounded-full overflow-hidden max-w-xs mx-auto">
                    <div
                      className="bg-[#C4432E] h-full transition-all duration-200"
                      style={{
                        width: `${Math.round(((dupScanProgress?.current || 0) / (dupScanProgress?.total || 1)) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              )}

              {/* Scan Completed: No Duplicates */}
              {!dupScanning && dupResult && !dupResult.hasDuplicates && (
                <div className="p-6 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-2xl text-center space-y-3">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 size={28} />
                  </div>
                  <div>
                    <h4 className="font-bold text-base text-emerald-900">No Duplicate Pages Found!</h4>
                    <p className="text-xs text-emerald-700 mt-1">
                      Your document was thoroughly scanned across all {pageCount} page(s) and contains no duplicate content.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={startDuplicateScan}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-white border border-emerald-300 text-xs font-bold text-emerald-800 rounded-lg hover:bg-emerald-100 transition-colors cursor-pointer"
                  >
                    <RefreshCcw size={14} />
                    <span>Rescan Document</span>
                  </button>
                </div>
              )}

              {/* Scan Completed: Duplicates Found */}
              {!dupScanning && dupResult && dupResult.hasDuplicates && (
                <div className="space-y-4">
                  {/* Summary Banner */}
                  <div className="p-3.5 bg-gradient-to-r from-[#1B2740] to-[#2C3E60] text-white rounded-xl shadow-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-[#C4432E] font-bold text-xs uppercase tracking-wider font-ibm-mono">
                        <CopyX size={16} />
                        <span>Duplicates Detected</span>
                      </div>
                      <span className="bg-[#C4432E] text-white text-[10px] font-bold font-ibm-mono px-2.5 py-0.5 rounded-full shadow-xs">
                        {dupResult.totalDuplicatesCount} Duplicate(s) Found
                      </span>
                    </div>
                    <p className="text-xs text-gray-200">
                      Identified <span className="font-bold text-white">{dupResult.totalDuplicatesCount} duplicate page(s)</span> across{' '}
                      <span className="font-bold text-white">{dupResult.groups.length} group(s)</span>. Uncheck pages if you want to keep them.
                    </p>
                    <div className="flex items-center justify-between pt-2 border-t border-white/10 text-xs">
                      <button
                        type="button"
                        onClick={() => {
                          if (dupSelectedToRemove.size === dupResult.totalDuplicatesCount) {
                            setDupSelectedToRemove(new Set());
                          } else {
                            setDupSelectedToRemove(new Set(dupResult.duplicatePageNumbers));
                          }
                        }}
                        className="text-xs font-medium text-gray-300 hover:text-white underline flex items-center space-x-1 cursor-pointer"
                      >
                        {dupSelectedToRemove.size === dupResult.totalDuplicatesCount ? (
                          <>
                            <Square size={13} />
                            <span>Deselect All</span>
                          </>
                        ) : (
                          <>
                            <CheckSquare size={13} />
                            <span>Select All Duplicates ({dupResult.totalDuplicatesCount})</span>
                          </>
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={startDuplicateScan}
                        className="text-xs text-gray-300 hover:text-white flex items-center space-x-1 cursor-pointer"
                      >
                        <RefreshCcw size={12} />
                        <span>Rescan</span>
                      </button>
                    </div>
                  </div>

                  {/* Groups List */}
                  <div className="space-y-3 max-h-[340px] overflow-y-auto pr-1">
                    {dupResult.groups.map((group, gIdx) => (
                      <div
                        key={gIdx}
                        className="p-3 bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl space-y-2.5 shadow-2xs"
                      >
                        {/* Group Header */}
                        <div className="flex items-center justify-between border-b border-[#E8E8E6] pb-2">
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-bold text-[#1B2740] font-ibm-mono">
                              Group {gIdx + 1}: Original Page {group.originalPage}
                            </span>
                            <span className="text-[10px] bg-[#1B2740]/10 text-[#1B2740] px-2 py-0.5 rounded font-bold uppercase">
                              {group.matchType === 'exact_text'
                                ? 'Exact Text Match'
                                : group.matchType === 'visual_layout'
                                ? 'Visual Layout Match'
                                : 'Identical Content'}
                            </span>
                          </div>
                          <span className="text-xs font-bold text-[#C4432E]">
                            {group.duplicates.length} Duplicate(s)
                          </span>
                        </div>

                        {/* Page Cards Grid */}
                        <div className="grid grid-cols-2 gap-2">
                          {/* Original Page Card */}
                          <div className="p-2 bg-white rounded-lg border-2 border-blue-200 shadow-2xs flex flex-col items-center space-y-1.5">
                            <span className="text-[10px] font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded">
                              Original (Page {group.originalPage})
                            </span>
                            {group.dataUrl ? (
                              <img
                                src={group.dataUrl}
                                alt={`Page ${group.originalPage}`}
                                className="w-20 h-28 object-contain rounded border border-gray-200 shadow-2xs"
                              />
                            ) : (
                              <div className="w-20 h-28 bg-gray-100 rounded flex items-center justify-center text-xs text-gray-400">
                                Page {group.originalPage}
                              </div>
                            )}
                            <span className="text-[10px] text-gray-500 font-medium">Keep (Original)</span>
                          </div>

                          {/* Duplicate Pages */}
                          {group.duplicates.map((dupPage) => {
                            const isSelected = dupSelectedToRemove.has(dupPage);
                            const thumb = group.duplicateThumbnails?.[dupPage] || group.dataUrl;

                            return (
                              <div
                                key={dupPage}
                                onClick={() => {
                                  const next = new Set(dupSelectedToRemove);
                                  if (next.has(dupPage)) {
                                    next.delete(dupPage);
                                  } else {
                                    next.add(dupPage);
                                  }
                                  setDupSelectedToRemove(next);
                                }}
                                className={`p-2 rounded-lg border-2 transition-all cursor-pointer flex flex-col items-center space-y-1.5 ${
                                  isSelected
                                    ? 'bg-[#C4432E]/5 border-[#C4432E] shadow-xs'
                                    : 'bg-white border-gray-200 hover:border-gray-400'
                                }`}
                              >
                                <div className="flex items-center justify-between w-full px-1">
                                  <span
                                    className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                                      isSelected ? 'bg-[#C4432E] text-white' : 'bg-gray-100 text-gray-700'
                                    }`}
                                  >
                                    Page {dupPage}
                                  </span>
                                  <input
                                    type="checkbox"
                                    checked={isSelected}
                                    onChange={() => {}} // handled by parent onClick
                                    className="w-4 h-4 accent-[#C4432E] rounded cursor-pointer"
                                  />
                                </div>

                                {thumb ? (
                                  <img
                                    src={thumb}
                                    alt={`Page ${dupPage}`}
                                    className="w-20 h-28 object-contain rounded border border-gray-200 shadow-2xs"
                                  />
                                ) : (
                                  <div className="w-20 h-28 bg-gray-100 rounded flex items-center justify-center text-xs text-gray-400">
                                    Page {dupPage}
                                  </div>
                                )}

                                <span
                                  className={`text-[10px] font-bold ${
                                    isSelected ? 'text-[#C4432E]' : 'text-gray-500'
                                  }`}
                                >
                                  {isSelected ? 'Remove Duplicate' : 'Keep Page'}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 10. BLANK PAGE DETECTOR TOOL */}
          {tool.id === 'blank-detector' && (
            <div className="space-y-4 text-sm">
              {/* Sensitivity Selector Header */}
              <div className="p-3 bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl flex items-center justify-between gap-2">
                <div className="flex items-center space-x-1.5 text-xs text-[#1B2740] font-bold">
                  <Sliders size={14} className="text-[#C4432E]" />
                  <span>Scan Sensitivity:</span>
                </div>
                <div className="flex items-center space-x-1 bg-white p-1 rounded-lg border border-[#E8E8E6]">
                  {(
                    [
                      { id: 'strict', label: 'Strict (0.1%)' },
                      { id: 'standard', label: 'Standard (0.25%)' },
                      { id: 'aggressive', label: 'Aggressive (0.5%)' },
                    ] as const
                  ).map((sens) => (
                    <button
                      key={sens.id}
                      type="button"
                      onClick={() => {
                        setBlankSensitivity(sens.id);
                        startBlankScan(sens.id);
                      }}
                      className={`px-2.5 py-1 text-[11px] font-bold rounded-md transition-all cursor-pointer ${
                        blankSensitivity === sens.id
                          ? 'bg-[#1B2740] text-white shadow-xs'
                          : 'text-[#6B7280] hover:text-[#1B2740] hover:bg-gray-100'
                      }`}
                    >
                      {sens.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Scanning State */}
              {blankScanning && (
                <div className="p-8 text-center bg-[#F6F6F4] rounded-2xl border border-[#E8E8E6] space-y-4">
                  <div className="w-12 h-12 border-4 border-[#C4432E] border-t-transparent rounded-full animate-spin mx-auto" />
                  <div>
                    <h4 className="font-bold text-[#1B2740] text-base">Scanning for Blank Pages...</h4>
                    <p className="text-xs text-[#6B7280] mt-1 font-ibm-mono">
                      Analyzing page {blankScanProgress?.current || 0} of {blankScanProgress?.total || pageCount} with pixel density check
                    </p>
                  </div>
                  <div className="w-full bg-[#E8E8E6] h-2 rounded-full overflow-hidden max-w-xs mx-auto">
                    <div
                      className="bg-[#C4432E] h-full transition-all duration-200"
                      style={{
                        width: `${Math.round(((blankScanProgress?.current || 0) / (blankScanProgress?.total || 1)) * 100)}%`,
                      }}
                    />
                  </div>
                </div>
              )}

              {/* Scan Completed: No Blank Pages */}
              {!blankScanning && blankResult && !blankResult.hasBlankPages && (
                <div className="p-6 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-2xl text-center space-y-3">
                  <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 size={28} />
                  </div>
                  <div>
                    <h4 className="font-bold text-base text-emerald-900">No Blank Pages Detected!</h4>
                    <p className="text-xs text-emerald-700 mt-1">
                      All {pageCount} page(s) contain meaningful text or visual graphical content.
                    </p>
                  </div>
                  <div className="flex items-center justify-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        setBlankSensitivity('aggressive');
                        startBlankScan('aggressive');
                      }}
                      className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-emerald-700 text-white text-xs font-bold rounded-lg hover:bg-emerald-800 transition-colors cursor-pointer shadow-xs"
                    >
                      <Sliders size={13} />
                      <span>Try Aggressive Scan (0.5%)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => startBlankScan()}
                      className="inline-flex items-center space-x-1 px-3 py-1.5 bg-white border border-emerald-300 text-xs font-bold text-emerald-800 rounded-lg hover:bg-emerald-100 transition-colors cursor-pointer"
                    >
                      <RefreshCcw size={13} />
                      <span>Rescan</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Scan Completed: Blank Pages Found */}
              {!blankScanning && blankResult && blankResult.hasBlankPages && (
                <div className="space-y-4">
                  {/* Summary Banner */}
                  <div className="p-3.5 bg-gradient-to-r from-[#1B2740] to-[#2C3E60] text-white rounded-xl shadow-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-[#C4432E] font-bold text-xs uppercase tracking-wider font-ibm-mono">
                        <FileX size={16} />
                        <span>Blank Pages Detected</span>
                      </div>
                      <span className="bg-[#C4432E] text-white text-[10px] font-bold font-ibm-mono px-2.5 py-0.5 rounded-full shadow-xs">
                        {blankResult.totalBlankCount} Blank Page(s) Found
                      </span>
                    </div>
                    <p className="text-xs text-gray-200">
                      Found <span className="font-bold text-white">{blankResult.totalBlankCount} blank page(s)</span> out of {pageCount} total pages. Uncheck any page you wish to retain.
                    </p>
                    <div className="flex items-center justify-between pt-2 border-t border-white/10 text-xs">
                      <button
                        type="button"
                        onClick={() => {
                          if (blankSelectedToRemove.size === blankResult.totalBlankCount) {
                            setBlankSelectedToRemove(new Set());
                          } else {
                            setBlankSelectedToRemove(new Set(blankResult.blankPageNumbers));
                          }
                        }}
                        className="text-xs font-medium text-gray-300 hover:text-white underline flex items-center space-x-1 cursor-pointer"
                      >
                        {blankSelectedToRemove.size === blankResult.totalBlankCount ? (
                          <>
                            <Square size={13} />
                            <span>Deselect All</span>
                          </>
                        ) : (
                          <>
                            <CheckSquare size={13} />
                            <span>Select All Blank Pages ({blankResult.totalBlankCount})</span>
                          </>
                        )}
                      </button>
                      <button
                        type="button"
                        onClick={() => startBlankScan()}
                        className="text-xs text-gray-300 hover:text-white flex items-center space-x-1 cursor-pointer"
                      >
                        <RefreshCcw size={12} />
                        <span>Rescan</span>
                      </button>
                    </div>
                  </div>

                  {/* Blank Pages Grid */}
                  <div className="grid grid-cols-3 gap-2.5 max-h-[300px] overflow-y-auto pr-1">
                    {blankResult.blankPages.map((pageInfo) => {
                      const isSelected = blankSelectedToRemove.has(pageInfo.pageNumber);

                      return (
                        <div
                          key={pageInfo.pageNumber}
                          onClick={() => {
                            const next = new Set(blankSelectedToRemove);
                            if (next.has(pageInfo.pageNumber)) {
                              next.delete(pageInfo.pageNumber);
                            } else {
                              next.add(pageInfo.pageNumber);
                            }
                            setBlankSelectedToRemove(next);
                          }}
                          className={`p-2 rounded-xl border-2 transition-all cursor-pointer flex flex-col items-center space-y-1.5 ${
                            isSelected
                              ? 'bg-[#C4432E]/5 border-[#C4432E] shadow-xs'
                              : 'bg-white border-gray-200 hover:border-gray-400'
                          }`}
                        >
                          <div className="flex items-center justify-between w-full px-0.5">
                            <span
                              className={`text-[10px] font-bold px-1.5 py-0.5 rounded font-ibm-mono ${
                                isSelected ? 'bg-[#C4432E] text-white' : 'bg-gray-100 text-gray-700'
                              }`}
                            >
                              Page {pageInfo.pageNumber}
                            </span>
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => {}} // handled by parent onClick
                              className="w-4 h-4 accent-[#C4432E] rounded cursor-pointer"
                            />
                          </div>

                          {pageInfo.dataUrl ? (
                            <div className="relative group">
                              <img
                                src={pageInfo.dataUrl}
                                alt={`Blank Page ${pageInfo.pageNumber}`}
                                className="w-20 h-28 object-contain rounded border border-gray-200 shadow-2xs bg-white"
                              />
                              <div className="absolute inset-0 bg-gray-900/10 rounded pointer-events-none flex items-center justify-center">
                                <span className="text-[9px] font-bold bg-white/90 text-gray-700 px-1.5 py-0.5 rounded shadow-2xs">
                                  EMPTY
                                </span>
                              </div>
                            </div>
                          ) : (
                            <div className="w-20 h-28 bg-gray-100 rounded flex items-center justify-center text-xs text-gray-400">
                              Page {pageInfo.pageNumber}
                            </div>
                          )}

                          <div className="text-center w-full">
                            <span
                              className={`text-[10px] font-bold block ${
                                isSelected ? 'text-[#C4432E]' : 'text-gray-500'
                              }`}
                            >
                              {isSelected ? 'Remove Page' : 'Keep Page'}
                            </span>
                            <span className="text-[9px] text-gray-400 font-ibm-mono block">
                              Density: {pageInfo.nonWhitePercentage}%
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 11. PAGE SIZE NORMALIZER TOOL */}
          {tool.id === 'page-size-normalizer' && (
            <div className="space-y-4 text-sm">
              {/* Current Status Info Banner */}
              <div className="p-3.5 bg-[#1B2740] text-white rounded-xl shadow-xs flex items-center justify-between">
                <div className="space-y-0.5">
                  <div className="flex items-center space-x-2">
                    <Scaling size={16} className="text-[#C4432E]" />
                    <span className="font-bold text-xs uppercase font-ibm-mono tracking-wider">
                      Page Size Analysis
                    </span>
                  </div>
                  <p className="text-xs text-gray-300">
                    {psSummary ? (
                      psSummary.isUniform ? (
                        <span className="text-emerald-400 font-semibold">
                          Uniform document ({psSummary.totalPages} pages are all {psSummary.pageSizes[0]?.label || 'same size'}).
                        </span>
                      ) : (
                        <span className="text-amber-300 font-semibold">
                          Mixed page sizes detected ({psSummary.uniqueSizesCount} unique sizes across {psSummary.totalPages} pages).
                        </span>
                      )
                    ) : (
                      `Analyzing ${pageCount} page(s)...`
                    )}
                  </p>
                </div>
                {psSummary && (
                  <div className="text-right">
                    <span className="text-[10px] text-gray-400 block uppercase font-ibm-mono">Page 1 Size</span>
                    <span className="text-xs font-bold font-ibm-mono text-white bg-white/10 px-2 py-0.5 rounded border border-white/10">
                      {Math.round(psSummary.firstPageWidthPt)} x {Math.round(psSummary.firstPageHeightPt)} pt
                    </span>
                  </div>
                )}
              </div>

              {/* Target Page Size Selector Grid */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-[#1B2740] block">
                  Select Target Page Size (Applies to ALL {pageCount} pages):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-[220px] overflow-y-auto pr-1">
                  {[
                    { id: 'A4', label: 'A4', sub: '210 x 297 mm', pt: '595 x 842 pt' },
                    { id: 'LETTER', label: 'US Letter', sub: '8.5 x 11 in', pt: '612 x 792 pt' },
                    { id: 'LEGAL', label: 'US Legal', sub: '8.5 x 14 in', pt: '612 x 1008 pt' },
                    { id: 'A3', label: 'A3', sub: '297 x 420 mm', pt: '842 x 1191 pt' },
                    { id: 'A5', label: 'A5', sub: '148 x 210 mm', pt: '420 x 595 pt' },
                    { id: 'TABLOID', label: 'Tabloid / Ledger', sub: '11 x 17 in', pt: '792 x 1224 pt' },
                    { id: 'EXECUTIVE', label: 'Executive', sub: '7.25 x 10.5 in', pt: '522 x 756 pt' },
                    {
                      id: 'MATCH_PAGE_1',
                      label: 'Match Page 1',
                      sub: 'Use Page 1 size',
                      pt: `${Math.round(psSummary?.firstPageWidthPt || 595)} x ${Math.round(psSummary?.firstPageHeightPt || 842)} pt`,
                    },
                    { id: 'CUSTOM', label: 'Custom Size', sub: 'User defined', pt: 'Specify dimensions' },
                  ].map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => setPsPreset(preset.id as any)}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        psPreset === preset.id
                          ? 'bg-[#C4432E]/10 border-[#C4432E] text-[#1B2740] shadow-2xs font-semibold'
                          : 'bg-white border-[#E8E8E6] hover:border-gray-400 text-gray-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-[#1B2740]">{preset.label}</span>
                        {psPreset === preset.id && <span className="w-2 h-2 rounded-full bg-[#C4432E]" />}
                      </div>
                      <span className="text-[10px] text-gray-500 font-ibm-mono block mt-1">{preset.sub}</span>
                      <span className="text-[9px] text-gray-400 font-ibm-mono block">{preset.pt}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Size Input Fields if CUSTOM selected */}
              {psPreset === 'CUSTOM' && (
                <div className="p-3 bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-[#1B2740] block mb-1">
                      Target Width (points / pt):
                    </label>
                    <input
                      type="number"
                      min="72"
                      max="3000"
                      value={psCustomWidthPt}
                      onChange={(e) => setPsCustomWidthPt(Number(e.target.value) || 595)}
                      className="w-full px-3 py-1.5 bg-white border border-[#E8E8E6] rounded-lg text-xs font-ibm-mono focus:border-[#C4432E] focus:outline-hidden"
                    />
                    <span className="text-[9px] text-gray-500 font-ibm-mono mt-0.5 block">
                      ≈ {(psCustomWidthPt / 72).toFixed(2)} in / {Math.round(psCustomWidthPt / 2.83465)} mm
                    </span>
                  </div>
                  <div>
                    <label className="text-[11px] font-bold text-[#1B2740] block mb-1">
                      Target Height (points / pt):
                    </label>
                    <input
                      type="number"
                      min="72"
                      max="3000"
                      value={psCustomHeightPt}
                      onChange={(e) => setPsCustomHeightPt(Number(e.target.value) || 842)}
                      className="w-full px-3 py-1.5 bg-white border border-[#E8E8E6] rounded-lg text-xs font-ibm-mono focus:border-[#C4432E] focus:outline-hidden"
                    />
                    <span className="text-[9px] text-gray-500 font-ibm-mono mt-0.5 block">
                      ≈ {(psCustomHeightPt / 72).toFixed(2)} in / {Math.round(psCustomHeightPt / 2.83465)} mm
                    </span>
                  </div>
                </div>
              )}

              {/* Orientation & Content Scale Controls Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Orientation Mode */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#1B2740] block">Page Orientation:</label>
                  <div className="grid grid-cols-3 gap-1 bg-white p-1 rounded-xl border border-[#E8E8E6]">
                    {[
                      { id: 'auto', label: 'Auto (Match)' },
                      { id: 'portrait', label: 'Portrait' },
                      { id: 'landscape', label: 'Landscape' },
                    ].map((mode) => (
                      <button
                        key={mode.id}
                        type="button"
                        onClick={() => setPsOrientation(mode.id as any)}
                        className={`py-1.5 px-2 text-[11px] font-bold rounded-lg transition-all cursor-pointer text-center ${
                          psOrientation === mode.id
                            ? 'bg-[#1B2740] text-white shadow-xs'
                            : 'text-[#6B7280] hover:bg-gray-100 hover:text-[#1B2740]'
                        }`}
                      >
                        {mode.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Content Fitting Mode */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-[#1B2740] block">Content Scaling Mode:</label>
                  <div className="grid grid-cols-3 gap-1 bg-white p-1 rounded-xl border border-[#E8E8E6]">
                    {[
                      { id: 'fit', label: 'Fit (Margins)' },
                      { id: 'fill', label: 'Fill Canvas' },
                      { id: 'stretch', label: 'Stretch' },
                    ].map((mode) => (
                      <button
                        key={mode.id}
                        type="button"
                        onClick={() => setPsScaleMode(mode.id as any)}
                        className={`py-1.5 px-2 text-[11px] font-bold rounded-lg transition-all cursor-pointer text-center ${
                          psScaleMode === mode.id
                            ? 'bg-[#C4432E] text-white shadow-xs'
                            : 'text-[#6B7280] hover:bg-gray-100 hover:text-[#1B2740]'
                        }`}
                      >
                        {mode.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* EDIT TEXT MODAL CONTENT */}
          {tool.id === 'edit-text' && (
            <div className="space-y-4 text-[#1B2740]">
              <div className="p-4 bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-[#C4432E]/10 text-[#C4432E] flex items-center justify-center shrink-0">
                  <FileEdit size={24} />
                </div>
                <div>
                  <h4 className="font-fraunces text-base font-semibold text-[#1B2740]">Interactive In-Place Text Editor</h4>
                  <p className="text-xs text-[#6B7280]">
                    Click directly on any existing text on your PDF page to edit words, numbers, or phrases in place.
                  </p>
                </div>
              </div>

              <div className="p-3 bg-white border border-[#E8E8E6] rounded-xl space-y-2 text-xs text-[#1B2740]">
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                  <span>Hover & tap any text item directly on your page canvas</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                  <span>Type your new text inside the inline input box</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                  <span>Click Apply (or press Enter) to erase old text and bake new text into the PDF</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    if (onLaunchEditTextMode) {
                      onLaunchEditTextMode();
                    }
                    onClose();
                  }}
                  className="w-full py-3.5 bg-[#C4432E] hover:bg-[#a83623] text-white font-semibold text-xs sm:text-sm rounded-xl red-glow shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
                >
                  <FileEdit size={16} />
                  <span>Start Editing Text Now</span>
                </button>
              </div>
            </div>
          )}

          {/* FIND & REPLACE TOOL CONTENT */}
          {tool.id === 'find-replace' && (
            <div className="space-y-4 text-[#1B2740]">
              <div className="p-4 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6] flex items-start space-x-3">
                <div className="p-2.5 bg-[#C4432E]/10 text-[#C4432E] rounded-lg shrink-0">
                  <Replace size={24} />
                </div>
                <div>
                  <h4 className="font-fraunces text-base font-semibold text-[#1B2740]">Interactive Find & Replace Engine</h4>
                  <p className="text-xs text-[#6B7280]">
                    Search for words, phrases, or numbers across your entire PDF document and replace single occurrences or all matches live in memory.
                  </p>
                </div>
              </div>

              <div className="p-3 bg-white border border-[#E8E8E6] rounded-xl space-y-2 text-xs text-[#1B2740]">
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                  <span>Search-as-you-type with Case Sensitive and Whole Word options</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                  <span>Live visual highlight rectangles over match locations in canvas preview</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                  <span>Replace single matches or Replace All with proportional text sizing and whiteout cover</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => {
                    if (onLaunchFindReplaceMode) {
                      onLaunchFindReplaceMode();
                    }
                    onClose();
                  }}
                  className="w-full py-3.5 bg-[#C4432E] hover:bg-[#a83623] text-white font-semibold text-xs sm:text-sm rounded-xl red-glow shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
                >
                  <Replace size={16} />
                  <span>Open Find & Replace Panel</span>
                </button>
              </div>
            </div>
          )}

          {/* REMOVE PASSWORD TOOL CONTENT */}
          {tool.id === 'remove-password' && (
            <div className="space-y-4 text-[#1B2740]">
              {removePwChecking ? (
                <div className="p-8 text-center space-y-3">
                  <div className="w-8 h-8 border-3 border-[#C4432E] border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="text-xs text-[#6B7280]">Inspecting PDF encryption status...</p>
                </div>
              ) : isDocEncryptedState ? (
                <div className="space-y-4">
                  <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 flex items-start space-x-3">
                    <div className="p-2.5 bg-amber-100 text-amber-700 rounded-lg shrink-0">
                      <Lock size={22} />
                    </div>
                    <div>
                      <h4 className="font-fraunces text-base font-semibold text-amber-900">Protected PDF Document</h4>
                      <p className="text-xs text-amber-700 mt-0.5">
                        This PDF is encrypted with a password. Enter the correct password below to unlock and permanently decrypt it in your browser.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-[#1B2740] uppercase font-ibm-mono block">
                      Document Password
                    </label>
                    <div className="relative">
                      <input
                        type={showRemovePwPassword ? 'text' : 'password'}
                        value={removePwPassword}
                        onChange={(e) => setRemovePwPassword(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleApplyAction();
                        }}
                        placeholder="Enter password..."
                        className="w-full bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl px-3.5 py-2.5 text-sm pr-10 focus:outline-none focus:border-[#C4432E] font-medium"
                      />
                      <button
                        type="button"
                        onClick={() => setShowRemovePwPassword(!showRemovePwPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6B7280] hover:text-[#1B2740] p-1 cursor-pointer"
                      >
                        {showRemovePwPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                      </button>
                    </div>
                  </div>

                  <div className="p-3 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6] text-xs text-[#6B7280] space-y-1">
                    <div className="flex items-center gap-2 text-emerald-700 font-medium">
                      <CheckCircle2 size={14} className="shrink-0" />
                      <span>Processed 100% locally in your browser memory</span>
                    </div>
                    <div className="flex items-center gap-2 text-[#1B2740]">
                      <CheckCircle2 size={14} className="text-emerald-600 shrink-0" />
                      <span>Removes both user and owner encryption when unlocked</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 flex items-start space-x-3">
                    <div className="p-2.5 bg-emerald-100 text-emerald-700 rounded-lg shrink-0">
                      <ShieldCheck size={24} />
                    </div>
                    <div>
                      <h4 className="font-fraunces text-base font-semibold text-emerald-900">Document is Unlocked & Unencrypted</h4>
                      <p className="text-xs text-emerald-800 mt-0.5 leading-relaxed">
                        This PDF has no active password restriction. All pages, content, and metadata are immediately accessible for editing and exporting.
                      </p>
                    </div>
                  </div>

                  <div className="p-3.5 bg-white border border-[#E8E8E6] rounded-xl space-y-2 text-xs text-[#1B2740]">
                    <div className="flex items-center gap-2 text-[#1B2740]">
                      <CheckCircle2 size={15} className="text-emerald-600 shrink-0" />
                      <span>Ready for all editing tools (watermark, split, compress, reorder)</span>
                    </div>
                    <div className="flex items-center gap-2 text-[#1B2740]">
                      <CheckCircle2 size={15} className="text-emerald-600 shrink-0" />
                      <span>All exported documents will be saved without encryption</span>
                    </div>
                    <div className="flex items-center gap-2 text-[#1B2740]">
                      <CheckCircle2 size={15} className="text-emerald-600 shrink-0" />
                      <span>Clicking the button below saves a clean unencrypted copy</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Action Footer (Hidden for E-Sign as ESignModalContent has its own action bar) */}
        {tool.id !== 'esign' && (
          <div className="px-6 py-4 bg-[#F6F6F4] border-t border-[#E8E8E6] flex justify-end items-center space-x-3 shrink-0">
            <button
              type="button"
              onClick={() => {
                if (tool.id === 'compress' && processing) {
                  compressCancelRef.current = true;
                  setProcessing(false);
                  setCompressProgress(null);
                } else {
                  onClose();
                }
              }}
              className="px-4 py-2 text-xs font-medium text-[#6B7280] hover:text-[#1B2740] hover:bg-white rounded-lg transition-colors cursor-pointer"
            >
              {tool.id === 'compress' && processing ? 'Stop / Cancel' : 'Cancel'}
            </button>
            <button
              type="button"
              onClick={handleApplyAction}
              disabled={
                processing ||
                dupScanning ||
                blankScanning ||
                (tool.id === 'remove-password' && isDocEncryptedState && !removePwPassword.trim()) ||
                (tool.id === 'extract-pages' && extractSelectedPages.length === 0) ||
                (tool.id === 'delete-pages' && (pageCount <= 1 || deleteSelectedPages.length === 0 || deleteSelectedPages.length >= pageCount)) ||
                (tool.id === 'duplicate-detector' && (!dupResult?.hasDuplicates || dupSelectedToRemove.size === 0)) ||
                (tool.id === 'blank-detector' && (!blankResult?.hasBlankPages || blankSelectedToRemove.size === 0))
              }
              className="px-5 py-2 bg-[#C4432E] hover:bg-[#a83522] text-white rounded-lg text-xs font-bold transition-all shadow-md disabled:opacity-50 cursor-pointer flex items-center space-x-2"
            >
              {processing ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>
                    {tool.id === 'compress' && compressMode === 'target'
                      ? 'Optimizing Iteration...'
                      : 'Processing...'}
                  </span>
                </>
              ) : (
                <span>
                  {tool.id === 'watermark'
                    ? 'Apply Watermark (Live Mode)'
                    : tool.id === 'add-image'
                    ? 'Place Image on PDF'
                    : tool.id === 'remove-password'
                    ? isDocEncryptedState
                      ? 'Unlock & Decrypt PDF'
                      : 'Save Unencrypted Copy'
                    : tool.id === 'extract-pages'
                    ? extractOutputFormat === 'separate'
                      ? `Extract & Download ${extractSelectedPages.length} Files`
                      : extractActionTarget === 'download'
                      ? `Extract & Download ${extractSelectedPages.length} Pages`
                      : `Extract ${extractSelectedPages.length} Page(s)`
                    : tool.id === 'delete-pages'
                    ? `Delete ${deleteSelectedPages.length} Page(s)`
                    : tool.id === 'compress'
                    ? compressMode === 'target'
                      ? `Compress to Target (≤ ${compressTargetValue || '5'} ${compressTargetUnit})`
                      : `Compress PDF (-${compressRatio}%)`
                    : tool.id === 'duplicate-detector'
                    ? `Remove ${dupSelectedToRemove.size} Duplicate Page(s)`
                    : tool.id === 'blank-detector'
                    ? `Remove ${blankSelectedToRemove.size} Blank Page(s)`
                    : tool.id === 'page-size-normalizer'
                    ? `Normalize All ${pageCount} Page(s)`
                    : `Apply ${tool.name}`}
                </span>
              )}
            </button>
          </div>
        )}
      </div>

      {/* CROP MODAL FOR WATERMARK IMAGE */}
      {isWmImageCropOpen && wmImageData && (
        <ImageCropModal
          isOpen={isWmImageCropOpen}
          onClose={() => setIsWmImageCropOpen(false)}
          sourceDataUrl={wmImageData.dataUrl}
          sourceWidth={wmImageData.width}
          sourceHeight={wmImageData.height}
          imageFormat={wmImageData.format}
          fileName={wmImageData.name}
          onApplyCrop={(cropped) => {
            setWmImageData({
              ...wmImageData,
              buffer: cropped.buffer,
              dataUrl: cropped.dataUrl,
              width: cropped.width,
              height: cropped.height,
              aspectRatio: cropped.aspectRatio,
            });
            setIsWmImageCropOpen(false);
          }}
        />
      )}

      {/* CROP MODAL FOR PRE-CROPPING ADDED IMAGE */}
      {isAddImageCropOpen && addImageData && (
        <ImageCropModal
          isOpen={isAddImageCropOpen}
          onClose={() => setIsAddImageCropOpen(false)}
          sourceDataUrl={addImageData.dataUrl}
          sourceWidth={addImageData.width}
          sourceHeight={addImageData.height}
          imageFormat={addImageData.format}
          fileName={addImageData.file.name}
          onApplyCrop={(cropped) => {
            setAddImageData({
              ...addImageData,
              buffer: cropped.buffer,
              dataUrl: cropped.dataUrl,
              width: cropped.width,
              height: cropped.height,
              aspectRatio: cropped.aspectRatio,
            });
            setIsAddImageCropOpen(false);
          }}
        />
      )}
    </div>
  );
};
