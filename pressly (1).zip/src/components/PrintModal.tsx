import React, { useState } from 'react';
import { Printer, X, FileText, CheckCircle2, Sliders, Layers, Monitor, RotateCw } from 'lucide-react';

interface PrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  documentTitle?: string;
  totalPages?: number;
}

export const PrintModal: React.FC<PrintModalProps> = ({
  isOpen,
  onClose,
  documentTitle = 'Executive Proposal & Technical Architecture 2026.pdf',
  totalPages = 3,
}) => {
  const [printer, setPrinter] = useState('Pressly High-Res PDF Printer');
  const [pageRange, setPageRange] = useState<'all' | 'current' | 'custom'>('all');
  const [customRange, setCustomRange] = useState('1-3');
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [copies, setCopies] = useState(1);
  const [colorMode, setColorMode] = useState<'color' | 'grayscale'>('color');
  const [paperSize, setPaperSize] = useState('A4 (8.27" x 11.69")');
  const [isPrinting, setIsPrinting] = useState(false);
  const [printSuccess, setPrintSuccess] = useState(false);

  if (!isOpen) return null;

  const handlePrint = () => {
    setIsPrinting(true);
    setTimeout(() => {
      setIsPrinting(false);
      setPrintSuccess(true);
      setTimeout(() => {
        setPrintSuccess(false);
        onClose();
        // Invoke native print dialog if supported
        window.print();
      }, 1200);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1B2740]/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl border border-[#E8E8E6] w-full max-w-xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#E8E8E6] flex items-center justify-between bg-[#F6F6F4]">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-[#1B2740] text-white">
              <Printer size={18} />
            </div>
            <div>
              <h3 className="font-fraunces text-lg font-medium text-[#1B2740]">Print Document</h3>
              <p className="text-xs text-[#6B7280] font-ibm-mono truncate max-w-xs">{documentTitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#6B7280] hover:text-[#1B2740] hover:bg-[#E8E8E6]/50 rounded-lg cursor-pointer transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          {/* Printer Selection */}
          <div className="space-y-2">
            <label className="text-xs font-semibold uppercase tracking-wider text-[#6B7280] font-ibm-mono">
              Destination Printer
            </label>
            <div className="relative">
              <select
                value={printer}
                onChange={(e) => setPrinter(e.target.value)}
                className="w-full bg-[#F6F6F4] border border-[#E8E8E6] rounded-xl px-3.5 py-2.5 text-xs text-[#1B2740] font-medium focus:outline-none focus:border-[#C4432E] cursor-pointer"
              >
                <option value="Pressly High-Res PDF Printer">Pressly High-Res Virtual Printer (256-bit Vector)</option>
                <option value="System Local Printer">System Local Printer (Hardware)</option>
                <option value="Save as High-Quality PDF">Save as High-Quality PDF</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {/* Page Range Options */}
            <div className="space-y-3">
              <label className="text-xs font-semibold uppercase tracking-wider text-[#6B7280] font-ibm-mono block">
                Page Range
              </label>
              <div className="space-y-2 text-xs">
                <label className="flex items-center space-x-2.5 p-2 rounded-lg border border-[#E8E8E6] hover:bg-[#F6F6F4] cursor-pointer transition-colors">
                  <input
                    type="radio"
                    name="pageRange"
                    checked={pageRange === 'all'}
                    onChange={() => setPageRange('all')}
                    className="accent-[#C4432E]"
                  />
                  <span className="font-medium text-[#1B2740]">All Pages (1 - {totalPages})</span>
                </label>

                <label className="flex items-center space-x-2.5 p-2 rounded-lg border border-[#E8E8E6] hover:bg-[#F6F6F4] cursor-pointer transition-colors">
                  <input
                    type="radio"
                    name="pageRange"
                    checked={pageRange === 'current'}
                    onChange={() => setPageRange('current')}
                    className="accent-[#C4432E]"
                  />
                  <span className="font-medium text-[#1B2740]">Current Page Only</span>
                </label>

                <label className="flex items-center space-x-2.5 p-2 rounded-lg border border-[#E8E8E6] hover:bg-[#F6F6F4] cursor-pointer transition-colors">
                  <input
                    type="radio"
                    name="pageRange"
                    checked={pageRange === 'custom'}
                    onChange={() => setPageRange('custom')}
                    className="accent-[#C4432E]"
                  />
                  <span className="font-medium text-[#1B2740]">Custom Range</span>
                </label>

                {pageRange === 'custom' && (
                  <div className="pt-1 pl-6">
                    <input
                      type="text"
                      value={customRange}
                      onChange={(e) => setCustomRange(e.target.value)}
                      placeholder="e.g. 1-2 or 1, 3"
                      className="w-full bg-[#F6F6F4] border border-[#E8E8E6] rounded-lg px-3 py-1.5 text-xs text-[#1B2740] font-ibm-mono focus:outline-none focus:border-[#C4432E]"
                    />
                  </div>
                )}
              </div>
            </div>

            {/* Page Orientation Options */}
            <div className="space-y-3">
              <label className="text-xs font-semibold uppercase tracking-wider text-[#6B7280] font-ibm-mono block">
                Page Orientation
              </label>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => setOrientation('portrait')}
                  className={`p-3 rounded-xl border flex flex-col items-center justify-center space-y-2 cursor-pointer transition-all ${
                    orientation === 'portrait'
                      ? 'border-[#C4432E] bg-[#C4432E]/5 ring-2 ring-[#C4432E]/20 text-[#1B2740]'
                      : 'border-[#E8E8E6] hover:bg-[#F6F6F4] text-[#6B7280]'
                  }`}
                >
                  <div className="w-6 h-8 border-2 border-current rounded-xs flex items-center justify-center">
                    <div className="w-3 h-0.5 bg-current rounded-full" />
                  </div>
                  <span className="font-medium font-ibm-mono text-[11px]">Portrait</span>
                </button>

                <button
                  type="button"
                  onClick={() => setOrientation('landscape')}
                  className={`p-3 rounded-xl border flex flex-col items-center justify-center space-y-2 cursor-pointer transition-all ${
                    orientation === 'landscape'
                      ? 'border-[#C4432E] bg-[#C4432E]/5 ring-2 ring-[#C4432E]/20 text-[#1B2740]'
                      : 'border-[#E8E8E6] hover:bg-[#F6F6F4] text-[#6B7280]'
                  }`}
                >
                  <div className="w-8 h-6 border-2 border-current rounded-xs flex items-center justify-center">
                    <div className="w-4 h-0.5 bg-current rounded-full" />
                  </div>
                  <span className="font-medium font-ibm-mono text-[11px]">Landscape</span>
                </button>
              </div>
            </div>
          </div>

          {/* Copies & Color Mode Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2 border-t border-[#E8E8E6]">
            {/* Copies */}
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-[#6B7280] font-ibm-mono block">
                Number of Copies
              </label>
              <div className="flex items-center space-x-3">
                <button
                  type="button"
                  onClick={() => setCopies(Math.max(1, copies - 1))}
                  className="w-8 h-8 rounded-lg bg-[#F6F6F4] border border-[#E8E8E6] flex items-center justify-center font-bold text-[#1B2740] hover:bg-[#E8E8E6] cursor-pointer"
                >
                  -
                </button>
                <span className="font-ibm-mono text-sm font-semibold w-8 text-center text-[#1B2740]">
                  {copies}
                </span>
                <button
                  type="button"
                  onClick={() => setCopies(copies + 1)}
                  className="w-8 h-8 rounded-lg bg-[#F6F6F4] border border-[#E8E8E6] flex items-center justify-center font-bold text-[#1B2740] hover:bg-[#E8E8E6] cursor-pointer"
                >
                  +
                </button>
              </div>
            </div>

            {/* Color Mode */}
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-[#6B7280] font-ibm-mono block">
                Color Settings
              </label>
              <div className="flex items-center space-x-2 text-xs">
                <button
                  type="button"
                  onClick={() => setColorMode('color')}
                  className={`flex-1 py-2 px-3 rounded-lg border font-medium cursor-pointer transition-colors ${
                    colorMode === 'color'
                      ? 'bg-[#1B2740] text-white border-[#1B2740]'
                      : 'bg-white border-[#E8E8E6] text-[#6B7280] hover:bg-[#F6F6F4]'
                  }`}
                >
                  Full Color
                </button>
                <button
                  type="button"
                  onClick={() => setColorMode('grayscale')}
                  className={`flex-1 py-2 px-3 rounded-lg border font-medium cursor-pointer transition-colors ${
                    colorMode === 'grayscale'
                      ? 'bg-[#1B2740] text-white border-[#1B2740]'
                      : 'bg-white border-[#E8E8E6] text-[#6B7280] hover:bg-[#F6F6F4]'
                  }`}
                >
                  Grayscale
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 bg-[#F6F6F4] border-t border-[#E8E8E6] flex items-center justify-between">
          <div className="text-xs text-[#6B7280] font-ibm-mono hidden sm:block">
            <span>A4 • {orientation === 'portrait' ? '8.27" x 11.69"' : '11.69" x 8.27"'}</span>
          </div>

          <div className="flex items-center space-x-3 w-full sm:w-auto justify-end">
            <button
              onClick={onClose}
              disabled={isPrinting}
              className="px-4 py-2 bg-white border border-[#E8E8E6] hover:bg-[#E8E8E6]/50 text-[#1B2740] rounded-xl text-xs font-medium cursor-pointer transition-colors"
            >
              Cancel
            </button>

            <button
              onClick={handlePrint}
              disabled={isPrinting}
              className="px-6 py-2.5 bg-[#C4432E] hover:bg-[#a83623] text-white rounded-xl text-xs font-medium cursor-pointer red-glow transition-all flex items-center space-x-2"
            >
              {isPrinting ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Preparing Spool...</span>
                </>
              ) : printSuccess ? (
                <>
                  <CheckCircle2 size={16} />
                  <span>Sent to Printer!</span>
                </>
              ) : (
                <>
                  <Printer size={15} />
                  <span>Print Document</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
