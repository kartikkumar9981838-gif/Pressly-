export type PageType = 'home' | 'editor' | 'faq' | 'privacy';

export type ToolCategory = 'Organize' | 'Edit' | 'Convert';

export interface PDFTool {
  id: string;
  name: string;
  category: ToolCategory;
  iconName: string;
  description: string;
  badge?: string;
  modalType?: 'merge' | 'generic';
}

export interface FaqItem {
  id: string;
  category: 'General' | 'Privacy' | 'Technical';
  question: string;
  answer: string;
}

export interface MockDocument {
  name: string;
  size: string;
  pagesCount: number;
  uploadTime: string;
  pages: {
    pageNumber: number;
    title: string;
    previewLines: string[];
    hasHeader: boolean;
  }[];
}

export type EditorMode = 'upload' | 'create' | 'convert';

export type WatermarkType = 'text' | 'image';

export interface WatermarkDraft {
  type?: WatermarkType;
  text: string;
  fontSize: number;
  color: string;
  opacity: number;
  rotation: number;
  xRatio: number;
  yRatio: number;
  scope: 'all' | 'current';
  // Image Watermark Properties
  imageDataUrl?: string;
  imageBytes?: ArrayBuffer;
  imageFormat?: 'jpg' | 'png';
  imageWidthRatio?: number;
  naturalWidth?: number;
  naturalHeight?: number;
  aspectRatio?: number;
  imageFileName?: string;
}

export interface SignatureDraft {
  imageDataUrl: string;
  xRatio: number;
  yRatio: number;
  widthRatio: number;
  pageNumber: number;
}

export interface ImageDraft {
  id?: string;
  imageBytes: ArrayBuffer;
  imageFormat: 'jpg' | 'png';
  imageDataUrl: string;
  fileName?: string;
  naturalWidth: number;
  naturalHeight: number;
  aspectRatio: number;
  pageNumber: number;
  xRatio: number;
  yRatio: number;
  widthRatio: number;
  rotation: number;
  opacity: number;
  originalImageBytes?: ArrayBuffer;
  originalImageDataUrl?: string;
  originalWidth?: number;
  originalHeight?: number;
  isCropped?: boolean;
}


