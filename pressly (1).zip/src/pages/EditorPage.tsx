import React, { useState, useEffect, useRef, useCallback } from 'react';
import { EditorMode, PDFTool, PageType, WatermarkDraft, SignatureDraft, ImageDraft } from '../types';
import { ALL_TOOLS } from '../data/toolsData';
import { EditorHeader } from '../components/Editor/EditorHeader';
import { EditorCanvas } from '../components/Editor/EditorCanvas';
import { BottomToolbar } from '../components/Editor/BottomToolbar';
import { ToolModal } from '../components/ToolModal';
import { PrintModal } from '../components/PrintModal';
import { FindReplacePanel } from '../components/Editor/FindReplacePanel';
import { PasswordPromptModal } from '../components/Editor/PasswordPromptModal';
import {
  loadPdfDoc,
  loadPdfJsDoc,
  renderAllThumbnails,
  downloadPdfBytes,
  addWatermarkToPdf,
  addSignatureToPdf,
  addImageToPdf,
  createPdfFromSimpleText,
  FindMatchItem,
  isPdfEncrypted,
  isEncryptionError,
  unlockAndDecryptPdf,
} from '../lib/pdfEngine';
import {
  saveEditorSession,
  loadEditorSession,
  clearEditorSession,
  getAutoSaveMeta,
  AutoSaveMeta,
} from '../lib/autoSave';
import { X, Sliders, RotateCcw, Sparkles, AlertCircle, Save, CheckCircle2 } from 'lucide-react';

interface EditorPageProps {
  onNavigate: (page: PageType) => void;
  initialToolId?: string | null;
  isOnline?: boolean;
  isInstalled?: boolean;
  onInstallClick?: () => void;
}

export const EditorPage: React.FC<EditorPageProps> = ({
  onNavigate,
  initialToolId,
  isOnline = true,
  isInstalled = false,
  onInstallClick,
}) => {
  const [selectedFlow, setSelectedFlow] = useState<EditorMode | null>(
    initialToolId ? 'upload' : null
  );

  // REAL PDF DOCUMENT STATE
  const [pdfBuffer, setPdfBuffer] = useState<ArrayBuffer | null>(null);
  const [pdfFileName, setPdfFileName] = useState<string>('document.pdf');
  const [pageCount, setPageCount] = useState<number>(1);
  const [activePage, setActivePage] = useState<number>(1);
  const [pageSequence, setPageSequence] = useState<number[]>([]);
  const [thumbnails, setThumbnails] = useState<string[]>([]);
  const [hasFile, setHasFile] = useState<boolean>(false);
  const [isLoadingFile, setIsLoadingFile] = useState<boolean>(false);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // AUTO-SAVE & SESSION RECOVERY STATE
  const [autoSaveStatus, setAutoSaveStatus] = useState<'saved' | 'saving' | 'error' | 'disabled' | 'idle'>('idle');
  const [lastSavedTime, setLastSavedTime] = useState<string | null>(null);
  const [pendingRecoveryMeta, setPendingRecoveryMeta] = useState<AutoSaveMeta | null>(null);
  const saveInProgressRef = useRef<boolean>(false);

  const [activeTool, setActiveTool] = useState<PDFTool | null>(
    initialToolId ? ALL_TOOLS.find((t) => t.id === initialToolId) || ALL_TOOLS[0] : ALL_TOOLS[0]
  );
  const [activeToolMessage, setActiveToolMessage] = useState<string | null>(
    initialToolId ? `Active tool: ${ALL_TOOLS.find((t) => t.id === initialToolId)?.name}` : null
  );

  // WATERMARK, SIGNATURE & EDIT TEXT DRAFT STATE
  const [watermarkDraft, setWatermarkDraft] = useState<WatermarkDraft | null>(null);
  const [signatureDraft, setSignatureDraft] = useState<SignatureDraft | null>(null);
  const [imageDraft, setImageDraft] = useState<ImageDraft | null>(null);
  const [isEditTextActive, setIsEditTextActive] = useState<boolean>(false);

  // FIND & REPLACE STATE
  const [isFindReplaceActive, setIsFindReplaceActive] = useState<boolean>(false);
  const [findReplaceMatchesByPage, setFindReplaceMatchesByPage] = useState<Record<number, FindMatchItem[]>>({});
  const [focusedFindMatchId, setFocusedFindMatchId] = useState<string | null>(null);

  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState<boolean>(false);

  // PASSWORD PROTECTION & REMOVAL STATE
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState<boolean>(false);
  const [pendingEncryptedFile, setPendingEncryptedFile] = useState<{
    buffer: ArrayBuffer;
    fileName: string;
  } | null>(null);
  const [passwordModalError, setPasswordModalError] = useState<string | null>(null);
  const [isDecrypting, setIsDecrypting] = useState<boolean>(false);

  // Settings State with Auto-Save preferences
  const [settings, setSettings] = useState(() => {
    try {
      const saved = localStorage.getItem('pressly_editor_settings');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {}
    return {
      autoCompress: true,
      rasterResolution: '300 DPI',
      memoryPurgeTimer: '60 minutes',
      darkCanvas: false,
      autoSaveEnabled: true,
      autoSaveIntervalSec: 10,
    };
  });

  // Save settings changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('pressly_editor_settings', JSON.stringify(settings));
    } catch (e) {}
  }, [settings]);

  // Check for existing auto-saved session on initial mount
  useEffect(() => {
    const meta = getAutoSaveMeta();
    if (meta && !hasFile) {
      setPendingRecoveryMeta(meta);
    }
  }, [hasFile]);

  // Synchronize active tool and flow when initialToolId is passed from HomePage or Navigation
  useEffect(() => {
    if (initialToolId) {
      const tool = ALL_TOOLS.find((t) => t.id === initialToolId);
      if (tool) {
        setActiveTool(tool);
        if (tool.id === 'create-pdf') {
          setSelectedFlow('create');
        } else if (tool.id === 'scan') {
          setSelectedFlow('scan');
        } else {
          setSelectedFlow('upload');
        }
      }
    }
  }, [initialToolId]);

  // Core Auto-Save execution function
  const triggerAutoSave = useCallback(async () => {
    if (!settings.autoSaveEnabled || !pdfBuffer || !hasFile || saveInProgressRef.current) {
      return;
    }

    try {
      saveInProgressRef.current = true;
      setAutoSaveStatus('saving');
      const meta = await saveEditorSession({
        buffer: pdfBuffer,
        fileName: pdfFileName,
        pageCount,
        activePage,
        pageSequence:
          pageSequence && pageSequence.length === pageCount
            ? pageSequence
            : Array.from({ length: pageCount }, (_, i) => i + 1),
        selectedFlow: selectedFlow || 'upload',
      });
      setAutoSaveStatus('saved');
      setLastSavedTime(meta.savedAtFormatted);
    } catch (err) {
      console.warn('Auto-save encountered an issue:', err);
      setAutoSaveStatus('error');
    } finally {
      saveInProgressRef.current = false;
    }
  }, [pdfBuffer, pdfFileName, pageCount, activePage, pageSequence, selectedFlow, hasFile, settings.autoSaveEnabled]);

  // Debounced auto-save on user actions / mutations (1.5s debounce)
  useEffect(() => {
    if (!hasFile || !pdfBuffer || !settings.autoSaveEnabled) return;
    const timer = setTimeout(() => {
      triggerAutoSave();
    }, 1500);
    return () => clearTimeout(timer);
  }, [pdfBuffer, activePage, pageSequence, pdfFileName, triggerAutoSave, hasFile, settings.autoSaveEnabled]);

  // Periodic interval auto-save (every N seconds)
  useEffect(() => {
    if (!hasFile || !pdfBuffer || !settings.autoSaveEnabled) return;
    const intervalMs = (settings.autoSaveIntervalSec || 10) * 1000;
    const intervalId = setInterval(() => {
      triggerAutoSave();
    }, intervalMs);
    return () => clearInterval(intervalId);
  }, [hasFile, pdfBuffer, settings.autoSaveEnabled, settings.autoSaveIntervalSec, triggerAutoSave]);

  // Manual save trigger (e.g. from header button or menu)
  const handleManualSave = async () => {
    if (!pdfBuffer || !hasFile) return;
    await triggerAutoSave();
    setActiveToolMessage('Progress successfully auto-saved to browser storage!');
    setTimeout(() => setActiveToolMessage(null), 2500);
  };

  // Restore session handler
  const handleRestoreSession = async () => {
    setIsLoadingFile(true);
    setUploadError(null);
    try {
      const session = await loadEditorSession();
      if (!session || !session.buffer) {
        throw new Error('Could not find cached PDF buffer data. The file might have been cleared or expired.');
      }
      const buffer = session.buffer;
      const meta = session.meta;
      const libDoc = await loadPdfDoc(buffer);
      const count = libDoc.getPageCount();

      const jsDoc = await loadPdfJsDoc(buffer);
      const thumbs = await renderAllThumbnails(jsDoc, 140);

      setPdfBuffer(buffer);
      setPdfFileName(meta?.fileName || 'recovered_document.pdf');
      setPageCount(count);
      const restoredPage = meta?.activePage && meta.activePage <= count ? meta.activePage : 1;
      setActivePage(restoredPage);
      if (meta?.pageSequence && meta.pageSequence.length === count) {
        setPageSequence(meta.pageSequence);
      } else {
        setPageSequence(Array.from({ length: count }, (_, i) => i + 1));
      }
      setThumbnails(thumbs);
      setHasFile(true);
      setSelectedFlow((meta?.selectedFlow as EditorMode) || 'upload');
      setPendingRecoveryMeta(null);
      if (meta?.savedAtFormatted) {
        setLastSavedTime(meta.savedAtFormatted);
      }
      setAutoSaveStatus('saved');
      setActiveToolMessage(`Restored auto-saved document: ${meta?.fileName || 'PDF'} (${count} pages).`);
      setTimeout(() => setActiveToolMessage(null), 3500);
    } catch (err: any) {
      console.error('Failed to restore auto-save session:', err);
      setUploadError(err.message || 'Failed to restore previous auto-saved session.');
      setPendingRecoveryMeta(null);
    } finally {
      setIsLoadingFile(false);
    }
  };

  // Discard auto-saved session
  const handleDiscardSession = async () => {
    await clearEditorSession();
    setPendingRecoveryMeta(null);
    setActiveToolMessage('Auto-saved session discarded.');
    setTimeout(() => setActiveToolMessage(null), 2500);
  };

  const handleStartOver = async () => {
    setSelectedFlow(null);
    setHasFile(false);
    setPdfBuffer(null);
    setPageSequence([]);
    setThumbnails([]);
    setWatermarkDraft(null);
    setSignatureDraft(null);
    setImageDraft(null);
    setIsEditTextActive(false);
    setIsFindReplaceActive(false);
    setFindReplaceMatchesByPage({});
    setFocusedFindMatchId(null);
    setAutoSaveStatus('idle');
    setLastSavedTime(null);
    await clearEditorSession();
    setPendingRecoveryMeta(null);
  };

  // REAL FILE UPLOAD HANDLER WITH PASSWORD ENCRYPTION DETECTION
  const processAndSetPdfBuffer = async (
    buffer: ArrayBuffer,
    fileName: string,
    successNote?: string
  ) => {
    const libDoc = await loadPdfDoc(buffer);
    const count = libDoc.getPageCount();

    const jsDoc = await loadPdfJsDoc(buffer);
    const thumbs = await renderAllThumbnails(jsDoc, 140);

    const seq = Array.from({ length: count }, (_, i) => i + 1);
    setPdfBuffer(buffer);
    setPdfFileName(fileName);
    setPageCount(count);
    setActivePage(1);
    setPageSequence(seq);
    setThumbnails(thumbs);
    setHasFile(true);
    setSelectedFlow('upload');
    setPendingRecoveryMeta(null);

    // Trigger immediate initial save for newly uploaded document
    if (settings.autoSaveEnabled) {
      saveEditorSession({
        buffer,
        fileName: fileName,
        pageCount: count,
        activePage: 1,
        pageSequence: seq,
        selectedFlow: 'upload',
      })
        .then((meta) => {
          setAutoSaveStatus('saved');
          setLastSavedTime(meta.savedAtFormatted);
        })
        .catch((err) => console.warn('Initial autosave error:', err));
    }

    // PDF is loaded directly into the editor for editing without any popup disturbances
    setIsModalOpen(false);
    setIsEditTextActive(false);
    setIsFindReplaceActive(false);

    setActiveToolMessage(successNote || `Successfully loaded ${fileName} (${count} pages).`);
    setTimeout(() => setActiveToolMessage(null), 3500);
  };

  const handleLoadPdfFile = async (file: File) => {
    setIsLoadingFile(true);
    setUploadError(null);
    setPasswordModalError(null);

    try {
      const buffer = await file.arrayBuffer();

      // Check if encrypted before attempting normal load
      const isEncrypted = await isPdfEncrypted(buffer);
      if (isEncrypted) {
        setPendingEncryptedFile({ buffer, fileName: file.name });
        setIsPasswordModalOpen(true);
        setIsLoadingFile(false);
        return;
      }

      await processAndSetPdfBuffer(buffer, file.name);
    } catch (err: any) {
      console.error('File load error:', err);
      if (isEncryptionError(err)) {
        try {
          const buffer = await file.arrayBuffer();
          setPendingEncryptedFile({ buffer, fileName: file.name });
          setIsPasswordModalOpen(true);
          setIsLoadingFile(false);
          return;
        } catch {}
      }
      setUploadError(err.message || 'Failed to load PDF file. The file may be corrupted.');
      setHasFile(false);
    } finally {
      setIsLoadingFile(false);
    }
  };

  const handleUnlockPendingPdf = async (password: string) => {
    if (!pendingEncryptedFile) return;
    setIsDecrypting(true);
    setPasswordModalError(null);

    try {
      const unlockResult = await unlockAndDecryptPdf(pendingEncryptedFile.buffer, password);
      const unlockedFileName = pendingEncryptedFile.fileName;
      setIsPasswordModalOpen(false);
      setPendingEncryptedFile(null);
      setPasswordModalError(null);
      setIsLoadingFile(true);

      await processAndSetPdfBuffer(
        unlockResult.decryptedBuffer,
        unlockedFileName,
        `Unlocked and decrypted ${unlockedFileName} successfully!`
      );
    } catch (err: any) {
      console.warn('Password unlock error:', err);
      const msg = err?.message || String(err);
      if (
        msg.includes('Incorrect password') ||
        msg.toLowerCase().includes('invalid password') ||
        msg.toLowerCase().includes('password')
      ) {
        setPasswordModalError('Incorrect password. Please try again.');
      } else {
        setPasswordModalError("Unable to process this PDF's encryption. It may use an unsupported security method.");
      }
    } finally {
      setIsDecrypting(false);
      setIsLoadingFile(false);
    }
  };

  const handleCancelPasswordPrompt = () => {
    setIsPasswordModalOpen(false);
    setPendingEncryptedFile(null);
    setPasswordModalError(null);
    setIsLoadingFile(false);
  };

  // UPDATE PDF BUFFER AFTER TOOL APPLICATION OR CONVERSION
  const handleUpdatePdfBuffer = async (
    newBuffer: ArrayBuffer,
    message: string,
    newFileName?: string,
    newSequence?: number[]
  ) => {
    try {
      const libDoc = await loadPdfDoc(newBuffer);
      const count = libDoc.getPageCount();

      const jsDoc = await loadPdfJsDoc(newBuffer);
      const thumbs = await renderAllThumbnails(jsDoc, 140);

      setPdfBuffer(newBuffer);
      setPageCount(count);
      setActivePage(1);
      setThumbnails(thumbs);
      setHasFile(true);
      setSelectedFlow('upload');
      const finalFileName = newFileName || pdfFileName;
      if (newFileName) {
        setPdfFileName(newFileName);
      }
      let finalSequence = pageSequence;
      if (newSequence && newSequence.length === count) {
        finalSequence = newSequence;
        setPageSequence(newSequence);
      } else if (pageSequence && pageSequence.length === count) {
        // Retain existing reordered page sequence throughout session
      } else {
        finalSequence = Array.from({ length: count }, (_, i) => i + 1);
        setPageSequence(finalSequence);
      }

      // Auto-save immediately upon PDF modification
      if (settings.autoSaveEnabled) {
        saveEditorSession({
          buffer: newBuffer,
          fileName: finalFileName,
          pageCount: count,
          activePage: 1,
          pageSequence: finalSequence,
          selectedFlow: 'upload',
        })
          .then((meta) => {
            setAutoSaveStatus('saved');
            setLastSavedTime(meta.savedAtFormatted);
          })
          .catch((err) => console.warn('Autosave post-update error:', err));
      }

      setActiveToolMessage(message);
      setTimeout(() => setActiveToolMessage(null), 4000);
    } catch (err: any) {
      console.error('Error updating PDF buffer:', err);
      setActiveToolMessage(`Action completed, but failed to re-render preview.`);
    }
  };

  const handleSelectTool = (tool: PDFTool) => {
    setActiveTool(tool);
    if (tool.id === 'find-replace') {
      setIsEditTextActive(false);
      setWatermarkDraft(null);
      setSignatureDraft(null);
      setIsFindReplaceActive(true);
      setIsModalOpen(false);
    } else {
      setIsModalOpen(true);
    }
  };

  const handleExportDownload = async () => {
    if (pdfBuffer) {
      downloadPdfBytes(new Uint8Array(pdfBuffer), `pressly_${pdfFileName}`);
      setActiveToolMessage('Downloaded modified PDF document with all changes!');
      setTimeout(() => setActiveToolMessage(null), 3500);
    } else if (selectedFlow === 'create') {
      try {
        const bytes = await createPdfFromSimpleText('New Pressly Document', 'Document generated from Pressly PDF Editor');
        downloadPdfBytes(bytes, 'pressly_new_document.pdf');
        setActiveToolMessage('Downloaded generated PDF document!');
        setTimeout(() => setActiveToolMessage(null), 3500);
      } catch (err: any) {
        console.error('Failed to generate PDF:', err);
        setActiveToolMessage('Error exporting document.');
        setTimeout(() => setActiveToolMessage(null), 2500);
      }
    } else {
      setActiveToolMessage('No active PDF loaded to export.');
      setTimeout(() => setActiveToolMessage(null), 2500);
    }
  };

  // BAKE WATERMARK TO PDF
  const handleBakeWatermark = async (draft: WatermarkDraft) => {
    if (!pdfBuffer) return;
    try {
      const targetPage = draft.scope === 'current' ? activePage : undefined;
      const isImage = draft.type === 'image' || Boolean(draft.imageBytes);
      const newBytes = await addWatermarkToPdf(
        pdfBuffer,
        isImage ? undefined : draft.text,
        isImage ? draft.imageBytes : undefined,
        draft.opacity,
        draft.rotation,
        targetPage,
        draft.fontSize,
        draft.color,
        draft.xRatio,
        draft.yRatio,
        draft.imageWidthRatio || 0.45,
        draft.imageFormat || 'png'
      );
      await handleUpdatePdfBuffer(
        newBytes.buffer,
        isImage ? 'Image watermark permanently applied to PDF!' : 'Watermark permanently applied to PDF!'
      );
      setWatermarkDraft(null);
    } catch (err: any) {
      console.error('Failed to bake watermark:', err);
      setActiveToolMessage(`Error applying watermark: ${err.message || 'Unknown error'}`);
    }
  };

  // BAKE SIGNATURE TO PDF
  const handleBakeSignature = async (draft: SignatureDraft) => {
    if (!pdfBuffer) return;
    try {
      const newBytes = await addSignatureToPdf(
        pdfBuffer,
        draft.imageDataUrl,
        draft.pageNumber,
        draft.xRatio,
        draft.yRatio,
        draft.widthRatio
      );
      await handleUpdatePdfBuffer(newBytes.buffer, 'E-Signature permanently applied to PDF!');
      setSignatureDraft(null);
    } catch (err: any) {
      console.error('Failed to bake signature:', err);
      setActiveToolMessage(`Error applying signature: ${err.message || 'Unknown error'}`);
    }
  };

  // BAKE IMAGE TO PDF
  const handleBakeImage = async (draft: ImageDraft) => {
    if (!pdfBuffer) return;
    try {
      const newBytes = await addImageToPdf(
        pdfBuffer,
        draft.imageBytes,
        draft.pageNumber,
        draft.xRatio,
        draft.yRatio,
        draft.widthRatio,
        draft.rotation,
        draft.opacity,
        draft.imageFormat
      );
      await handleUpdatePdfBuffer(newBytes.buffer, 'Image permanently inserted into PDF!');
      setImageDraft(null);
    } catch (err: any) {
      console.error('Failed to bake image:', err);
      setActiveToolMessage(`Error adding image: ${err.message || 'Unknown error'}`);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-[#F6F6F4] text-[#1B2740] overflow-hidden select-none">
      {/* Top Header */}
      <EditorHeader
        selectedFlow={selectedFlow}
        onStartOver={handleStartOver}
        activeTool={activeTool}
        hasFile={hasFile}
        onDownload={handleExportDownload}
        onHomeClick={() => onNavigate('home')}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenPrint={() => setIsPrintModalOpen(true)}
        autoSaveStatus={autoSaveStatus}
        lastSavedTime={lastSavedTime}
        onManualSave={handleManualSave}
        isOnline={isOnline}
        isInstalled={isInstalled}
        onInstallClick={onInstallClick}
      />

      {/* Auto-Save Session Recovery Notification Banner */}
      {pendingRecoveryMeta && !hasFile && (
        <div className="bg-linear-to-r from-[#1B2740] via-[#243350] to-[#1B2740] text-white px-4 py-3 sm:px-6 shadow-md border-b border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in slide-in-from-top-3 duration-200 z-20">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-[#C4432E]/20 text-[#C4432E] rounded-xl shrink-0 border border-[#C4432E]/30 shadow-2xs">
              <RotateCcw size={18} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase font-ibm-mono text-[#C4432E] tracking-wider">
                  Auto-Saved Progress Available
                </span>
                <span className="text-[11px] text-gray-300 font-ibm-mono">
                  • Saved {pendingRecoveryMeta.savedAtFormatted}
                </span>
              </div>
              <p className="text-xs sm:text-sm font-medium text-white">
                Found previous unsaved session for <span className="font-bold underline">{pendingRecoveryMeta.fileName}</span> ({pendingRecoveryMeta.pageCount} {pendingRecoveryMeta.pageCount === 1 ? 'page' : 'pages'}, active page {pendingRecoveryMeta.activePage}).
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
            <button
              onClick={handleRestoreSession}
              disabled={isLoadingFile}
              className="px-4 py-2 bg-[#C4432E] hover:bg-[#a83623] text-white text-xs font-semibold rounded-lg shadow-sm transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <Sparkles size={14} />
              <span>{isLoadingFile ? 'Restoring Session...' : 'Restore Session'}</span>
            </button>
            <button
              onClick={handleDiscardSession}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 text-gray-200 hover:text-white text-xs font-medium rounded-lg transition-colors cursor-pointer border border-white/10"
            >
              Discard
            </button>
          </div>
        </div>
      )}

      {/* Main Canvas Area */}
      <EditorCanvas
        selectedFlow={selectedFlow}
        onSelectFlow={(flow) => setSelectedFlow(flow)}
        hasFile={hasFile}
        pdfBuffer={pdfBuffer}
        pdfFileName={pdfFileName}
        pageCount={pageCount}
        activePage={activePage}
        setActivePage={setActivePage}
        thumbnails={thumbnails}
        isLoadingFile={isLoadingFile}
        uploadError={uploadError}
        onUploadPdfFile={handleLoadPdfFile}
        onResetFile={() => {
          setHasFile(false);
          setPdfBuffer(null);
          setThumbnails([]);
          setWatermarkDraft(null);
          setSignatureDraft(null);
          setImageDraft(null);
        }}
        activeTool={activeTool}
        activeToolMessage={activeToolMessage}
        onUpdatePdfBuffer={handleUpdatePdfBuffer}
        watermarkDraft={watermarkDraft}
        setWatermarkDraft={setWatermarkDraft}
        onBakeWatermark={handleBakeWatermark}
        signatureDraft={signatureDraft}
        setSignatureDraft={setSignatureDraft}
        onBakeSignature={handleBakeSignature}
        imageDraft={imageDraft}
        setImageDraft={setImageDraft}
        onBakeImage={handleBakeImage}
        isEditTextActive={isEditTextActive}
        setIsEditTextActive={setIsEditTextActive}
        isFindReplaceActive={isFindReplaceActive}
        setIsFindReplaceActive={setIsFindReplaceActive}
        findReplaceMatchesByPage={findReplaceMatchesByPage}
        focusedMatchId={focusedFindMatchId}
        onSelectMatch={(match) => setFocusedFindMatchId(match.id)}
      />

      {/* Floating Find & Replace Panel */}
      {isFindReplaceActive && pdfBuffer && (
        <FindReplacePanel
          pdfBuffer={pdfBuffer}
          activePage={activePage}
          pageCount={pageCount}
          setActivePage={setActivePage}
          onUpdatePdfBuffer={handleUpdatePdfBuffer}
          onClose={() => {
            setIsFindReplaceActive(false);
            setFindReplaceMatchesByPage({});
            setFocusedFindMatchId(null);
          }}
          onMatchesUpdate={(matchesByPage, focusedId) => {
            setFindReplaceMatchesByPage(matchesByPage);
            setFocusedFindMatchId(focusedId);
          }}
        />
      )}

      {/* Bottom Sticky Toolbar */}
      {selectedFlow === 'upload' && hasFile && (
        <BottomToolbar activeTool={activeTool} onSelectTool={handleSelectTool} />
      )}

      {/* Interactive Tool Modal */}
      {activeTool && (
        <ToolModal
          tool={activeTool}
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          pdfBuffer={pdfBuffer}
          pdfFileName={pdfFileName}
          activePage={activePage}
          pageCount={pageCount}
          pageSequence={pageSequence}
          thumbnails={thumbnails}
          setActivePage={setActivePage}
          onUpdatePdfBuffer={handleUpdatePdfBuffer}
          onLaunchWatermarkDraft={(draft) => {
            setWatermarkDraft(draft);
            setActiveToolMessage('Live Watermark active. Drag on canvas to reposition, then click Bake Watermark.');
          }}
          onLaunchSignatureDraft={(draft) => {
            setSignatureDraft(draft);
            setActiveToolMessage('Live E-Signature active. Drag on canvas to reposition and resize, then click Bake.');
          }}
          onLaunchImageDraft={(draft) => {
            setImageDraft(draft);
            setActiveToolMessage('Image draft active. Drag on canvas to reposition, resize with handles, then click Apply.');
          }}
          onLaunchEditTextMode={() => {
            setIsFindReplaceActive(false);
            setIsEditTextActive(true);
            setActiveToolMessage('Edit Text mode active. Tap any text region on the page canvas to edit in place.');
          }}
          onLaunchFindReplaceMode={() => {
            setIsEditTextActive(false);
            setWatermarkDraft(null);
            setSignatureDraft(null);
            setIsFindReplaceActive(true);
            setActiveToolMessage('Find & Replace active. Search for words and replace occurrences across your document.');
          }}
        />
      )}

      {/* Settings Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1B2740]/60 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-white rounded-xl shadow-2xl border border-[#E8E8E6] w-full max-w-md overflow-hidden">
            <div className="px-6 py-4 border-b border-[#E8E8E6] flex items-center justify-between bg-[#F6F6F4]">
              <div className="flex items-center space-x-2">
                <Sliders size={18} className="text-[#C4432E]" />
                <h3 className="font-fraunces text-lg font-medium text-[#1B2740]">Editor Preferences</h3>
              </div>
              <button
                onClick={() => setIsSettingsOpen(false)}
                className="p-1 text-[#6B7280] hover:text-[#1B2740] rounded-lg cursor-pointer"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-6 space-y-4 text-sm">
              {/* Auto-Save Toggle */}
              <div className="flex items-center justify-between py-2 border-b border-[#E8E8E6]">
                <div>
                  <p className="font-medium text-[#1B2740]">Auto-Save Progress</p>
                  <p className="text-xs text-[#6B7280]">
                    Periodically save PDF and edits to localStorage across tab refreshes
                  </p>
                </div>
                <button
                  onClick={() => setSettings({ ...settings, autoSaveEnabled: !settings.autoSaveEnabled })}
                  className={`w-11 h-6 rounded-full transition-colors cursor-pointer p-0.5 ${
                    settings.autoSaveEnabled ? 'bg-[#C4432E]' : 'bg-[#E8E8E6]'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full transition-transform ${
                      settings.autoSaveEnabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Auto-Save Interval Frequency */}
              {settings.autoSaveEnabled && (
                <div className="flex items-center justify-between py-2 border-b border-[#E8E8E6]">
                  <div>
                    <p className="font-medium text-[#1B2740]">Auto-Save Frequency</p>
                    <p className="text-xs text-[#6B7280]">Interval between automatic background saves</p>
                  </div>
                  <select
                    value={settings.autoSaveIntervalSec || 10}
                    onChange={(e) =>
                      setSettings({ ...settings, autoSaveIntervalSec: parseInt(e.target.value, 10) })
                    }
                    className="bg-[#F6F6F4] border border-[#E8E8E6] rounded-md text-xs px-2.5 py-1.5 focus:outline-none font-ibm-mono"
                  >
                    <option value={5}>Every 5 seconds</option>
                    <option value={10}>Every 10 seconds (Default)</option>
                    <option value={30}>Every 30 seconds</option>
                    <option value={60}>Every 1 minute</option>
                  </select>
                </div>
              )}

              {/* PDF Compression */}
              <div className="flex items-center justify-between py-2 border-b border-[#E8E8E6]">
                <div>
                  <p className="font-medium text-[#1B2740]">Automatic PDF Compression</p>
                  <p className="text-xs text-[#6B7280]">Optimize files automatically upon export</p>
                </div>
                <button
                  onClick={() => setSettings({ ...settings, autoCompress: !settings.autoCompress })}
                  className={`w-11 h-6 rounded-full transition-colors cursor-pointer p-0.5 ${
                    settings.autoCompress ? 'bg-[#C4432E]' : 'bg-[#E8E8E6]'
                  }`}
                >
                  <div
                    className={`w-5 h-5 bg-white rounded-full transition-transform ${
                      settings.autoCompress ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              {/* Raster Resolution */}
              <div className="flex items-center justify-between py-2 border-b border-[#E8E8E6]">
                <div>
                  <p className="font-medium text-[#1B2740]">Raster Resolution</p>
                  <p className="text-xs text-[#6B7280]">Target rendering DPI quality</p>
                </div>
                <select
                  value={settings.rasterResolution}
                  onChange={(e) => setSettings({ ...settings, rasterResolution: e.target.value })}
                  className="bg-[#F6F6F4] border border-[#E8E8E6] rounded-md text-xs px-2.5 py-1.5 focus:outline-none"
                >
                  <option value="150 DPI">150 DPI (Fast)</option>
                  <option value="300 DPI">300 DPI (Standard)</option>
                  <option value="600 DPI">600 DPI (Ultra)</option>
                </select>
              </div>

              {/* Manual Save & Clear Session Actions */}
              <div className="pt-2 flex flex-col gap-2">
                {hasFile && (
                  <button
                    type="button"
                    onClick={() => {
                      handleManualSave();
                      setIsSettingsOpen(false);
                    }}
                    className="w-full py-2 bg-[#1B2740] hover:bg-[#243456] text-white text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Save size={14} />
                    <span>Save Current Progress to LocalStorage</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={async () => {
                    await clearEditorSession();
                    setLastSavedTime(null);
                    setAutoSaveStatus('idle');
                    setActiveToolMessage('Cleared cached auto-save storage.');
                    setTimeout(() => setActiveToolMessage(null), 2500);
                  }}
                  className="w-full py-1.5 text-xs text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer border border-transparent hover:border-red-200 text-center"
                >
                  Clear Cached Auto-Save Storage
                </button>
              </div>
            </div>

            <div className="px-6 py-3.5 bg-[#F6F6F4] border-t border-[#E8E8E6] flex justify-end">
              <button
                onClick={() => setIsSettingsOpen(false)}
                className="px-4 py-2 bg-[#1B2740] text-white rounded-lg text-xs font-medium cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Print Document Modal */}
      <PrintModal
        isOpen={isPrintModalOpen}
        onClose={() => setIsPrintModalOpen(false)}
      />

      {/* Password Prompt Modal for Unlocking Protected PDFs */}
      <PasswordPromptModal
        isOpen={isPasswordModalOpen}
        fileName={pendingEncryptedFile?.fileName || 'document.pdf'}
        onUnlock={handleUnlockPendingPdf}
        onCancel={handleCancelPasswordPrompt}
        errorMessage={passwordModalError}
        isLoading={isDecrypting}
      />
    </div>
  );
};

