import React, { useState, useEffect } from 'react';
import { ShieldCheck, Lock, Trash2, CheckCircle } from 'lucide-react';

export const PrivacyPage: React.FC = () => {
  const [activeSection, setActiveSection] = useState('data-collect');

  const sections = [
    { id: 'data-collect', title: '1. Data We Collect' },
    { id: 'how-use', title: '2. How We Use Data' },
    { id: 'file-deletion', title: '3. File Handling & Auto-Deletion' },
    { id: 'third-party', title: '4. Third-Party Services' },
    { id: 'user-rights', title: '5. Your Rights & GDPR' },
    { id: 'contact', title: '6. Contact Us' },
  ];

  const scrollTo = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen bg-white text-[#1B2740] pt-12 pb-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Sticky Sidebar Table of Contents */}
        <aside className="hidden lg:block lg:col-span-3 sticky top-28 h-fit space-y-4">
          <div className="p-4 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6] space-y-3">
            <span className="text-xs font-semibold uppercase tracking-wider font-ibm-mono text-[#6B7280]">
              Table of Contents
            </span>
            <nav className="space-y-1.5 text-xs font-medium">
              {sections.map((sec) => (
                <button
                  key={sec.id}
                  onClick={() => scrollTo(sec.id)}
                  className={`block w-full text-left py-1.5 px-2 rounded-md transition-colors cursor-pointer ${
                    activeSection === sec.id
                      ? 'bg-white text-[#C4432E] font-semibold shadow-2xs border border-[#E8E8E6]'
                      : 'text-[#6B7280] hover:text-[#1B2740]'
                  }`}
                >
                  {sec.title}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-4 bg-[#1B2740] text-white rounded-xl space-y-2 text-xs">
            <div className="flex items-center space-x-1.5 text-[#C4432E] font-bold">
              <ShieldCheck size={16} />
              <span>Zero-Storage Promise</span>
            </div>
            <p className="text-white/70 leading-relaxed">
              All processed PDF files are held exclusively in ephemeral volatile RAM and auto-purged within 60 minutes.
            </p>
          </div>
        </aside>

        {/* Main Content Column */}
        <main className="lg:col-span-9 max-w-3xl space-y-10">
          <div className="space-y-3 border-b border-[#E8E8E6] pb-8">
            <h1 className="font-fraunces text-4xl sm:text-5xl font-medium text-[#1B2740]">
              Privacy Policy
            </h1>
            <p className="text-sm font-ibm-mono text-[#6B7280]">
              Last updated: August 7, 2026 • Effective Version 3.4
            </p>
          </div>

          <div className="space-y-10 text-sm sm:text-base text-[#1B2740]/90 leading-relaxed font-ibm-sans">
            {/* Section 1 */}
            <section id="data-collect" className="space-y-3 scroll-mt-28">
              <h2 className="font-fraunces text-2xl font-medium text-[#1B2740]">
                1. Data We Collect
              </h2>
              <p className="text-[#6B7280]">
                Pressly operates on a zero-retention architecture. When you upload or process PDF files using our online tools, we collect only minimal telemetry data required to complete the requested processing task.
              </p>
              <ul className="list-disc pl-5 space-y-1.5 text-[#6B7280]">
                <li>File metadata (file size, page counts, MIME types) for memory allocation</li>
                <li>Anonymized session identifiers to track task progress</li>
                <li>Standard HTTP server log telemetry (IP addresses stripped after 24 hours)</li>
              </ul>
            </section>

            {/* Section 2 */}
            <section id="how-use" className="space-y-3 scroll-mt-28">
              <h2 className="font-fraunces text-2xl font-medium text-[#1B2740]">
                2. How We Use Data
              </h2>
              <p className="text-[#6B7280]">
                We use collected operational data strictly to render PDF conversions, compression algorithms, e-signature overlays, and watermarking. We never inspect, analyze, or aggregate document contents for machine learning training, advertising, or profiling.
              </p>
            </section>

            {/* Section 3 */}
            <section id="file-deletion" className="space-y-3 scroll-mt-28">
              <h2 className="font-fraunces text-2xl font-medium text-[#1B2740]">
                3. File Handling & Auto-Deletion
              </h2>
              <p className="text-[#6B7280]">
                All files uploaded to Pressly are encrypted in transit using 256-bit TLS/SSL and stored temporarily in isolated ephemeral memory buffers.
              </p>
              <div className="p-4 bg-[#F6F6F4] rounded-xl border border-[#E8E8E6] space-y-2">
                <div className="flex items-center space-x-2 font-bold text-[#1B2740]">
                  <Trash2 size={18} className="text-[#C4432E]" />
                  <span>Automatic 1-Hour Purge Protocol</span>
                </div>
                <p className="text-xs text-[#6B7280]">
                  Your uploaded and generated PDF files are permanently erased from server memory 60 minutes after upload, or immediately when you click "Reset" in the editor.
                </p>
              </div>
            </section>

            {/* Section 4 */}
            <section id="third-party" className="space-y-3 scroll-mt-28">
              <h2 className="font-fraunces text-2xl font-medium text-[#1B2740]">
                4. Third-Party Services
              </h2>
              <p className="text-[#6B7280]">
                Pressly integrates with certified infrastructure providers (Cloudflare SSL, AWS Cloud KMS) for secure network delivery. No third party is granted read permissions to your files.
              </p>
            </section>

            {/* Section 5 */}
            <section id="user-rights" className="space-y-3 scroll-mt-28">
              <h2 className="font-fraunces text-2xl font-medium text-[#1B2740]">
                5. Your Rights & GDPR Compliance
              </h2>
              <p className="text-[#6B7280]">
                Under European Union GDPR and California CCPA guidelines, you retain full ownership of all intellectual property processed through Pressly. You have the right to request immediate deletion of session history at any time.
              </p>
            </section>

            {/* Section 6 */}
            <section id="contact" className="space-y-3 scroll-mt-28 border-t border-[#E8E8E6] pt-8">
              <h2 className="font-fraunces text-2xl font-medium text-[#1B2740]">
                6. Contact Us
              </h2>
              <p className="text-[#6B7280]">
                If you have questions regarding this Privacy Policy or document security practices, please contact our Data Protection Officer at:
              </p>
              <p className="font-ibm-mono text-xs text-[#C4432E]">
                privacy@pressly.app • Pressly Inc. Security & Compliance Team
              </p>
            </section>
          </div>
        </main>
      </div>
    </div>
  );
};
