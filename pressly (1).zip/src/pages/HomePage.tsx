import React, { useState, useEffect } from 'react';
import { PageType, PDFTool } from '../types';
import { TOOL_CATEGORIES, ALL_TOOLS } from '../data/toolsData';
import { getAutoSaveMeta, AutoSaveMeta } from '../lib/autoSave';
import {
  ArrowRight,
  Shield,
  Lock,
  Trash2,
  CheckCircle2,
  FileText,
  Layers,
  RefreshCw,
  Edit3,
  PenTool,
  ShieldCheck,
  Zap,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: PageType) => void;
  onSelectTool: (tool: PDFTool) => void;
}

const CATEGORY_ICON_MAP: Record<string, React.FC<{ size?: number; className?: string }>> = {
  Layers,
  RefreshCw,
  Edit3,
  PenTool,
  ShieldCheck,
  Zap,
};

export const HomePage: React.FC<HomePageProps> = ({ onNavigate, onSelectTool }) => {
  const [savedSessionMeta, setSavedSessionMeta] = useState<AutoSaveMeta | null>(null);

  useEffect(() => {
    const meta = getAutoSaveMeta();
    if (meta) {
      setSavedSessionMeta(meta);
    }
  }, []);

  return (
    <div className="min-h-screen bg-white text-[#1B2740]">
      {/* Hero Section */}
      <section className="relative pt-12 sm:pt-20 pb-16 sm:pb-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto overflow-hidden bg-dot-pattern">
        {/* Soft Radial Backdrop Glow */}
        <div className="absolute top-1/4 right-10 w-96 h-96 bg-[#C4432E]/10 rounded-full blur-3xl pointer-events-none -z-10" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8 text-left">
            <div className="flex flex-wrap items-center gap-2.5">
              <div className="inline-flex items-center gap-2 bg-[#F6F6F4] border border-[#E8E8E6] px-4 py-2 rounded-full text-xs font-ibm-mono text-[#1B2740] shadow-2xs">
                <span className="w-2.5 h-2.5 rounded-full bg-[#C4432E] animate-pulse" />
                <span className="font-semibold">Next-Gen Web PDF Platform</span>
              </div>

              {savedSessionMeta && (
                <button
                  onClick={() => onNavigate('editor')}
                  className="inline-flex items-center gap-2 bg-[#1B2740] hover:bg-[#2B3A5A] text-white px-3.5 py-1.5 rounded-full text-xs font-ibm-mono transition-colors cursor-pointer shadow-xs animate-in fade-in"
                >
                  <RotateCcw size={12} className="text-[#C4432E]" />
                  <span>
                    Resume <strong className="underline">{savedSessionMeta.fileName}</strong>
                  </span>
                  <ArrowRight size={12} className="text-gray-300" />
                </button>
              )}
            </div>

            <h1 className="font-fraunces text-4xl sm:text-5xl lg:text-6xl font-medium tracking-tight text-[#1B2740] leading-[1.12]">
              Every PDF tool. <br />
              <span className="text-[#C4432E]">One place.</span>
            </h1>

            <p className="text-base sm:text-lg text-[#6B7280] font-ibm-sans max-w-2xl leading-relaxed">
              Merge, split, edit, compress, e-sign, and convert PDF files directly inside your browser with 256-bit encryption and zero data retention.
            </p>

            {/* CTA Buttons Side-by-Side */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
              <button
                onClick={() => onNavigate('editor')}
                className="inline-flex items-center justify-center gap-2.5 bg-[#C4432E] hover:bg-[#a83623] text-white font-medium text-base px-8 py-3.5 rounded-xl red-glow transition-all transform hover:-translate-y-0.5 cursor-pointer"
              >
                Launch Online Editor
                <ArrowRight size={18} />
              </button>

              <a
                href="#tools-grid"
                className="inline-flex items-center justify-center gap-2 bg-white hover:bg-[#F6F6F4] text-[#1B2740] font-medium text-base px-8 py-3.5 rounded-xl border border-[#1B2740] transition-colors cursor-pointer soft-card-shadow"
              >
                Explore 40+ Tools
              </a>
            </div>
          </div>

          {/* Right Column: Layered Fanned Document Cards Composition */}
          <div className="lg:col-span-5 relative flex justify-center">
            <div className="w-full max-w-md bg-[#F6F6F4] rounded-2xl border border-[#E8E8E6] p-8 relative soft-card-shadow-lg">
              <div className="relative h-72 sm:h-80 w-full flex items-center justify-center">
                {/* Back Card */}
                <div className="absolute w-52 sm:w-60 h-64 sm:h-72 bg-white rounded-xl border border-[#E8E8E6] soft-card-shadow transform -rotate-8 translate-x-6 p-4 space-y-3 opacity-60">
                  <div className="w-1/2 h-2 bg-[#1B2740]/20 rounded" />
                  <div className="w-3/4 h-1.5 bg-[#6B7280]/20 rounded" />
                  <div className="w-full h-1.5 bg-[#6B7280]/20 rounded" />
                  <div className="w-2/3 h-1.5 bg-[#6B7280]/20 rounded" />
                </div>

                {/* Middle Card */}
                <div className="absolute w-52 sm:w-60 h-64 sm:h-72 bg-white rounded-xl border border-[#E8E8E6] soft-card-shadow transform rotate-4 -translate-x-3 p-4 space-y-3 opacity-85">
                  <div className="w-2/3 h-2 bg-[#1B2740]/30 rounded" />
                  <div className="w-full h-1.5 bg-[#6B7280]/20 rounded" />
                  <div className="w-4/5 h-1.5 bg-[#6B7280]/20 rounded" />
                  <div className="w-1/2 h-1.5 bg-[#6B7280]/20 rounded" />
                </div>

                {/* Top Sheet (Red Accented, High Contrast) */}
                <div className="absolute w-56 sm:w-64 h-68 sm:h-76 bg-white rounded-xl border-2 border-[#1B2740] soft-card-shadow-lg p-6 flex flex-col justify-between transform -rotate-1 hover:rotate-0 transition-transform duration-300">
                  <div>
                    <div className="flex justify-between items-center border-b border-[#E8E8E6] pb-3 mb-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 rounded-full bg-[#C4432E]" />
                        <span className="font-fraunces font-medium text-sm text-[#1B2740]">Pressly PDF Engine</span>
                      </div>
                      <span className="text-[10px] font-ibm-mono text-[#6B7280]">256-BIT AES</span>
                    </div>

                    <div className="space-y-2.5">
                      <div className="w-3/4 h-3 bg-[#1B2740] rounded" />
                      <div className="w-full h-2 bg-[#6B7280]/20 rounded" />
                      <div className="w-5/6 h-2 bg-[#6B7280]/20 rounded" />
                      <div className="w-2/3 h-2 bg-[#6B7280]/20 rounded" />
                    </div>
                  </div>

                  <div className="pt-4 border-t border-[#E8E8E6] flex justify-between items-center text-xs">
                    <span className="text-[#C4432E] font-bold font-ibm-mono">• E-SIGN READY</span>
                    <span className="bg-[#1B2740] text-white text-[10px] px-2.5 py-1 rounded-md font-ibm-mono">
                      COMPRESSED -48%
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Curved SVG Divider */}
      <div className="w-full overflow-hidden leading-none bg-white text-[#F6F6F4]">
        <svg viewBox="0 0 1200 120" preserveAspectRatio="none" className="relative block w-full h-10 fill-current">
          <path d="M0,0 C150,90 350,-40 500,45 C650,130 900,10 1200,50 L1200,120 L0,120 Z" />
        </svg>
      </div>

      {/* Trust Bar Section: 3 Pill-Shaped Badges Row */}
      <section className="bg-[#F6F6F4] py-8 border-b border-[#E8E8E6]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6">
            <div className="inline-flex items-center gap-2.5 bg-white border border-[#E8E8E6] px-5 py-2.5 rounded-full soft-card-shadow text-xs sm:text-sm font-medium text-[#1B2740]">
              <div className="w-7 h-7 rounded-full bg-[#C4432E]/10 flex items-center justify-center text-[#C4432E]">
                <Trash2 size={15} />
              </div>
              <span>Auto-delete in 1 hour</span>
            </div>

            <div className="inline-flex items-center gap-2.5 bg-white border border-[#E8E8E6] px-5 py-2.5 rounded-full soft-card-shadow text-xs sm:text-sm font-medium text-[#1B2740]">
              <div className="w-7 h-7 rounded-full bg-[#1B2740]/8 flex items-center justify-center text-[#1B2740]">
                <Shield size={15} />
              </div>
              <span>No signup required</span>
            </div>

            <div className="inline-flex items-center gap-2.5 bg-white border border-[#E8E8E6] px-5 py-2.5 rounded-full soft-card-shadow text-xs sm:text-sm font-medium text-[#1B2740]">
              <div className="w-7 h-7 rounded-full bg-[#C4432E]/10 flex items-center justify-center text-[#C4432E]">
                <Lock size={15} />
              </div>
              <span>256-bit SSL encryption</span>
            </div>
          </div>
        </div>
      </section>

      {/* Tools Grid Section */}
      <section id="tools-grid" className="py-20 sm:py-28 bg-[#F6F6F4]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <h2 className="font-fraunces text-3xl sm:text-4xl font-medium text-[#1B2740]">
              Everything you need
            </h2>
            <p className="text-base text-[#6B7280] font-ibm-sans">
              Comprehensive toolsets categorized for rapid document organization, conversion, signatures, and file optimization.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {TOOL_CATEGORIES.map((cat, idx) => {
              const CategoryIcon = CATEGORY_ICON_MAP[cat.icon] || FileText;
              const catTools = ALL_TOOLS.filter((t) => t.category === cat.name);
              const isRedIcon = idx % 2 === 1;

              return (
                <div
                  key={cat.name}
                  onClick={() => onNavigate('editor')}
                  className="bg-white rounded-2xl border border-[#E8E8E6] p-7 hover:border-[#C4432E] transition-all duration-200 cursor-pointer group soft-card-shadow hover:shadow-xl hover:-translate-y-1 relative"
                >
                  {/* Click to explore arrow */}
                  <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity text-[#C4432E]">
                    <ArrowRight size={18} />
                  </div>

                  {/* Tinted Icon Background Container */}
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 transition-transform group-hover:scale-105 ${
                      isRedIcon
                        ? 'bg-[#C4432E]/10 text-[#C4432E]'
                        : 'bg-[#1B2740]/8 text-[#1B2740]'
                    }`}
                  >
                    <CategoryIcon size={24} />
                  </div>

                  <h3 className="font-fraunces text-xl font-medium text-[#1B2740] mb-2 group-hover:text-[#C4432E] transition-colors">
                    {cat.name}
                  </h3>

                  <p className="text-sm text-[#6B7280] mb-6 leading-relaxed">
                    {cat.description}
                  </p>

                  <div className="border-t border-[#E8E8E6] pt-4 flex flex-wrap gap-1.5">
                    {catTools.map((tool) => (
                      <button
                        key={tool.id}
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectTool(tool);
                        }}
                        className="text-[11px] font-ibm-mono bg-[#F6F6F4] hover:bg-[#C4432E] hover:text-white text-[#1B2740] px-2.5 py-1 rounded-md transition-colors cursor-pointer"
                      >
                        {tool.name}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 sm:py-28 bg-white border-t border-[#E8E8E6]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-16">
          <div className="max-w-2xl mx-auto space-y-3">
            <h2 className="font-fraunces text-3xl sm:text-4xl font-medium text-[#1B2740]">
              How it works
            </h2>
            <p className="text-base text-[#6B7280]">
              Three simple steps to process and transform any PDF document.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
            {/* Step 1 */}
            <div className="bg-[#F6F6F4] rounded-2xl border border-[#E8E8E6] p-8 text-center space-y-4 relative soft-card-shadow">
              <div className="w-14 h-14 rounded-full border-2 border-[#1B2740] bg-white text-[#C4432E] font-fraunces text-xl font-bold flex items-center justify-center mx-auto shadow-xs">
                1
              </div>
              <h3 className="font-fraunces text-xl font-medium text-[#1B2740]">Choose or Drop File</h3>
              <p className="text-sm text-[#6B7280] leading-relaxed">
                Drag your PDF directly into the canvas dropzone or choose from your computer or cloud drive.
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-[#F6F6F4] rounded-2xl border border-[#E8E8E6] p-8 text-center space-y-4 relative soft-card-shadow">
              <div className="w-14 h-14 rounded-full border-2 border-[#1B2740] bg-white text-[#C4432E] font-fraunces text-xl font-bold flex items-center justify-center mx-auto shadow-xs">
                2
              </div>
              <h3 className="font-fraunces text-xl font-medium text-[#1B2740]">Select Your Tool</h3>
              <p className="text-sm text-[#6B7280] leading-relaxed">
                Pick from over 40+ tools in the bottom bar to merge, split, compress, edit, or e-sign instantly.
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-[#F6F6F4] rounded-2xl border border-[#E8E8E6] p-8 text-center space-y-4 relative soft-card-shadow">
              <div className="w-14 h-14 rounded-full border-2 border-[#1B2740] bg-white text-[#C4432E] font-fraunces text-xl font-bold flex items-center justify-center mx-auto shadow-xs">
                3
              </div>
              <h3 className="font-fraunces text-xl font-medium text-[#1B2740]">Download Clean PDF</h3>
              <p className="text-sm text-[#6B7280] leading-relaxed">
                Export your processed document with zero watermarks and automatic file purge protection.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 100% Free Banner Section */}
      <section className="py-16 sm:py-20 bg-[#F6F6F4] border-t border-[#E8E8E6]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-6">
          <div className="inline-flex items-center gap-2 bg-white border border-[#E8E8E6] px-4 py-2 rounded-full text-xs font-ibm-mono text-[#1B2740] shadow-2xs">
            <span className="w-2 h-2 rounded-full bg-[#C4432E]" />
            <span className="font-semibold">100% Free Online PDF Tool</span>
          </div>
          <h2 className="font-fraunces text-3xl sm:text-4xl font-medium text-[#1B2740]">
            No subscriptions. No credit card required.
          </h2>
          <p className="text-base text-[#6B7280] max-w-xl mx-auto leading-relaxed">
            Pressly provides complete, unlimited access to all 40+ PDF tools for everyone without any hidden fees, mandatory registration, or paywalls.
          </p>
          <div>
            <button
              onClick={() => onNavigate('editor')}
              className="inline-flex items-center gap-2 bg-[#C4432E] hover:bg-[#a83623] text-white font-medium text-sm px-8 py-3.5 rounded-xl red-glow transition-all cursor-pointer"
            >
              Start Editing PDF Free
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
