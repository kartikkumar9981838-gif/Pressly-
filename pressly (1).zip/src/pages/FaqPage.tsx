import React, { useState } from 'react';
import { FAQ_DATA } from '../data/faqData';
import { ChevronDown, Search, HelpCircle } from 'lucide-react';

export const FaqPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'General' | 'Privacy' | 'Technical'>('General');
  const [expandedId, setExpandedId] = useState<string | null>('g-1');
  const [searchQuery, setSearchQuery] = useState('');

  const categories = ['General', 'Privacy', 'Technical'] as const;

  const filteredFaqs = FAQ_DATA.filter((item) => {
    const matchesCategory = searchQuery ? true : item.category === activeTab;
    const matchesSearch =
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-[#F6F6F4] pt-12 pb-24 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto space-y-10">
        {/* Page Title & Subtext */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 bg-white border border-[#E8E8E6] px-3.5 py-1.5 rounded-full text-xs font-ibm-mono text-[#1B2740] shadow-2xs">
            <HelpCircle size={14} className="text-[#C4432E]" />
            <span>Support & Documentation</span>
          </div>

          <h1 className="font-fraunces text-4xl sm:text-5xl font-medium text-[#1B2740]">
            Frequently Asked Questions
          </h1>

          <p className="text-base sm:text-lg text-[#6B7280] font-ibm-sans max-w-xl mx-auto leading-relaxed">
            Everything you need to know about Pressly security, document handling, file tools, and subscription plans.
          </p>

          {/* Search Input Bar */}
          <div className="pt-4 max-w-md mx-auto relative">
            <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-[#6B7280]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search questions (e.g., encryption, OCR, size limits)..."
              className="w-full pl-10 pr-4 py-3 bg-white border border-[#E8E8E6] rounded-xl text-sm text-[#1B2740] focus:outline-none focus:border-[#C4432E] shadow-2xs"
            />
          </div>
        </div>

        {/* Category Tabs */}
        {!searchQuery && (
          <div className="flex justify-center border-b border-[#E8E8E6] space-x-6 sm:space-x-12 overflow-x-auto no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  setActiveTab(cat);
                  const firstCatItem = FAQ_DATA.find((i) => i.category === cat);
                  if (firstCatItem) setExpandedId(firstCatItem.id);
                }}
                className={`pb-4 text-sm font-medium transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === cat
                    ? 'border-b-2 border-[#C4432E] text-[#C4432E] font-semibold'
                    : 'text-[#6B7280] hover:text-[#1B2740]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        )}

        {/* Accordion List */}
        <div className="space-y-4">
          {filteredFaqs.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-xl border border-[#E8E8E6] p-8">
              <p className="text-sm text-[#6B7280]">No matching questions found for "{searchQuery}".</p>
            </div>
          ) : (
            filteredFaqs.map((faq) => {
              const isExpanded = expandedId === faq.id;

              return (
                <div
                  key={faq.id}
                  className="bg-white rounded-xl border border-[#E8E8E6] overflow-hidden transition-all shadow-2xs hover:border-[#1B2740]/30"
                >
                  <button
                    onClick={() => setExpandedId(isExpanded ? null : faq.id)}
                    className="w-full px-6 py-5 text-left flex justify-between items-center space-x-4 cursor-pointer focus:outline-none"
                  >
                    <span className="font-ibm-sans font-medium text-base text-[#1B2740]">
                      {faq.question}
                    </span>
                    <ChevronDown
                      size={20}
                      className={`text-[#6B7280] shrink-0 transition-transform duration-200 ${
                        isExpanded ? 'rotate-180 text-[#C4432E]' : ''
                      }`}
                    />
                  </button>

                  {isExpanded && (
                    <div className="px-6 pb-6 pt-1 text-sm text-[#6B7280] border-t border-[#F6F6F4] leading-relaxed animate-in fade-in duration-150">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
