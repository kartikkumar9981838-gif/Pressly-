import { FaqItem } from '../types';

export const FAQ_DATA: FaqItem[] = [
  // General
  {
    id: 'g-1',
    category: 'General',
    question: 'What is Pressly?',
    answer:
      'Pressly is an all-in-one PDF manager tool and web editor designed for instant document organization, conversion, editing, signature collection, and security directly inside your browser.',
  },
  {
    id: 'g-2',
    category: 'General',
    question: 'Do I need to download or install software?',
    answer:
      'No. Pressly operates 100% inside modern web browsers on macOS, Windows, Linux, iOS, and Android with zero plugins required.',
  },
  {
    id: 'g-3',
    category: 'General',
    question: 'Are there file size or usage limits?',
    answer:
      'Pressly is 100% free to use. All users get unlimited processing operations, e-signatures, conversions, and document editing with zero registration or credit card required.',
  },
  {
    id: 'g-4',
    category: 'General',
    question: 'Can I use Pressly on mobile devices?',
    answer:
      'Yes! Pressly is fully responsive with touch-optimized controls for mobile phones and tablets, allowing you to sign, merge, or convert PDFs on the go.',
  },

  // Privacy
  {
    id: 'p-1',
    category: 'Privacy',
    question: 'Are my uploaded documents secure and private?',
    answer:
      'Absolute privacy is our top principle. All files are encrypted in transit with 256-bit SSL/TLS encryption. Files are processed in ephemeral isolated memory and automatically purged completely after 1 hour.',
  },
  {
    id: 'p-2',
    category: 'Privacy',
    question: 'Do you inspect or read my file content?',
    answer:
      'Never. Pressly uses automated client-assisted algorithms and never scans, indexes, or retains document content or metadata for training models or analytics.',
  },
  {
    id: 'p-3',
    category: 'Privacy',
    question: 'Is Pressly GDPR and HIPAA compliant?',
    answer:
      'Yes. Pressly complies with GDPR requirements and follows strict data privacy standards for all personal and business document processing.',
  },

  // Technical
  {
    id: 't-1',
    category: 'Technical',
    question: 'How does OCR (Optical Character Recognition) work?',
    answer:
      'Pressly OCR extracts text from image-based or scanned PDFs using high-accuracy neural vision engines, turning non-selectable text into searchable and copyable documents.',
  },
  {
    id: 't-2',
    category: 'Technical',
    question: 'What formats can I convert to and from PDF?',
    answer:
      'Pressly supports bidirectional conversion between PDF and Microsoft Word (DOCX), Excel (XLSX), PowerPoint (PPTX), JPG, PNG, WEBP, and HTML.',
  },
  {
    id: 't-3',
    category: 'Technical',
    question: 'Are digital signatures created on Pressly legally binding?',
    answer:
      'Yes. E-signatures generated through Pressly comply with the US ESIGN Act and European eIDAS regulation standards for electronic signatures.',
  },
];
