import React, { useState, useEffect } from 'react';
import { PageType, PDFTool } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { EditorPage } from './pages/EditorPage';
import { FaqPage } from './pages/FaqPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { usePwaInstall } from './lib/usePwaInstall';
import { PwaInstallModal } from './components/PwaInstallModal';
import { OfflineIndicator } from './components/OfflineIndicator';

export default function App() {
  const {
    isInstallable,
    hasPrompt,
    isInstalled,
    isOnline,
    isIOS,
    isInstallModalOpen,
    setIsInstallModalOpen,
    triggerInstall,
  } = usePwaInstall();

  const [currentPage, setCurrentPage] = useState<PageType>(() => {
    try {
      // Check query params (e.g. from PWA app shortcut)
      if (typeof window !== 'undefined' && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        const p = params.get('page') as PageType;
        if (p && ['home', 'editor', 'faq', 'privacy'].includes(p)) {
          return p;
        }
      }

      const savedPage = localStorage.getItem('pressly_current_page') as PageType;
      if (savedPage && ['home', 'editor', 'faq', 'privacy'].includes(savedPage)) {
        return savedPage;
      }
    } catch (e) {}
    return 'home';
  });

  const [selectedToolId, setSelectedToolId] = useState<string | null>(() => {
    try {
      if (typeof window !== 'undefined' && window.location.search) {
        const params = new URLSearchParams(window.location.search);
        const tool = params.get('tool');
        if (tool) return tool;
      }
    } catch (e) {}
    return null;
  });

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    try {
      localStorage.setItem('pressly_current_page', currentPage);
    } catch (e) {}
  }, [currentPage]);

  const handleNavigate = (page: PageType, sectionId?: string) => {
    if (page === 'home' || page === 'faq' || page === 'privacy') {
      setSelectedToolId(null);
    }
    setCurrentPage(page);
    try {
      localStorage.setItem('pressly_current_page', page);
    } catch (e) {}
    if (sectionId && page === 'home') {
      setTimeout(() => {
        const el = document.getElementById(sectionId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
  };

  const handleSelectToolFromHome = (tool: PDFTool) => {
    setSelectedToolId(tool.id);
    setCurrentPage('editor');
    try {
      localStorage.setItem('pressly_current_page', 'editor');
    } catch (e) {}
  };

  return (
    <div className="min-h-screen flex flex-col justify-between bg-white text-[#1B2740]">
      {/* Offline Status & Real-time Connectivity Notice Strip */}
      <OfflineIndicator
        isOnline={isOnline}
        isInstallable={isInstallable}
        isInstalled={isInstalled}
        onInstallClick={triggerInstall}
      />

      {currentPage === 'editor' ? (
        <EditorPage
          onNavigate={handleNavigate}
          initialToolId={selectedToolId}
          isOnline={isOnline}
          isInstalled={isInstalled}
          onInstallClick={triggerInstall}
        />
      ) : (
        <>
          <Header
            currentPage={currentPage}
            onNavigate={handleNavigate}
            isOnline={isOnline}
            isInstallable={isInstallable}
            isInstalled={isInstalled}
            onInstallClick={triggerInstall}
          />

          <main className="flex-1">
            {currentPage === 'home' && (
              <HomePage
                onNavigate={handleNavigate}
                onSelectTool={handleSelectToolFromHome}
              />
            )}
            {currentPage === 'faq' && <FaqPage />}
            {currentPage === 'privacy' && <PrivacyPage />}
          </main>

          <Footer onNavigate={handleNavigate} />
        </>
      )}

      {/* PWA Guided Installation Dialog (For iOS Safari or manual install trigger) */}
      <PwaInstallModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
        onInstall={triggerInstall}
        hasPrompt={hasPrompt}
        isIOS={isIOS}
        isInstalled={isInstalled}
      />
    </div>
  );
}

